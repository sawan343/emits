// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

import { StringOperationFilterInput, ComparableNullableOfDateTimeOperationFilterInput } from "./graphqlUtils";

export const Configuration: any = {
    Asset_Lat_Long: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Total'
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            } ,
            {
                name: "assettype_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            }
        ],
        enterprise: [
            {
                name: "enterprise",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: "Enterprise1"
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'CO2e'
            }
           
        ],
        region: [
            {
                name: "region",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Region1'
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'CO2e'
            },
        ],
        mapview: [{
            name: "asset_name",
            isFilterVariable: true,
            isRequiredField: false,
            filterVariableType: StringOperationFilterInput,
            defaultValue: ''
        }]

    },
    Kpi_Bar: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "assettype_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            }
        ],
        enterprise: [{
            name: "enterprise",
            isFilterVariable: true,
            isRequiredField: false,
            filterVariableType: StringOperationFilterInput,
            defaultValue: "Enterprise1"
        }],
        region: [
            {
                name: "enterprise",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: "Enterprise1"
            },
            {
                name: "region",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Region1'
            }
        ],
        site: [
            {
                name: "region",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Region1'
            },
            {
                name: "site",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Site4'
            }
        ]

    },
    Kpi_Landing_Page: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Total'
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'CO2e'
            },
            {
                name: "assettype_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "asset_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            }
        ],
        kpiCategories: [{
            name: 'Intensity',
            sub_display_name: '',
            isFilterVariable: true,
            total: 0
        },
        {
            name: 'Total',
            sub_display_name: '',
            isFilterVariable: true,
            total: 0
        }],
        kpiTypes: ['CO2e', 'CH4'],
        emissionIntensityBar: [
            {
                value: 1,
                percentage: '0%'
            },
            {
                value: 0.75,
                percentage: '25%'
            },
            {
                value: 0.50,
                percentage: '50%'
            },
            {
                value: 0.25,
                percentage: '75%'
            },
            {
                value: 0,
                percentage: '99%'
            }

        ]
    },
    Kpi_Selector: {
        default: [
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            }
        ],
        enterprise: [
            {
                name: "enterprise",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: "Enterprise1"
            }
        ],
        site: [
            {
                name: "site",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: "site4"
            }
        ],
        region: [
            {
                name: "region",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: "Enterprise1"
            }
        ]

    },
    Intensity_Tile: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Intensity'
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'CO2e'
            },
            {
                name: "assettype_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "actualValue",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "uom",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "targetHighLimit",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "warningHigh",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
        ],
        enterprise: [
            {
                name: "enterprise",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
        ],
        region: [
            {
                name: "enterprise",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "region",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
        ],
        site: [
            {
                name: "enterprise",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "region",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "site",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
        ],
    },
    Critical_Sites_Tile: {
        default: [

            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'CO2e'
            },
            {
                name: "assettype_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "actualValue",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "uom",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "targetHighLimit",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "warningHigh",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "site",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
        ],
        enterprise: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Total'
            },
            {
                name: "enterprise",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "region",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
        ],
        region: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Total'
            },
            {
                name: "enterprise",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "region",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
        ],
        site: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Source Tag'
            },
            {
                name: "enterprise",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "region",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "site",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
        ],
    },
    Donut_Chart: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Total'
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'CO2e'
            },
            {
                name: "assettype_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "asset_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            }
        ]
    },
    Column_Chart: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Total'
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'CO2e'
            },
            {
                name: "assettype_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "asset_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly',
                reportingPeriodMapping: {
                    'ALL OF TODAY': 'Hourly',
                    'ALL OF YESTERDAY': 'Hourly',
                    'ALL OF LAST WEEK': 'Daily',
                    'ALL OF LAST MONTH': 'Daily',
                    'ALL OF LAST QUARTER': 'Monthly',
                    'ALL OF LAST YEAR': 'Monthly',
                    'START OF THE DAY TO NOW': 'Hourly',
                    'START OF THE WEEK TO NOW': 'Daily',
                    'START OF THE MONTH TO NOW': 'Daily',
                    'START OF THE QUARTER TO NOW': 'Monthly',
                    'START OF THE YEAR TO NOW': 'Monthly'
                }
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            }
        ]
    },
    Unit_Level_Column_Trend: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Total'
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'CO2e'
            },
            {
                name: "site",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "process_unit",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly',
                reportingPeriodMapping: {
                    'ALL OF TODAY': 'Hourly',
                    'ALL OF YESTERDAY': 'Hourly',
                    'ALL OF LAST WEEK': 'Daily',
                    'ALL OF LAST MONTH': 'Daily',
                    'ALL OF LAST QUARTER': 'Monthly',
                    'ALL OF LAST YEAR': 'Monthly',
                    'START OF THE DAY TO NOW': 'Hourly',
                    'START OF THE WEEK TO NOW': 'Daily',
                    'START OF THE MONTH TO NOW': 'Daily',
                    'START OF THE QUARTER TO NOW': 'Monthly',
                    'START OF THE YEAR TO NOW': 'Monthly'
                }
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            }
        ]
    },
    Map_View: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Source Tag'
            },
            {
                name: "site",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ''
            }
            
        ]
    },
    Ranking_Visual: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Source Tag'
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'CO2e'
            }, {
                name: "site",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "rank",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "actualValue",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "uom",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            }, {
                name: "scope_displayname",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "source_displayname",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            }, {
                name: "source_tag",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            }, {
                name: "sourcetag_displayname",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            }, {
                name: "subsource_displayname",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            }, {
                name: "sourcegroup_displayname",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
        ]
    },
    Active_Rank: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Rank'
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "site",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "actualValue",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "asset_name",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "rank",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "kpi_type",
                isFilterVariable: false,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'CO2e'
            }
        ]
    },
    Trend_Grid: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Total'
            },
            {
                name: "assettype_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "asset_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            }
        ],
        level_0: [],
        level1: [
            {
                name: 'scope_displayname',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Scope 1'
            }
        ],
        level2: [
            {
                name: 'scope_displayname',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Scope 1'
            },
            {
                name: 'source_displayname',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Scope 1'
            }

        ],
        level3: [
            {
                name: 'scope_displayname',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Scope 1'
            },
            {
                name: 'source_displayname',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Scope 1'
            },
            {
                name: 'subsource_displayname',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Scope 1'
            }

        ]
    },
    Unit_Level_TrendGrid: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Total'
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'CO2e'
            },
            {
                name: "site",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "process_unit",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly',
                reportingPeriodMapping: {
                    'ALL OF TODAY': 'Hourly',
                    'ALL OF YESTERDAY': 'Hourly',
                    'ALL OF LAST WEEK': 'Daily',
                    'ALL OF LAST MONTH': 'Daily',
                    'ALL OF LAST QUARTER': 'Monthly',
                    'ALL OF LAST YEAR': 'Monthly',
                    'START OF THE DAY TO NOW': 'Hourly',
                    'START OF THE WEEK TO NOW': 'Daily',
                    'START OF THE MONTH TO NOW': 'Daily',
                    'START OF THE QUARTER TO NOW': 'Monthly',
                    'START OF THE YEAR TO NOW': 'Monthly'
                }
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            }
        ]
    },
    Kpi_FilterPage: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Souce Group'
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'CO2e'
            },
            {
                name: "assettype_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "asset_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Daily'
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            }
        ],
        kpiCategories: [
        {
            name: 'Source Group',
            sub_display_name: '',
            isFilterVariable: true,
            total: 0
        }],
        kpiTypes: ['CO2e'],
        
    },
    Source_Details: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "asset_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            }
        ],
    },
    All_Source_Tag : {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "asset_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            }
        ]
    },
    All_Source: {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "asset_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "source_displayname",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            }
        ]
    },
    All_Scope : {
        default: [
            {
                name: 'kpi_category',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "kpi_type",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "asset_name",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "scope_displayname",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: 'Hourly'
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ""
            }
        ]
    },
    All_KPI_Type: {
        default: [
            {
                name: 'asset_name',
                isFilterVariable: true,
                isRequiredField: true,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ''
            },
            {
                name: "kpi_category",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "reportingperiod",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: StringOperationFilterInput,
                defaultValue: ""
            },
            {
                name: "time",
                isFilterVariable: true,
                isRequiredField: false,
                filterVariableType: ComparableNullableOfDateTimeOperationFilterInput,
                defaultValue: ''
            }
        ]
    }
}