
/**
 * graphQl schemas.
 */
export const GQL_paginatedEmissions_Schema_Type = 'paginatedEmissions';
export const GQL_assets_Schema_Type = 'assets';

/**
 * graphql accepted data types.
 */
export const StringOperationFilterInput = 'StringOperationFilterInput';
export const ComparableNullableOfDateTimeOperationFilterInput = 'ComparableNullableOfDateTimeOperationFilterInput';

/**
 * Time control reporting time mapping
 * This should be temporary solution as time control won't send the reporting period data
 * Values can be different based on tenant
 */
export const Time_Control_Reporting_Mapping: any = {
    'ALL OF TODAY': 'Hourly',
    'ALL OF YESTERDAY': 'Hourly',
    'ALL OF LAST WEEK': 'Daily',
    'ALL OF LAST MONTH': 'Daily',
    'ALL OF LAST QUARTER': 'Monthly',
    'ALL OF LAST YEAR': 'Monthly',
    'START OF THE DAY TO NOW': 'Hourly',
    'START OF THE WEEK TO NOW': 'Daily',
    'START OF THE MONTH TO NOW': 'Daily',
    'START OF THE QUARTER TO NOW': 'Monthly',
    'START OF THE YEAR TO NOW': 'Monthly'
}

export const getReportingPeriod = (start: any, end: any, key: any) => {
    if (Time_Control_Reporting_Mapping.hasOwnProperty(key)) {
        return Time_Control_Reporting_Mapping[key];
    }
    const startTime = new Date(start).getTime();
    const endTime = new Date(end).getTime();
    const diffMilliseconds = endTime - startTime;
    const diffHours = diffMilliseconds / (1000 * 60 * 60);
    const diffDays = diffHours / 24;
    const diffMonths = diffDays / 30;

    if (diffHours <= 24) {
        return 'Hourly';
    } else if (diffDays <= 30) {
        return 'Daily';
    } else {
        return 'Monthly';
    }
}

export const getAvailableFilterTypes = (page: string, configuration: any, optionalFilters: any = []) => {
    const defaultFilters = configuration['default']?.filter((item: any) => item.isFilterVariable);
    const pageFilters = configuration[page]?.filter((item: any) => item.isFilterVariable);
    if (optionalFilters.length > 0) {
        return pageFilters ? [...defaultFilters, ...pageFilters, ...optionalFilters] : [...defaultFilters, ...optionalFilters];
    }
    return pageFilters ? [...defaultFilters, ...pageFilters, ...optionalFilters] : defaultFilters;
}

export const getFiltersDataType = (availableFilterTypes: any) => {
    let filters: string = '';
    availableFilterTypes.map((item: any) => {
        filters = filters.concat(`$${item.name}: ${item.filterVariableType}!, `)
    });
    return filters;
}

export const createFilters = (availableFilterTypes: any) => {
    let filters: string = '';
    availableFilterTypes.map((item: any) => {
        filters = filters.concat(`${item.name}: $${item.name}, `)
    });
    return filters;
}
