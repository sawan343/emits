// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.


import { ApolloClient, ApolloLink, HttpLink, InMemoryCache } from '@apollo/client';
import { setContext } from "@apollo/client/link/context";
import { onError } from "@apollo/client/link/error";
import {graphQlUrl, authToken, tenantId} from '../api/config';

const cache = new InMemoryCache({});

const authFlow = (headers: any) => {
    return {
        headers: {
            ...headers,
            authorization: authToken,
            tenantid: tenantId
        },
    };
};

const authorization = setContext((request: any, { headers }: any) => {
    return authFlow(headers)
});

export const client = new ApolloClient({
    link: ApolloLink.from([
        authorization,
        new HttpLink({
            uri:graphQlUrl,
        }),
    ]),
    defaultOptions: {
        query: {
            fetchPolicy: 'network-only', // Can be changed on a query level, but going with network by default because of defects raised
        },
    },
    cache
});