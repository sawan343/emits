export const baseURL = 'https://hciememissiongrapqlsit-ee.dev.forge.connected.honeywell.com';
export const uri = '/api/graphql';
export const graphQlUrl = `${baseURL}/api/graphql`;
export const authToken = sessionStorage.getItem('access_token');
export const tenantId = sessionStorage.getItem('tenantId') && sessionStorage.getItem('tenantId') !== '' ? sessionStorage.getItem('tenantId') : 'piappdevsit3';
export const contentId = "2a698cdc-7ed3-9e4c-23ab-66f2c7600132";
export const assetViewId = "045d7cb6-bbdd-4ec8-ac35-73218719ad70";
