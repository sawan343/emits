import React, { createContext, useReducer, useMemo } from 'react';

const host = window.location.hostname;
const defaultTime =  host === 'localhost' ?  {
    end: "2023-07-11T05:27:30.000Z",
id: "2023-03-16 21:00:00 to 2023-03-16 21:00:00",
start: "2023-06-30T18:30:00.000Z"
    } : {};

export interface IAppContext {
    locale: any
    setLocale: Function
    portalContext: any
    setPortalContext: Function
    timeContext: any
    setTimeContext: Function
    siteDetailFilter: any,
    setSiteDetailFilter: Function

}

const AppContextInitialState: IAppContext = {
    locale: {},
    setLocale: () => { },
    portalContext: {},
    setPortalContext: () => { },
    timeContext: {},
    setTimeContext: () => { },
    siteDetailFilter: {},
    setSiteDetailFilter: () => { }
}

export const AppContext = createContext(AppContextInitialState);

export const AppContextProvider = ({ children }: any) => {

    const [context, setContext] = useReducer((oldState: any, newState: any) => (
        { ...oldState, ...newState }),
        // initial state
        {
            locale: {},
            setLocale: (locale: any) => {
                setContext({ locale: locale });
            },
            portalContext: {},
            setPortalContext: (portalContext: any) => {
                setContext({ portalContext });
            },
            siteDetailFilter: {},
            setSiteDetailFilter: (siteDetailFilter: any) => {
                setContext({siteDetailFilter: siteDetailFilter});
            },
            timeContext: defaultTime,
            setTimeContext: (timeContext: any) => {
                setContext({ timeContext });
            }
        }
    );

    const value: any = useMemo(() => {
        return {
            ...context,
            setContext
        }
    }, [context])

    return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}