import { useContext } from 'react';
import { useQuery, gql } from '@apollo/client';
import { Configuration } from '../api/queryFieldMappings';
import { AppContext } from '../store/AppContext';
import {
    getReportingPeriod,
    GQL_paginatedEmissions_Schema_Type,
    getAvailableFilterTypes,
    getFiltersDataType,
    createFilters,
} from "../api/graphqlUtils";
import { findMixAndMax, precisionDecimal } from '../utils/utils';

const initCarbonNeutralityData = {
    min: 0,
    max: 0,
    current: 0,
    getCarbonNeutralityLimit: [{
        value: 0,
        percentage: '0%'
    },
    {
        value: 0,
        percentage: '25%'
    },
    {
        value: 0,
        percentage: '50%'
    },
    {
        value: 0,
        percentage: '75%'
    },
    {
        value: 0,
        percentage: '96%'
    }
    ],
    trianglePoint: 100
}

const getVariables = (availableFilterTypes: any, page: string, portalContext: any, timeContext: any) => {
    let variables: any = {};
    availableFilterTypes.map((filter: any) => {
        if (filter.name === 'assettype_name') {
            variables = { ...variables, [filter.name]: { eq: "Enterprise" } }
        } else if (filter.name === 'asset_name') {
            variables = { ...variables, [filter.name]: { eq: portalContext['enterprise'] } }
        } else if (filter.name === 'kpi_category') {
            variables = { ...variables, [filter.name]: { in: ["Intensity", "Total"] } }
        } else if (filter.name === 'kpi_type') {
            variables = { ...variables, [filter.name]: { in: ["CO2e", "CH4"] } }
        } else if (filter.name === 'time') {
            variables = { ...variables, "time": { "gte": timeContext?.['start'], "lte": timeContext?.['end'] } }
        } else if (filter.name === 'reportingperiod') {
            variables = { ...variables, "reportingperiod": { eq: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()) || "Hourly" } }
        }
    });
    return variables;

}

const getQuery = (page: string, portalContext: any, timeContext: any) => {
    const { Kpi_Landing_Page } = Configuration;
    const availableFilterTypes = getAvailableFilterTypes(page, Kpi_Landing_Page);
    const filtersWithDatatype = getFiltersDataType(availableFilterTypes);
    const filters = createFilters(availableFilterTypes);
    const variables = getVariables(availableFilterTypes, page, portalContext, timeContext);

    const query = gql`
    query getLandingPageData (${filtersWithDatatype}) {

    ${GQL_paginatedEmissions_Schema_Type}(
  
     where: {${filters}}
     order: {time: ASC}
  
    ) {
        edges {
            node {  
                actualValue
                kpi_type      
                kpi_category 
                time 
                uom
            }
        }
      }
  
   }`

    return { query, variables }
}

const getCarbonNeutralityLimit = (max: number, min: number) => {
    const arr = [max, max * 0.75, max * 0.5, max * 0.25, min * 0];
    return arr;
}
const getTrianglePosition = (currentValue: number, maxValue: number, defaultValue: number) => {
    if (currentValue < 1 || maxValue < 1 || isNaN(currentValue) || isNaN(maxValue)) return defaultValue;
    return (defaultValue - (currentValue / maxValue) * defaultValue);
}
const useLandingPageData = (page: string) => {
    const { portalContext, timeContext } = useContext(AppContext);
    const { query, variables } = getQuery(page, portalContext, timeContext);
    const { data, loading, error } = useQuery(query, { variables: variables });
    const { Kpi_Landing_Page } = Configuration;
    let kpiLandingPageData: Array<any> = [];
    let totalEmissionData = {}

    if (!loading) {
        console.log({ data })
        const { edges } = data?.paginatedEmissions;
        const nodes = edges.map((item: any) => {
            return item.node
        });

        Kpi_Landing_Page['kpiCategories'].map((kpiCategory: any) => {
            Kpi_Landing_Page['kpiTypes'].map((kpiType: any) => {
                let sum: any = 0;
                nodes.map((node: any) => {
                    if (kpiCategory.name === node.kpi_category && kpiType === node.kpi_type) {
                        sum = sum + node.actualValue;
                        const data = { kpi_category: node.kpi_category, kpi_type: kpiType, totalActualValue: sum, uom: node.uom };
                        const index = kpiLandingPageData.findIndex(el => (el.kpi_category === node.kpi_category && el.kpi_type === node.kpi_type));
                        return index > -1 ? kpiLandingPageData[index] = data : kpiLandingPageData.push(data);
                    }
                })
            });
        });
        const CO2eSeriesActualValue = nodes.filter((item: any) => item?.kpi_type === 'CO2e' && item?.kpi_category === "Intensity");
        // const productionTotalValue = kpiLandingPageData.find((item: any) => item?.kpi_type === 'Production')?.totalActualValue;
        const CO2eIntesity = kpiLandingPageData.find((item: any) => (item?.kpi_type === 'CO2e' && item?.kpi_category === "Intensity"))?.totalActualValue;
        const CO2eIntesityUom = kpiLandingPageData.find((item: any) => (item?.kpi_type === 'CO2e' && item?.kpi_category === "Intensity"))?.uom;
        const CH4Intesity = kpiLandingPageData.find((item: any) => (item?.kpi_type === 'CH4' && item?.kpi_category === "Intensity"))?.totalActualValue;
        const CH4IntesityUom = kpiLandingPageData.find((item: any) => (item?.kpi_type === 'CH4' && item?.kpi_category === "Intensity"))?.uom;
        const CO2eTotalValue = kpiLandingPageData.find((item: any) => (item?.kpi_type === 'CO2e' && item?.kpi_category === "Total"))?.totalActualValue;
        const CO2eTotalValueUom = kpiLandingPageData.find((item: any) => (item?.kpi_type === 'CO2e' && item?.kpi_category === "Total"))?.uom;
        totalEmissionData = {
            ...totalEmissionData,
            CO2ePercentage: CO2eIntesity ? `${precisionDecimal(CO2eIntesity)}%` : '-',
            CH4ePercentage: CH4Intesity ? `${precisionDecimal(CH4Intesity)}%` : '-',
            CO2eTotalValue: isNaN(CO2eTotalValue) ? '-' : Number(precisionDecimal(CO2eTotalValue)),
            CO2eIntesityUom: CO2eIntesityUom,
            CH4IntesityUom: CH4IntesityUom,
            CO2eTotalValueUom: CO2eTotalValueUom
        };
        try {
            const minAndMax = findMixAndMax(CO2eSeriesActualValue, 'actualValue');
            const currentValue = CO2eSeriesActualValue[CO2eSeriesActualValue.length - 1]?.actualValue;
            if (minAndMax) {
                initCarbonNeutralityData.min = minAndMax.lowest;
                initCarbonNeutralityData.max = minAndMax.highest;
                initCarbonNeutralityData.current = currentValue;
                initCarbonNeutralityData.trianglePoint = getTrianglePosition(currentValue, minAndMax.highest, initCarbonNeutralityData.trianglePoint);
                initCarbonNeutralityData.getCarbonNeutralityLimit = getCarbonNeutralityLimit(minAndMax.highest, minAndMax.lowest).map((item: any, index: number) => {
                    return {
                        ...initCarbonNeutralityData.getCarbonNeutralityLimit[index],
                        value: item,
                    }
                })
            }
        } catch (error) {
            console.log(error);
        }
        totalEmissionData = {
            ...totalEmissionData,
            carbonNeutralityData: initCarbonNeutralityData
        }
    }

    return {
        totalEmissionData,
        loading,
        error
    }

};

export default useLandingPageData;