// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.


import React from 'react';
import { gql } from '@apollo/client';
import { graphQlUrl, authToken, tenantId } from '../api/config';

const assetDetailsQuery = gql`{
  assets {
    assettype_name
    name
    qualifiedpath
    site
    enterprise
    region
  }
}`


const GetAssetDetails = async () => {
  let apiCall = await fetch(graphQlUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': authToken ? authToken : '',
      'tenantId': tenantId ? tenantId : ''
    },
    body: JSON.stringify({
      variables: {},
      query: `{
          assets {
            id
            assettype_name
            name
            qualifiedpath
            site
            enterprise
            region
          }
        }`,
    }),
  })

  let results = await apiCall.json()
  return results;
}



export default GetAssetDetails;