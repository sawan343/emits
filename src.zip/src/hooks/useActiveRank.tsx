
import { useContext } from 'react';
import { useQuery, gql } from '@apollo/client';
import { Configuration } from '../api/queryFieldMappings';
import { GQL_paginatedEmissions_Schema_Type, getReportingPeriod, getAvailableFilterTypes, getFiltersDataType, createFilters } from '../api/graphqlUtils';
import { AppContext } from '../store/AppContext';
import { groupDataByKey } from '../utils/utils';
import { getActiveElement } from '@testing-library/user-event/dist/utils';

const getRankQuery = (page: any, portalContext: any, timeContext: any, siteName: any, assetName: string) => {
    const { Active_Rank } = Configuration;
    const availableFilterTypes = getAvailableFilterTypes(page, Active_Rank);
    const query = gql`
    query getSourceDetailActiveRank {
        paginatedEmissions(
          where: {
            asset_name: {eq: "${assetName}"}
            kpi_category: {in: ["Rank"]}
            site: {eq: "${siteName}"}
            reportingperiod: {eq: "Hourly"}
            time: { 
                gte: "${timeContext?.['start']}"
                lte: "${timeContext?.['end']}"
            }
          }
      
          order: { time: DESC }
        ) {
          totalCount
      
          edges {
            node {
              actualValue
              asset_name
            }
          }
        }
      }
      `

    return query;
};

const useActiveRank = (page: string, siteName: string, assetName: string) => {
    const { portalContext, timeContext } = useContext(AppContext);
    const { data, loading, error} = useQuery( getRankQuery(page, portalContext, getActiveElement(timeContext), siteName, assetName));
    let activeRankData:any = false;
    if(!loading) {
        const { edges } = data?.paginatedEmissions || [];
          if(edges?.length > 0) {
            const nodes = edges.map((item: any) => {
                  return item?.node;
          });
          if(nodes?.length > 0) {
            if(nodes[0]?.asset_name === assetName){
              if(nodes[0]?.actualValue) {
                activeRankData = nodes[0]?.actualValue
              }
            }
          }
        }
    }

    return {
        activeRankData: activeRankData, activeLoading: loading, activeError: error
    }
}


export default useActiveRank;