import { useQuery, gql } from "@apollo/client";
import { Configuration } from "../api/queryFieldMappings";
import { GQL_paginatedEmissions_Schema_Type, getAvailableFilterTypes, getFiltersDataType, createFilters, getReportingPeriod } from "../api/graphqlUtils";
import { useContext, useMemo } from "react";
import { AppContext } from "../store/AppContext";
import { DONUT_CHART_SCOPES, CHART_COLORS } from "../utils/constants";
import { groupDataByKey } from "../utils/utils";

const orderData = [
  "CO2e",
  "CH4",
  "CO2",
  "N2O",
  "R134a"
];

const getVariables = (availableFilterTypes: any, soure_tag_key: any, page: string, portalContext: any, timeContext: any) => {
  let variables: any = {};
  availableFilterTypes.map((filter: any) => {
    if (filter.name === 'asset_name') {
      variables = { ...variables, [filter.name]: { eq: soure_tag_key } }
    } else if (filter.name === 'kpi_category') {
      variables = { ...variables, [filter.name]: { eq: "Source Tag" } }
    } else if (filter.name === 'time') {
      variables = { ...variables, "time": { "gte": timeContext?.['start'], "lte": timeContext?.['end'] } }
    } else if (filter.name === 'reportingperiod') {
      variables = { ...variables, "reportingperiod": { eq: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()) || 'Daily' } }
    }
  });
  return variables;
};

const getQuery = (page: string, soure_tag_key: any, portalContext: any, timeContext: any) => {
  const { All_KPI_Type } = Configuration;
  const availableFilterTypes = getAvailableFilterTypes(page, All_KPI_Type);
  const filtersWithDatatype = getFiltersDataType(availableFilterTypes);
  const filters = createFilters(availableFilterTypes);
  const variables = getVariables(availableFilterTypes, soure_tag_key, page, portalContext, timeContext);

  const query = gql`
  query getAllKPITYpesBySourceTag (${filtersWithDatatype}) {

  ${GQL_paginatedEmissions_Schema_Type}(

   where: {${filters}}
  ) {
      edges {
          node {  
            actualValue
            uom
            kpi_type
            rank
          }
      }
    }

 }`

  return { query, variables }
}

const useGetAll_KPI_TYpesBySourceTag = (page: string, soure_tag_key: any, activeRank:any) => {
  const { portalContext, timeContext } = useContext(AppContext);
  const { query, variables } = getQuery(page, soure_tag_key, portalContext, timeContext)
  const { data, loading, error } = useQuery(query, { variables: variables });
  let kpiData: Array<any> = [];
  let headers: any = [];
  let kpi_values: any = {};
  let uom = 'Tonnes';


  // useMemo(() => {
  // }, [loading]);
  if (!loading) {
    const { edges } = data?.paginatedEmissions;
    const nodes = edges.map((item: any) => item.node);
    const groupDataByDisplayName: string = 'kpi_type';
    let groupedKPI_Values = groupDataByKey(nodes, groupDataByDisplayName);

    // Object.keys(groupedKPI_Values).sort(function (a:any,b:any){
    //   return orderData.indexOf(a) - orderData.indexOf(b)
    // });

    //addition of gases by KPI type
    try {
      headers = Object.keys(groupedKPI_Values);
      headers = headers.sort(function (a: any, b: any) {
        return orderData.indexOf(a) - orderData.indexOf(b);
      });
      Object.keys(groupedKPI_Values).forEach((item: any, i) => {
        const groupByRank =  groupDataByKey(groupedKPI_Values[item], "rank");
        kpi_values[item] = groupByRank[activeRank]?.reduce((acc: any, int: any) => {
          return acc + Number(int?.actualValue?.toFixed(20));
        }, 0);
        uom = groupedKPI_Values[item]?.[0]?.uom
      });



    } catch (error) {
      headers = []
      kpi_values = []
    }

    //Group values based on scope 
    console.log('groupedScopeValues----->', kpi_values);
    console.log('kpiData----->', kpiData);

  }

  return {
    headers,
    kpi_values,
    uom,
    loading,
    error,
  };
};

export default useGetAll_KPI_TYpesBySourceTag;
