import { useContext, useMemo } from 'react';
import { useQuery, gql } from '@apollo/client';
import { AppContext } from '../store/AppContext';
import { Configuration } from '../api/queryFieldMappings';
import { GQL_paginatedEmissions_Schema_Type, getAvailableFilterTypes, getFiltersDataType, createFilters } from '../api/graphqlUtils';
import { KPI_TYPES_NAME_MAPPING } from '../utils/constants';


const getVariables = (availableFilterTypes: any, params:any, page: string, portalContext: any, timeContext: any) => {
    let variables: any = {};
    availableFilterTypes.map((filter: any) => {
        if (filter.name === 'enterprise') {
            variables = { ...variables, [filter.name]: { eq: portalContext[filter.name] || 'Enterprise1' } }
        } else if (filter.name === 'region') {
            variables = { ...variables, [filter.name]: { eq: portalContext[filter.name] } }
        } else if (filter.name === 'site') {
            variables = { ...variables, [filter.name]: { eq:params?.siteName ? params?.siteName : portalContext[filter.name] } }
        } else if (filter.name === 'time') {
            variables = { ...variables, [filter.name]: { gte: timeContext?.['start'], lte: timeContext?.['end'] } }
        }
    });
    return variables;

}

const getQuery = (page: string, params:any, portalContext: any, timeContext: any) => {
    const { Kpi_Selector } = Configuration;
    const availableFilterTypes = getAvailableFilterTypes(page, Kpi_Selector);
    const filtersWithDatatype = getFiltersDataType(availableFilterTypes);
    const filters = createFilters(availableFilterTypes);
    const variables = getVariables(availableFilterTypes, params, page, portalContext, timeContext);

    const query = gql`
    query getKpiSelectorData (${filtersWithDatatype}) {

    ${GQL_paginatedEmissions_Schema_Type}(
  
     where: {${filters}}
  
    ) {
        edges {
            node {  
                kpi_type
            }
        }
      }
  
   }`

    return { query, variables }
}

const useKPISelectorData = (page: string, params:any) => {
    let { portalContext, timeContext } = useContext(AppContext);
    const { query, variables } = getQuery(page, params, portalContext, timeContext);
    const { data, loading, error } = useQuery(query, { variables: variables });
    let nodes: Array<any> = [];
    let options: Array<any> = [];
    
    // useMemo(() => {
    // }, [loading]);
    if (!loading) {
        const { edges } = data?.paginatedEmissions;
        nodes = edges.map((item: any) => item.node);
        nodes.map((node: any) => {
            if (KPI_TYPES_NAME_MAPPING[node?.kpi_type?.toLowerCase()]) {
              if (!options.some((item: any) => item.value === node.kpi_type)) {
                options.push({
                  name: KPI_TYPES_NAME_MAPPING[node?.kpi_type?.toLowerCase()]?.dropdownOptionDisplayName,
                  value: node.kpi_type
                });
              }
            }
          })            
    }
    

    return {
        options,
        loading,
        error
    }

};

export default useKPISelectorData;