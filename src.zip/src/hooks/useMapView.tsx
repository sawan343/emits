import { useContext, useMemo } from 'react';
import { useQuery, gql } from '@apollo/client';
import { AppContext } from '../store/AppContext';
import { Configuration } from '../api/queryFieldMappings';
import { GQL_paginatedEmissions_Schema_Type, getReportingPeriod, getAvailableFilterTypes, getFiltersDataType, createFilters } from '../api/graphqlUtils';
import { groupDataByKey } from '../utils/utils';

const orderData = [
    "CO2e",
    "CH4",
    "CO2",
    "N2O",
    "R134a"
];
const getVariables = (availableFilterTypes: any, page: string, siteName: any, portalContext: any, timeContext: any) => {
    let variables: any = {};
    availableFilterTypes.map((filter: any) => {
        if (filter.name === 'kpi_category') {
            variables = { ...variables, [filter.name]: { eq: "Source Tag" } }
        } else if (filter.name === 'time') {
            variables = { ...variables, "time": { "gte": timeContext?.['start'], "lte": timeContext?.['end'] } }
        } else if (filter.name === 'reportingperiod') {
            variables = { ...variables, "reportingperiod": { eq: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()) || filter.defaultValue } }
        } else if (filter.name === 'site') {
            variables = { ...variables, [filter.name]: { eq: siteName || portalContext?.asset } }
        }
    });
    return variables;

}

const getQuery = (page: string, siteName: any, portalContext: any, timeContext: any) => {
    const { Map_View } = Configuration;
    const availableFilterTypes = getAvailableFilterTypes(page, Map_View);
    const filtersWithDatatype = getFiltersDataType(availableFilterTypes);
    const filters = createFilters(availableFilterTypes);
    const variables = getVariables(availableFilterTypes, page, siteName, portalContext, timeContext);

    const query = gql`
    query getMapViewLatLongData (${filtersWithDatatype}) {

    ${GQL_paginatedEmissions_Schema_Type}(
  
     where: {${filters}}
     order: { time: DESC}
  
    ) {
        edges {
            node {  
                asset_name
                site
                latitude
                longitude
                limitCheckStatus
                sourcetag_displayname
                kpi_type
                actualValue
                source_displayname
                scope_displayname
                source_group
                time
                uom
            }
        }
      }
  
   }`

    return { query, variables }
}

const useMapView = (page: string, siteName: any, siteDetailFilter:any) => {
    let { portalContext, timeContext } = useContext(AppContext);
    const { query, variables } = getQuery(page, siteName, portalContext, timeContext);
    const { data, loading, error } = useQuery(query, { variables: variables });
    let assetsLatLong: Array<any> = [];
    let markersWithTop3Emitters: any = {};

    // useMemo(() => {

    // }, [loading]);
    if (!loading) {
        const { edges } = data?.paginatedEmissions;
        let nodes = edges.map((item: any) => item.node);
        
        if(siteDetailFilter?.length > 0) {
            nodes = nodes?.filter((item:any) =>  siteDetailFilter.indexOf(item?.scope_displayname) >=0  );
        }

        if(siteDetailFilter?.length > 0) {
            nodes = nodes?.filter((item:any) =>  siteDetailFilter.indexOf(item?.source_displayname) >=0 );
        }

        let groupDataByForMarker: string = 'sourcetag_displayname';
        let assetTypeForMarkerTooltip: string = 'kpi_type';

        const groupedAssetsLatLong = groupDataByKey(nodes, groupDataByForMarker);


        Object.keys(groupedAssetsLatLong).map((item: any) => {
            // get the last hour data - latitude, longitude to plot Marker, limitCheckStatus to get good or bad data for marker color 
            assetsLatLong.push(groupedAssetsLatLong[item].reduce((a: any, b: any) => (a.time > b.time ? a : b)));
            const gasesGroupBy = groupDataByKey(groupedAssetsLatLong[item], assetTypeForMarkerTooltip);
            const latestGas: any = []
            Object.keys(gasesGroupBy).forEach((gas: any) => {
                const singleGas: any = gasesGroupBy[gas].reduce((a: any, b: any) => (a.time > b.time ? a : b));
                latestGas.push({
                    kpi_type: singleGas.kpi_type,
                    actualValue: singleGas.actualValue,
                    uom: singleGas.uom,
                });
            })
            latestGas.sort(function (a: any, b: any) {
                return orderData.indexOf(a.kpi_type) - orderData.indexOf(b.kpi_type)
            });
            markersWithTop3Emitters[item] = latestGas;

        });
        console.log('groupedAssetsLatLong', groupedAssetsLatLong);
        console.log('assetsLatLong', assetsLatLong);
        console.log('markersWithTop3Emitters', markersWithTop3Emitters);
    }

    return {
        assetsLatLong,
        markersWithTop3Emitters,
        loading,
        error
    }

};

export default useMapView;