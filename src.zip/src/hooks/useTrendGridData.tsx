// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

import React from 'react';
import { useContext } from 'react';
import { useQuery, gql } from '@apollo/client';
import { Configuration } from '../api/queryFieldMappings';
import { AppContext } from '../store/AppContext';
import { graphQlUrl, authToken, tenantId } from '../api/config';
import { getReportingPeriod, GQL_paginatedEmissions_Schema_Type, getAvailableFilterTypes, getFiltersDataType, createFilters } from '../api/graphqlUtils';
import { TREND_KPI_TYPE_MAPPING } from '../utils/constants';
import { groupDataByKey } from '../utils/utils';
const { v4: uuidv4 } = require('uuid');

const getVariables = (availableFilterTypes: any, portalContext: any, timeContext: any, level: any, nodeName: any, siteName: any) => {

  let nodeParentLength = nodeName?.parent ? nodeName.parent.length : 1;
  let variables: any = {};


  availableFilterTypes.map((filter: any) => {

    if (filter.name === 'assettype_name') {
      variables = { ...variables, [filter.name]: { eq: 'Site' } }
    } else if (filter.name === 'asset_name') {
      variables = { ...variables, [filter.name]: { eq: siteName || portalContext?.asset } }
    } else if (level == 0 && filter.name === 'kpi_category') {
      variables = { ...variables, [filter.name]: { eq: "Scope" } }
    } else if (level == 1 && filter.name === 'kpi_category') {
      variables = { ...variables, [filter.name]: { eq: "Source" } }
    } else if (level == 2 && filter.name === 'kpi_category') {
      variables = { ...variables, [filter.name]: { eq: "Subsource" } }
    } else if (level == 3 && filter.name === 'kpi_category') {
      variables = { ...variables, [filter.name]: { eq: "Source Group" } }
    } else if (level == 1 && filter.name === 'scope_displayname') {
      variables = { ...variables, [filter.name]: { eq: nodeName.parent[nodeParentLength - 1] } }
    } else if (level == 2 && filter.name === 'scope_displayname') {
      variables = { ...variables, [filter.name]: { eq: nodeName.parent[nodeParentLength - 2] } }
    } else if (level == 3 && filter.name === 'scope_displayname') {
      variables = { ...variables, [filter.name]: { eq: nodeName.parent[nodeParentLength - 3] } }
    } else if (level == 2 && filter.name === 'source_displayname') {
      variables = { ...variables, [filter.name]: { eq: nodeName.parent[nodeParentLength - 1] } }
    } else if (level == 3 && filter.name === 'source_displayname') {
      variables = { ...variables, [filter.name]: { eq: nodeName.parent[nodeParentLength - 2] } }
    } else if (level == 3 && filter.name === 'subsource_displayname') {
      variables = { ...variables, [filter.name]: { eq: nodeName.parent[nodeParentLength - 1] } }
    } else if (filter.name === 'time') {
      variables = { ...variables, "time": { "gte": timeContext?.['start'], "lte": timeContext?.['end'] } }
    } else if (filter.name === 'reportingperiod') {
      variables = { ...variables, "reportingperiod": { eq: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()) || "Daily" } }
    }
  });
  return variables;

}

const getVariablesUnitLevel = (availableFilterTypes: any, portalContext: any, timeContext: any, siteName: string) => {
  let variables: any = {};
  availableFilterTypes.map((filter: any) => {
    if (filter.name === 'site') {
      variables = { ...variables, [filter.name]: { eq: siteName } }
    } else if (filter.name === 'kpi_category') {
      variables = { ...variables, [filter.name]: { eq: 'Source Tag' } }
    } else if (filter.name === 'kpi_type') {
      variables = { ...variables, [filter.name]: { in: ["CH4", "CO2e", "CO2", "R134a", "N2O"] } }
    } else if (filter.name === 'process_unit') {
      variables = { ...variables, [filter.name]: { neq: null } }
    } else if (filter.name === 'time') {
      variables = { ...variables, "time": { "gte": timeContext?.['start'], "lte": timeContext?.['end'] } }
    } else if (filter.name === 'reportingperiod') {
      variables = { ...variables, "reportingperiod": { eq: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()) || "Daily" } }
    }
  });
  return variables;
}

const getAddedValues = (data: Array<any>) => {
  const nodes = data?.map((item: any) => item?.values);
  let finalObj: any = {};
  nodes.map((node: any) => {
    if (finalObj[node?.name]) {
      finalObj = { ...finalObj, [node?.name]: finalObj[node?.name] + node?.value }
    } else {
      finalObj = { ...finalObj, [node?.name]: node?.value }
    }
  });

  finalObj = { ...finalObj, 'Emissions Sources': data?.[0]?.name };
  return finalObj;
}

const getHeaders = (edges: Array<any>) => {
  const nodes = edges.map((item: any) => item?.node?.kpi_type).filter((value: any, index: any, self: any) => self.indexOf(value) === index);
  const headers = nodes.map((kpi: any) => {
    const uom = edges.find((item: any) => item?.node?.kpi_type === kpi)?.node?.uom;
    return {
      name: `${TREND_KPI_TYPE_MAPPING[kpi?.toLowerCase()]?.displayName} (${uom?.toUpperCase()})` || kpi,
      order: TREND_KPI_TYPE_MAPPING[kpi?.toLowerCase()]?.order,
      field: kpi
    }
  })
  return headers.sort((a: any, b: any) => a.order > b.order ? 1 : -1);
}


const getLevelBasedValue = (level: any, data: any, previousNode: any) => {
  const headers = getHeaders(data?.paginatedEmissions?.edges);
  console.log(headers);

  switch (level) {
    case 0:
      const scopeTypes = data?.paginatedEmissions?.edges.map((item: any) => item?.node?.scope_displayname
      ).filter((value: any, index: any, self: any) => self.indexOf(value) === index);
      const nodes: any = scopeTypes.map((scopeItem: any, index: any) => {
        let collectedData: any = [];
        let rawData: any = [];
        data?.paginatedEmissions?.edges.forEach((item: any) => {
          if (scopeItem == item?.node?.scope_displayname) {
            let nodeName = item?.node?.kpi_type;
            let valueKey = item?.node?.actualValue
            //rawData.push({ name: scopeItem, values: { [nodeName]: valueKey, "Emissions Sources": scopeItem } })
            rawData.push({ name: scopeItem, values: { name: nodeName, value: valueKey } })
          }
        });

        // let val: any = [];
        // rawData.forEach((element: any) => {
        //   val.push(element.values)
        // });
        let finalObj = getAddedValues(rawData);

        // for (let i = 0; i < val.length; i++) {
        //   Object.assign(finalObj, val[i]);
        // }
        console.log({rawData})
        let dataObj = { key:rawData[0].name.replaceAll(' ',''), uid:rawData[0].name+1, parent: [rawData[0].name], name: rawData[0].name, leaf: false, data: finalObj, level: 0 }
        return dataObj;
      })
      return { headers, nodes };
      break;

    case 1:
      let level1Items = data?.paginatedEmissions?.edges.map((item: any) => item?.node?.source_displayname
      ).filter((value: any, index: any, self: any) => self.indexOf(value) === index);
      const level1Nodes: any = level1Items.map((sourceItem: any, index: any) => {
        let collectedData: any = [];
        let rawData: any = [];
        data?.paginatedEmissions?.edges.forEach((item: any) => {
          if (sourceItem == item?.node?.source_displayname) {
            let nodeName = item?.node?.kpi_type;
            let valueKey = item?.node?.actualValue
            rawData.push({ name: sourceItem, values: { name: nodeName, value: valueKey } })
          }
        });
        let finalObj = getAddedValues(rawData);
        
        let dataObj = { key: rawData[0].name.replaceAll(' ',''), uid:rawData[0].name+2, parent: [...previousNode, rawData[0].name], name: rawData[0].name, leaf: false, data: finalObj, level: 1 }
        return dataObj;
      })
      return level1Nodes
      break;

    case 2:
      let level2Items = data?.paginatedEmissions?.edges.map((item: any) => item?.node?.subsource_displayname
      ).filter((value: any, index: any, self: any) => self.indexOf(value) === index);
      const level2Nodes: any = level2Items.map((sourceItem: any, index: any) => {
        let collectedData: any = [];
        let rawData: any = [];
        data?.paginatedEmissions?.edges.forEach((item: any) => {
          if (sourceItem == item?.node?.subsource_displayname) {
            let nodeName = item?.node?.kpi_type;
            let valueKey = item?.node?.actualValue
            rawData.push({ name: sourceItem, values: { name: nodeName, value: valueKey } })
          }
        });
        let finalObj = getAddedValues(rawData);
        let dataObj = { key: rawData[0].name.replaceAll(' ',''), uid:rawData[0].name+3, parent: [...previousNode, rawData[0].name], name: rawData[0].name, leaf: false, data: finalObj, level: 2 }
        return dataObj;
      })
      return level2Nodes
      break;

    case 3:
      let level3Items = data?.paginatedEmissions?.edges.map((item: any) => item?.node?.sourcegroup_displayname

      ).filter((value: any, index: any, self: any) => self.indexOf(value) === index);
      const level3Nodes: any = level3Items.map((sourceItem: any, index: any) => {
        let collectedData: any = [];
        let rawData: any = [];
        data?.paginatedEmissions?.edges.forEach((item: any) => {
          if (sourceItem == item?.node?.sourcegroup_displayname
          ) {
            let nodeName = item?.node?.kpi_type;
            let valueKey = item?.node?.actualValue
            rawData.push({ name: sourceItem, values: { name: nodeName, value: valueKey } })
          }
        });
        let finalObj = getAddedValues(rawData);
        let dataObj = { key: rawData[0].name.replaceAll(' ',''), uid:rawData[0].name+4, parent: [...previousNode, rawData[0].name], name: rawData[0].name, leaf: true, data: finalObj, level: 3 }
        return dataObj;
      })
      return level3Nodes
      break;

    default:
      break;
  }
}

const getUnitBasedValue = (level: any, data: any, previousNode: any) => {
  const headers = getHeaders(data?.paginatedEmissions?.edges);
  console.log(headers);

  const unitTypes = data?.paginatedEmissions?.edges.map((item: any) => item?.node?.process_unit
  ).filter((value: any, index: any, self: any) => self.indexOf(value) === index);
  const nodes: any = unitTypes.map((unitItem: any, index: any) => {
    let children: any = [];
    let rawData: any = [];
    data?.paginatedEmissions?.edges.forEach((item: any) => {
      if (unitItem == item?.node?.process_unit) {
        let nodeName = item?.node?.kpi_type;
        let valueKey = item?.node?.actualValue
        children.push({ name: item?.node?.sourcetag_displayname, value: item?.node?.actualValue, kpi_type: item?.node?.kpi_type })
        rawData.push({ name: unitItem, values: { name: nodeName, value: valueKey }, children: children })
      }
    });
    let finalObj = getAddedValues(rawData);
    let unitsData = getSourceTagNodes(rawData, {})
    let dataObj = { key: rawData[0].name.replaceAll(' ',''), uid:rawData[0].name+1, parent: [rawData[0].name], name: rawData[0].name, leaf: false, data: finalObj, level: 0, children: unitsData }
    return dataObj;
  })
  console.log({ nodes })
  return { headers, nodes };
}

const getSourceTagNodes = (data: any, previousNode: any) => {
  if (data.length > 0) {
    let level1Items = data[0].children.map((item: any) => item?.name
    ).filter((value: any, index: any, self: any) => self.indexOf(value) === index);
    console.log({ level1Items })
    const level1Nodes: any = level1Items.map((sourceItem: any, index: any) => {
      let collectedData: any = [];
      let rawData: any = [];
      data[0].children.forEach((item: any) => {
        if (sourceItem == item?.name) {
          let nodeName = item?.name;
          let valueKey = item?.value
          let kpi_type = item?.kpi_type
          rawData.push({ name: nodeName, values: { name: kpi_type, value: valueKey } })
        }
      });
      let finalObj = getAddedValues(rawData);
      let dataObj = { key: rawData[0].name.replaceAll(' ',''), name: rawData[0].name, leaf: true, data: finalObj, level: 1 }
      return dataObj;
    })
    return level1Nodes
  }

}

const TrendPageData = async (level: any, nodeName: any, portalContext: any, timeContext: any, siteName: any, isUnitLevel: any, siteDetailFilter:any) => {
  console.log("query requests")
  const { Trend_Grid, Unit_Level_TrendGrid } = Configuration;
  let filtersWithDatatype: any, filters: any, variables: any;

  if (!isUnitLevel) {
    const availableFilterTypes = getAvailableFilterTypes("level" + level, Trend_Grid);
    filtersWithDatatype = getFiltersDataType(availableFilterTypes);
    filters = createFilters(availableFilterTypes);
    variables = getVariables(availableFilterTypes, portalContext, timeContext, level, nodeName, siteName);
  }

  if (isUnitLevel) {
    const availableFilterTypes = getAvailableFilterTypes("level" + level, Unit_Level_TrendGrid);
    filtersWithDatatype = getFiltersDataType(availableFilterTypes);
    filters = createFilters(availableFilterTypes);
    variables = getVariablesUnitLevel(availableFilterTypes, portalContext, timeContext, siteName);
  }
  const query = `
  query getTrendGridData (${filtersWithDatatype}) {
   ${GQL_paginatedEmissions_Schema_Type}(
     where: {${filters}}
     order: { time: ASC }
   ) {
     totalCount
     edges {
       node {
         kpi_type
         kpi_category
         kpi_displayname
         scope_displayname
         source_displayname
         subsource_displayname
         sourcegroup_displayname
         sourcetag_displayname
         process_unit
         time
         itemName
         reportingStartTime
         reportingEndTime
         enterprise
         region
         site
         asset_name
         assettype_name
         actualValue
         uom
       }
       cursor
     }
     pageInfo {
       hasNextPage
     }
   }
 }`
  let dataValues: any;
  let apiCall = await fetch(graphQlUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': authToken ? authToken : '',
      'tenantId': tenantId ? tenantId : ''
    },

    body: JSON.stringify({
      variables: variables,
      query
    }),
  })

  let results = await apiCall.json();
  if (results) {
    dataValues = isUnitLevel ? getUnitBasedValue(level, results.data, nodeName.parent) : getLevelBasedValue(level, results.data, nodeName.parent)
  };

  // if (dataValues?.headers) {
  //   const orderData = [
  //     "CO2e",
  //     "CH4",
  //     "CO2",
  //     "N2O",
  //     "R134a"
  //   ];
  //   const headerArr: any = [...dataValues?.headers];
  //   const newOrderArr: any = [];
  //   orderData.forEach((item) => {
  //     const index = headerArr.indexOf(item);
  //     if (index >= 0) {
  //       newOrderArr.push(headerArr[index]);
  //       headerArr.splice(index, 1);
  //     }
  //   });
  //   dataValues = {
  //     ...dataValues,
  //     headers: [...newOrderArr, ...headerArr]
  //   };
  //   let nodes: any = [...dataValues?.nodes];
  //   nodes = nodes.map((item: any) => {
  //     const objGasData: any = { ...item.data };
  //     let newOrderArr: any = {};

  //     orderData.forEach((item) => {
  //       const val = objGasData[item];
  //       if (isNaN(val) === false) {
  //         newOrderArr = { [item]: val, ...newOrderArr };
  //         delete objGasData[item];

  //       }
  //     });

  //     item.data = { ...newOrderArr, ...objGasData };
  //     return item;
  //   })
  // }

  if(level === 0) {
    if(siteDetailFilter?.length > 0) {
      dataValues = {
        ...dataValues,
        nodes: dataValues?.nodes?.filter((item:any) => siteDetailFilter?.indexOf(item?.name) >=0  )
      }
    }
  }

  if(level === 1) {
    if(siteDetailFilter?.length > 0) {
      dataValues = dataValues?.filter((item:any) => siteDetailFilter?.indexOf(item?.name) >=0  );
    }
  }

  dataValues?.nodes?.sort((a: any, b: any) => a.name > b.name ? 1 : -1);
  return { dataValues };

}


export default TrendPageData;
