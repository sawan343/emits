import { useContext } from 'react';
import { useQuery, gql } from '@apollo/client';
import { AppContext } from '../store/AppContext';
import { Configuration } from '../api/queryFieldMappings';
import { GQL_paginatedEmissions_Schema_Type, getReportingPeriod, getAvailableFilterTypes, getFiltersDataType, createFilters } from '../api/graphqlUtils';
import { groupDataByKey } from '../utils/utils';


const getVariables = (availableFilterTypes: any, page: string, params: any, portalContext: any, timeContext: any) => {
    let variables: any = {};
    availableFilterTypes.map((filter: any) => {
        if (filter.name === 'assettype_name') {
            if (page === 'enterprise') {
                variables = { ...variables, [filter.name]: { in: ["Region", "Site"] } }
            }
            if (page === 'region') {
                variables = { ...variables, [filter.name]: { in: ["Site"] } }
            }
        } else if (filter.name === 'kpi_category') {
            if (page === 'enterprise') {
                variables = { ...variables, [filter.name]: { eq: "Total" } }
            }
            if (page === 'region') {
                variables = { ...variables, [filter.name]: { eq: "Source" } }
            }
           
        } else if (filter.name === 'kpi_type') {
            variables = { ...variables, [filter.name]: { eq: "CO2e" } }
        } else if (filter.name === 'time') {
            variables = { ...variables, "time": { "gte": timeContext?.['start'], "lte": timeContext?.['end'] } }
        } else if (filter.name === 'reportingperiod') {
            variables = { ...variables, "reportingperiod": { eq: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()) || filter.defaultValue } }
        } else if (filter.name === 'enterprise') {
            variables = { ...variables, [filter.name]: { eq: portalContext[filter.name] || 'Enterprise1' } }
        } else if (filter.name === 'region') {
            variables = { ...variables, [filter.name]: { eq: params?.redirect ? params?.redirect : portalContext[filter.name] } }
        }
    });
    return variables;

}

const getQuery = (page: string, params: any, portalContext: any, timeContext: any) => {
    const { Asset_Lat_Long } = Configuration;
    const availableFilterTypes = getAvailableFilterTypes(page, Asset_Lat_Long);
    const filtersWithDatatype = getFiltersDataType(availableFilterTypes);
    const filters = createFilters(availableFilterTypes);
    const variables = getVariables(availableFilterTypes, page, params, portalContext, timeContext);

    const query = gql`
    query getAssetLatLongData (${filtersWithDatatype}) {

    ${GQL_paginatedEmissions_Schema_Type}(
  
     where: {${filters}}
     order: { time: DESC}
  
    ) {
        edges {
            node {  
                assettype_name
                asset_name              
                enterprise
                region
                site
                latitude
                longitude
                limitCheckStatus
                time
                kpi_type
                actualValue
                uom
                source_displayname
            }
        }
      }
  
   }`

    return { query, variables }
}

const useAssetLatLongData = (page: string, params: any) => {
    let { portalContext, timeContext } = useContext(AppContext);
    const { query, variables } = getQuery(page, params, portalContext, timeContext);
    const { data, loading, error } = useQuery(query, { variables: variables });
    let assetsLatLong: Array<any> = [];
    let markersWithTop3Emitters: any = {};

    if (!loading) {
        const { edges } = data?.paginatedEmissions;
        if(edges.length < 1) {
            return {
                assetsLatLong,
                markersWithTop3Emitters,
                loading,
                error
            }
        }
        const nodes = edges.map((item: any) => item.node);
        let groupDataByForMarker: string = '';
        let assetTypeForMarkerTooltip: string = '';

            if (page === 'enterprise') {
                groupDataByForMarker = 'region';
                assetTypeForMarkerTooltip = 'site';
            }
            if (page === 'region') {
                groupDataByForMarker = 'site';
                assetTypeForMarkerTooltip = 'source_displayname';
            }

            const groupedAssetsLatLong = nodes.reduce((group: any, arr: any) => {
                group[arr[groupDataByForMarker]] = group[arr[groupDataByForMarker]] ?? [];
                group[arr[groupDataByForMarker]].push(arr);
                return group;
            }, {});

            Object.keys(groupedAssetsLatLong).map((item: any) => {
                // get the last hour data - latitude, longitude to plot Marker, limitCheckStatus to get good or bad data for marker color 
                assetsLatLong.push(groupedAssetsLatLong[item].reduce((a: any, b: any) => (a.time > b.time ? a : b)));

                // get the list of sites with actualValue for each marker to show top 3 emitters
                let markerList: Array<any> = [];
                if (page === 'enterprise') {
                    groupedAssetsLatLong[item].map((node: any) => {
                        let sum: number = 0;
                        if (node?.assettype_name?.toLowerCase() === assetTypeForMarkerTooltip) {
                            sum = sum + node?.actualValue;
                            if (!markerList.find((item: any) => item.asset_name === node?.asset_name)) {
                                markerList.push({
                                    asset_name: node?.asset_name,
                                    actualValue: node?.actualValue,
                                    kpi_type: node?.kpi_type,
                                    uom: node?.uom
                                })
                            }
                            else {
                                const inputData = markerList.find((item: any) => item?.asset_name === node?.asset_name);
                                inputData['actualValue'] = sum;
                            }
                        }
                    });
                    markerList = markerList?.sort()?.reverse()?.slice(0, 3);
                }
                if (page === 'region') {
                    let groupBySource =   groupDataByKey(groupedAssetsLatLong[item], assetTypeForMarkerTooltip);
                    let sumOfEachSource:any = []; 
                    Object.keys(groupBySource)?.forEach((element:any, index:number) => {
                      const sum =   groupBySource[element]?.reduce((acc:any, current:any) => {
                            return acc + current?.actualValue
                        }, 0);
                      const firstValue = {
                        uom: groupBySource[element][0]?.uom,
                        asset_name: element,
                        kpi_type: groupBySource[element][0]?.kpi_type,

                      }
                        sumOfEachSource?.push({
                            actualValue:  sum,
                            ...firstValue
                        })
                    });
                    markerList = sumOfEachSource?.sort((a: any, b: any) =>  b.actualValue - a.actualValue)?.slice(0, 3);
                }
                markersWithTop3Emitters = { ...markersWithTop3Emitters, [item]: markerList };
            });

            console.log('groupedAssetsLatLong', groupedAssetsLatLong);
            console.log('assetsLatLong', assetsLatLong);
            console.log('markersWithTop3Emitters', markersWithTop3Emitters);
        }
        return {
            assetsLatLong,
            markersWithTop3Emitters,
            loading,
            error
        }
};

export default useAssetLatLongData;