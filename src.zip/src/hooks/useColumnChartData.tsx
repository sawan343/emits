import { Configuration } from '../api/queryFieldMappings';
import { GQL_paginatedEmissions_Schema_Type, getAvailableFilterTypes, getFiltersDataType, createFilters, getReportingPeriod } from '../api/graphqlUtils';
import { COLUMN_CHART_HIERARCHY_MAPPING, CHART_COLORS, COLUMN_CHART_HIERARCHY_MAPPING_UNIT_LEVEL } from '../utils/constants';
import { groupDataByKey, getLocaleDate, getLocaleTime, getLocaleMonth } from '../utils/utils';
import { graphQlUrl, authToken, tenantId } from '../api/config';


const getVariables = (availableFilterTypes: any, portalContext: any, timeContext: any, siteName: string) => {
    let variables: any = {};
    availableFilterTypes.map((filter: any) => {
        if (filter.name === 'assettype_name') {
            variables = { ...variables, [filter.name]: { eq: 'Site' } }
        } else if (filter.name === 'asset_name' || filter.name === 'site') {
            variables = { ...variables, [filter.name]: { eq: siteName || portalContext.site } }
        } else if (filter.name === 'kpi_category') {
            variables = { ...variables, [filter.name]: { eq: COLUMN_CHART_HIERARCHY_MAPPING[0].kpi_category } }
        } else if (filter.name === 'kpi_type') {
            variables = { ...variables, [filter.name]: { eq: "CO2e" } }
        } else if (filter.name === 'time') {
            variables = { ...variables, "time": { "gte": timeContext?.['start'], "lte": timeContext?.['end'] } }
        } else if (filter.name === 'reportingperiod') {
            variables = { ...variables, "reportingperiod": { eq: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()) || filter.defaultValue } }
        } else {
            variables = { ...variables, [filter.name]: { eq: filter.defaultValue } }
        }
    });
    //variables = {... variables, scope_displayname : {eq: 'Scope 1'}}
    return variables;
}

const getVariablesUnitLevel = (availableFilterTypes: any, portalContext: any, timeContext: any, siteName: string) => {
    let variables: any = {};
    availableFilterTypes.map((filter: any) => {
        if (filter.name === 'site') {
            variables = { ...variables, [filter.name]: { eq: siteName || portalContext.site } }
        } else if (filter.name === 'kpi_category') {
            variables = { ...variables, [filter.name]: { eq: 'Source Tag' } }
        } else if (filter.name === 'kpi_type') {
            variables = { ...variables, [filter.name]: { eq: "CO2e" } }
        } else if (filter.name === 'process_unit') {
            variables = { ...variables, [filter.name]: { neq: null } }
        } else if (filter.name === 'time') {
            variables = { ...variables, "time": { "gte": timeContext?.['start'], "lte": timeContext?.['end'] } }
        } else if (filter.name === 'reportingperiod') {
            variables = { ...variables, "reportingperiod": { eq: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()) || filter.defaultValue } }
        }
    });
    return variables;
}

const getQuery = (page: string, portalContext: any, timeContext: any, siteName: any, isUnitLevel: boolean, optionalFilters?: Array<any>) => {
    const { Column_Chart, Unit_Level_Column_Trend } = Configuration;
    const config = isUnitLevel ? Unit_Level_Column_Trend : Column_Chart;
    const availableFilterTypes = getAvailableFilterTypes(page, config, optionalFilters);
    const filtersWithDatatype = getFiltersDataType(availableFilterTypes);
    const filters = createFilters(availableFilterTypes);
    const variables = isUnitLevel ? getVariablesUnitLevel(availableFilterTypes, portalContext, timeContext, siteName) : getVariables(availableFilterTypes, portalContext, timeContext, siteName);
    const node = isUnitLevel ? `time actualValue kpi_type kpi_category asset_name sourcetag_displayname process_unit sourcetag_displayname` :
        `time actualValue kpi_type kpi_category asset_name scope_displayname source_displayname subsource_displayname sourcegroup_displayname`;

    const query = `
    query getColumnChartData (${filtersWithDatatype}) {

    ${GQL_paginatedEmissions_Schema_Type}(
  
     where: {${filters}}
     order: { time: ASC }
  
    ) {
        edges {
            node {  
                ${node}
            }
        }
      }
  
   }`

    return { query, variables }
}

const getFiltersForSelectedLevel = (selectedCategory: any) => {
    let optionalVariables: any = {};
    let optionalFilters: Array<any> = [];
    selectedCategory?.map((item: any) => {
        const displayName = COLUMN_CHART_HIERARCHY_MAPPING?.find((category: any) => category?.level === item?.level)?.displayName;
        optionalVariables = { ...optionalVariables, [displayName]: { eq: item?.displayName } };
        optionalFilters.push({ name: displayName, filterVariableType: 'StringOperationFilterInput', isFilterVariable: true, isRequiredField: false, defaultValue: "" });
    });

    const lastLevelFromSelectedLevels = selectedCategory?.reduce((prev: any, current: any) => (prev.level > current.level) ? prev : current);
    const category = COLUMN_CHART_HIERARCHY_MAPPING?.find((item: any) => item?.level === (lastLevelFromSelectedLevels.level + 1))?.kpi_category;
    optionalVariables = { ...optionalVariables, kpi_category: { eq: category } }
    console.log('filters', optionalVariables);
    return { lastLevelFromSelectedLevels, optionalVariables, optionalFilters };
}

const GetColumnChartData = async (query: any, variables: any) => {
    let apiCall = await fetch(graphQlUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': authToken ? authToken : '',
            'tenantId': tenantId ? tenantId : ''
        },
        body: JSON.stringify({
            variables: variables,
            query: query
        }),
    })

    let results = await apiCall.json()
    return results;
}

const getSeries = (nodes: Array<any>, displayName: string, currentLevel: any, isUnitLevel: boolean, currentParentTree: any) => {
    let series: Array<any> = [];
    //Group values based on scope 
    const groupedData = groupDataByKey(nodes, displayName);
    console.log("currentParentTree : ", currentParentTree)
    series = Object.keys(groupedData).map((item: any) => {
        return {
            name: item,
            type: "column",
            data: [],
            color: CHART_COLORS?.[item],
            borderWidth: 2,
            timeSeries: [],
            parent: [...currentParentTree, item],
            level: currentLevel,
            uid:item+currentLevel
        }
    });

    if (isUnitLevel) {
        series.map((categories: any) => {
            nodes.map((node: any) => {
                if (node?.[displayName] === categories.name) {
                    const index = categories.timeSeries?.indexOf(node?.time);
                    const value = index > -1 && categories.data?.[index] ? categories.data?.[index] + node?.actualValue : node?.actualValue;
                    if (index > -1) {
                        categories.data[index] = value;
                    } else {
                        categories.data?.push(value);
                        categories.timeSeries.push(node?.time);
                    }
                }
            });
        });
        return series;
    }

    series.map((categories: any) => {
        nodes.map((node: any) => {
            if (node?.[displayName] === categories?.name) {
                categories?.data?.push(node?.actualValue);
                categories?.timeSeries?.push(node?.time);
            }
        });
    });

    return series;
}

const getXAxisTitle = (values: any, variables: any) => {
    const date = new Date(values?.[0]);
    if (variables?.reportingperiod?.eq === "Daily" || variables?.reportingperiod?.eq === "Weekly") {
        return `${getLocaleMonth(values?.[0], { month: "long" })} ${date.getFullYear()}`;
    }
    if (variables?.reportingperiod?.eq === "Hourly") {
        return `${getLocaleDate(values?.[0], { day: '2-digit' })} ${getLocaleMonth(values?.[0], { month: "long" })} ${date.getFullYear()}`;
    }
    if (variables?.reportingperiod?.eq === "Monthly") {
        return `${date.getFullYear()}`;
    }
    return '';
};

const getXAxis = (values: any, variables: any) => {
    return values?.map((item: any) => {
        if (variables?.reportingperiod?.eq === "Daily") {
            return getLocaleDate(item, { day: '2-digit' });
        }
        if (variables?.reportingperiod?.eq === "Hourly") {
            return getLocaleTime(item, { hour: 'numeric', minute: 'numeric', hour12: false });
        }
        if (variables?.reportingperiod?.eq === "Monthly") {
            return getLocaleMonth(item, { month: "long" });
        }
        return new Date(item);
    });
};

const ColumnChartData = async (selectedCategory: any, portalContext: any, timeContext: any, siteName: string, isUnitLevel: boolean, siteDetailFilter:any = {}) => {
    let query: any, variables: any;
    let currentLevel: number = 1;
    let xAxis: Array<any> = [];
    let xAxisTitle: any = '';
    let currentParentTree: any = [];

    if (selectedCategory?.length > 0 && !isUnitLevel) {
        const { lastLevelFromSelectedLevels, optionalVariables, optionalFilters } = getFiltersForSelectedLevel(selectedCategory);
        const selectedLevelFiltersAndQuery = getQuery('', portalContext, timeContext, siteName, isUnitLevel, optionalFilters);
        query = selectedLevelFiltersAndQuery?.query;
        variables = { ...selectedLevelFiltersAndQuery?.variables, ...optionalVariables };
        currentLevel = lastLevelFromSelectedLevels?.level + 1;
        selectedCategory.map((item: any) => {
            currentParentTree.push(item.displayName);
            return currentParentTree;
        });
    } else {
        const queryAndVariables = getQuery('', portalContext, timeContext, siteName, isUnitLevel);
        query = queryAndVariables?.query;
        variables = queryAndVariables?.variables;
    }

    const data = await GetColumnChartData(query, variables);
    const { edges } = data?.data?.paginatedEmissions;
    let nodes = edges?.map((item: any) => item.node);
    console.clear();
    console.log("siteDetailFilter", siteDetailFilter);
    if(siteDetailFilter?.length > 0) {
        nodes = nodes?.filter((item:any) =>  siteDetailFilter.indexOf(item?.scope_displayname) >=0 );
    }

    if( selectedCategory?.length === 1) {
        if(siteDetailFilter?.length > 0) {
            nodes = nodes?.filter((item:any) => siteDetailFilter.indexOf(item?.source_displayname) >=0 );
        }
    }
    const mapping = isUnitLevel ? COLUMN_CHART_HIERARCHY_MAPPING_UNIT_LEVEL : COLUMN_CHART_HIERARCHY_MAPPING;


    if (selectedCategory?.length > 0 && isUnitLevel) {
        const lastLevelFromSelectedLevels = selectedCategory.reduce((prev: any, current: any) => (prev.level > current.level) ? prev : current);
        const selectedUnit = COLUMN_CHART_HIERARCHY_MAPPING_UNIT_LEVEL.find((item: any) => item?.level === lastLevelFromSelectedLevels?.level);
        nodes = nodes.filter((item: any) => item?.[selectedUnit?.displayName] === lastLevelFromSelectedLevels?.displayName);
        currentLevel = lastLevelFromSelectedLevels?.level + 1;
        selectedCategory.map((item: any) => {
            currentParentTree.push(item.displayName);
            return currentParentTree;
        });
    }

    const currentValue: any = mapping.find((item: any) => item?.level === currentLevel);
    const { displayName, stacking } = currentValue;

    const series: Array<any> = getSeries(nodes, displayName, currentLevel, isUnitLevel, currentParentTree)?.sort((a: any, b: any) => a.name > b.name ? 1 : -1);

    //Time is xAxis and its will same for all the series
    xAxis = getXAxis(series[0]?.timeSeries, variables);

    xAxisTitle = getXAxisTitle(series[0]?.timeSeries, variables);

    console.log('series', series);
    console.log('xAxis', xAxis);

    return {
        series,
        xAxis,
        xAxisTitle,
        stacking
    }

};

export default ColumnChartData;