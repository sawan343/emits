import { useContext } from 'react';
import { useQuery, gql } from '@apollo/client';
import { Configuration } from '../api/queryFieldMappings';
import { GQL_paginatedEmissions_Schema_Type, getReportingPeriod, getAvailableFilterTypes, getFiltersDataType, createFilters } from '../api/graphqlUtils';
import { AppContext } from '../store/AppContext';
import { groupDataByKey, getLastRankDataFromData, getActiveRankTime, getHighestValueEntry } from '../utils/utils';


const getVariables = (availableFilterTypes: any, page: string, portalContext: any, timeContext: any, siteName: string, tag: string) => {
    let variables: any = {};
    availableFilterTypes.map((filter: any) => {
        if (filter.name === 'kpi_category') {
            variables = { ...variables, [filter.name]: { eq: filter.defaultValue } }
        } else if (filter.name === 'kpi_type') {
            variables = { ...variables, [filter.name]: { in: filter.defaultValue } }
        }
        else if (filter.name === 'site') {
            variables = { ...variables, [filter.name]: { eq: siteName || portalContext?.asset } }
        } else if (filter.name === 'time') {
            variables = { ...variables, "time": { "gte": timeContext?.['start'], "lte": timeContext?.['end'] } }
        } else if (filter.name === 'reportingperiod') {
            if (tag === 'rank')
                variables = { ...variables, [filter.name]: { eq: filter.defaultValue } }
            else
                variables = { ...variables, [filter.name]: { eq: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()) || filter.defaultValue } }
        } else {
            variables = { ...variables, [filter.name]: { eq: portalContext[filter.name] ? portalContext[filter.name] : filter.defaultValue } }
        }
    });
    return variables;
}

const getQuery = (page: string, portalContext: any, timeContext: any, siteName: string) => {
    const { Ranking_Visual } = Configuration;
    const availableFilterTypes = getAvailableFilterTypes(page, Ranking_Visual);
    console.log("filter", availableFilterTypes)
    const filtersWithDatatype = getFiltersDataType(availableFilterTypes);
    console.log("filter1", filtersWithDatatype)
    const filters = createFilters(availableFilterTypes);
    console.log("filter2", filters)
    const variables = getVariables(availableFilterTypes, page, portalContext, timeContext, siteName, 'sources');
    console.log("filter3", variables)
    const query = gql`
    query getRankingVisualData (${filtersWithDatatype}){ 
        ${GQL_paginatedEmissions_Schema_Type}(

        where:{
  
            and: {${filters}}
        
            } 
       
        order: {time:ASC})
       
        {
       
        edges
       
        {
       
        node
       
        { 
       
            time,
            actualValue,
            rank,
            scope_displayname,
            source_displayname,
            source_tag,
            sourcetag_displayname,
            subsource_displayname,
            sourcegroup_displayname,
            uom,
            site,
            kpi_category,
            asset_name,
            kpi_type,
            emissonfactorstandard,
            emissionfactorversion
       
        }
       
        cursor
       
        }
       
        pageInfo {
       
       hasNextPage
       
        }
       
        }
       
       }`

    return { query, variables }


}

const getRankQuery = (page: any, portalContext: any, timeContext: any, siteName: any) => {
    const { Active_Rank } = Configuration;
    const availableFilterTypes = getAvailableFilterTypes(page, Active_Rank);
    const filtersWithDatatype = getFiltersDataType(availableFilterTypes);
    const filters = createFilters(availableFilterTypes);
    const variables = getVariables(availableFilterTypes, page, portalContext, getActiveRankTime(timeContext), siteName, 'rank');
    const rankQuery = gql`
    query getRankData (${filtersWithDatatype}){ 
        ${GQL_paginatedEmissions_Schema_Type}(

        where:{
  
            and: {${filters}}
        
            } 
       
        order: {time:ASC})
       
        {
       
        edges
       
        {
       
        node
       
        { 
            actualValue
            asset_name
            rank
            kpi_type
            time
        }
       
        cursor
       
        }
       
        pageInfo {
       
       hasNextPage
       
        }
       
        }
       
       }`

    return { rankQuery, variables }
}

const useRankingVisualData = (page: string, siteName: string, siteDetailFilter:any ) => {
    const { portalContext, timeContext } = useContext(AppContext);
    const { query, variables } = getQuery(page, portalContext, timeContext, siteName);
    const { data, loading, error } = useQuery(query, { variables: variables });
    const { rankQuery, variables: Var } = getRankQuery(page, portalContext, timeContext, siteName);
    const { data: rankData, loading: activeRankLoading} = useQuery(rankQuery, { variables: Var });

    let RankingVisualData: any = {};
    let latestRanks: any = {};
    let EFLSData:any = {};
    let sourceTagsActiveRank:any = {};
    if (!loading && !activeRankLoading) {
        const { edges } = data?.paginatedEmissions;
        let nodes = edges?.map((item: any, index: number) => {
            return { ...item?.node, index };
        });
        if(siteDetailFilter?.length > 0) {
            nodes = nodes?.filter((item:any) =>  siteDetailFilter.indexOf(item?.scope_displayname) >=0  );
        }

        if(siteDetailFilter?.length > 0) {
            nodes = nodes?.filter((item:any) =>  siteDetailFilter.indexOf(item?.source_displayname) >=0 );
        }

        RankingVisualData = groupDataByKey(nodes, 'asset_name');
        //deleting site name which is also coming in data
        delete RankingVisualData[siteName];

        const { edges: activeRankDataEdges } = rankData?.paginatedEmissions;
        const activeRankObject:any = {};
        activeRankDataEdges?.forEach((item: any, index: number) => {
            activeRankObject[item?.node?.asset_name] = { ...item?.node}
        });
        for (const key in RankingVisualData) {
            if(activeRankObject?.[key]) {
                const actualRank = activeRankObject?.[key]?.actualValue;
                if( actualRank > 0) {
                    latestRanks[key] =  actualRank;
                } else {
                    latestRanks[key] =  getLastRankDataFromData(RankingVisualData?.[key])
                }
            } else {
                latestRanks[key] =  getLastRankDataFromData(RankingVisualData?.[key])
            }
            const groupByRank = groupDataByKey(RankingVisualData?.[key], 'rank');
            const dataRelatedToActiveRank:any = groupByRank[latestRanks[key]];
            sourceTagsActiveRank[key] = dataRelatedToActiveRank;
            const latestTimeData = getHighestValueEntry(dataRelatedToActiveRank, 'time');
            EFLSData[key] = {
                emissonfactorstandard: latestTimeData?.emissonfactorstandard || null,
                emissionfactorversion: latestTimeData?.emissionfactorversion || null
            }

        };
    };
    return {
        RankingVisualData : sourceTagsActiveRank,
        EFLSData,
        latestRanks,
        loading,
        error
    }
}

export default useRankingVisualData;