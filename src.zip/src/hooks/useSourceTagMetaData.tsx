import { useContext } from 'react';
import { useQuery, gql } from '@apollo/client';
import { Configuration } from '../api/queryFieldMappings';
import { GQL_paginatedEmissions_Schema_Type, getReportingPeriod, getAvailableFilterTypes, getFiltersDataType, createFilters } from '../api/graphqlUtils';
import { AppContext } from '../store/AppContext';
import { groupDataByKey } from '../utils/utils';


const getVariables = (availableFilterTypes: any, page: string, portalContext: any, timeContext: any, asset_name: string) => {
    let variables: any = {};
    availableFilterTypes.map((filter: any) => {
        if (filter.name === 'kpi_category') {
            variables = { ...variables, [filter.name]: { eq: "Source Tag" } }
        } else if (filter.name === 'kpi_type') {
            variables = { ...variables, [filter.name]: { eq: "CO2e" } }
        }
        else if (filter.name === 'time') {
            variables = { ...variables, "time": { "gte": timeContext?.['start'], "lte": timeContext?.['end'] } }
        } else if (filter.name === 'reportingperiod') {
            variables = { ...variables, [filter.name]: { eq: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()) || filter.defaultValue } }
        } else if (filter.name === 'asset_name') {
            variables = { ...variables, [filter.name]: { eq: asset_name || portalContext?.asset } }
        }
    });
    return variables;
}

const getQuery = (page: string, portalContext: any, timeContext: any, asset_name: string) => {
    const { Source_Details } = Configuration;
    const availableFilterTypes = getAvailableFilterTypes(page, Source_Details);
    console.log("filter", availableFilterTypes)
    const filtersWithDatatype = getFiltersDataType(availableFilterTypes);
    console.log("filter1", filtersWithDatatype)
    const filters = createFilters(availableFilterTypes);
    console.log("filter2", filters)
    const variables = getVariables(availableFilterTypes, page, portalContext, timeContext, asset_name);
    console.log("filter3", variables)
    const query = gql`
    query getSourceTagMeta (${filtersWithDatatype}){ 
        ${GQL_paginatedEmissions_Schema_Type}(
        first: 1    
        where:{
  
            and: {${filters}}
        
            } 
       
        order: {time:DESC})
       
        {
       
        edges
       
        {
       
        node
       
        { 
       
            asset_name
            source_displayname
            scope_displayname
            source_group
            uom
            rank
            kpi_type
            sourcetag_displayname
            actualValue
        }
       
        cursor
       
        }
       
        pageInfo {
       
       hasNextPage
       
        }
       
        }
       
       }`

    return { query, variables }


}

const useSourceTagMetaData = (page: string, asset_name: string) => {
    const { portalContext, timeContext } = useContext(AppContext);
    const { query, variables } = getQuery(page, portalContext, timeContext, asset_name);
    const { data, loading, error } = useQuery(query, { variables: variables });

    let sourceTagMetaData: any = [];

    if (!loading) {
        const { edges } = data?.paginatedEmissions;
        const nodes = edges?.map((item: any, index: number) => {
            return { ...item?.node };
        });
        sourceTagMetaData = nodes[0]
    };
    return {
        sourceTagMetaData,
        sourceTagMetaDataLoading: loading,
        sourceTagMetaDataError: error
    }
}

export default useSourceTagMetaData;