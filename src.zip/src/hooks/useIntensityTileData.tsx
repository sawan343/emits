import { useContext, useMemo } from 'react';
import { useQuery, gql, NetworkStatus } from '@apollo/client';
import { Configuration } from '../api/queryFieldMappings';
import { GQL_paginatedEmissions_Schema_Type, getReportingPeriod } from '../api/graphqlUtils';
import { AppContext } from '../store/AppContext';
import { tileNames } from "../../src/utils/constants";
const getFiltersDataType = (page: string, tileName: string) => {
    const tileConfiguration = Configuration[tileName];
    const defaultVariables = tileConfiguration['default'].filter((item: any) => item.isFilterVariable);
    const pageVariables = tileConfiguration[page].filter((item: any) => item.isFilterVariable);
    const allVariables = defaultVariables.concat(pageVariables)
    let filters: string = '';
    allVariables.map((item: any) => {
        filters = filters.concat(`$${item.name}: ${item.filterVariableType}!, `)
    });
    return filters;
}

const createFilters = (page: string, tileName: string) => {
    const tileConfiguration = Configuration[tileName];
    const defaultVariables = tileConfiguration['default'].filter((item: any) => item.isFilterVariable);
    const pageVariables = tileConfiguration[page].filter((item: any) => item.isFilterVariable);
    const allVariables = defaultVariables.concat(pageVariables)
    let filters: string = '';
    allVariables.map((item: any) => {
        filters = filters.concat(`${item.name}: $${item.name}, `)
    });
    console.log('filters--->', filters)
    return filters;
}

const getVariables = (page: string, params: any, tile: string, portalContext: any, timeContext: any) => {
    const tileConfiguration = Configuration[tile];
    let defaultFilters = tileConfiguration?.['default'].filter((item: any) => item.isFilterVariable);
    const pagefilters = tileConfiguration?.[page]?.filter((item: any) => item.isFilterVariable);
    const allFilters = defaultFilters.concat(pagefilters)
    let variables: any = {};
    allFilters.map((filter: any) => {
        if (filter.defaultValue !== '') {
            let obj: any = {};
            obj[filter.name] = { eq: filter.defaultValue }
            variables = { ...variables, ...obj }
        } else if (filter.name === 'kpi_type') {
            variables = { ...variables, "kpi_type": { eq: 'CO2e' } }
        }
        else if (filter.name === 'assettype_name') {
            if (tile === tileNames.intensity) {
                if (page === 'enterprise') {
                    variables = { ...variables, [filter.name]: { eq: "Enterprise" } }
                }
                if (page === 'region') {
                    variables = { ...variables, [filter.name]: { eq: "Region" } }
                }
                if (page === 'site') {
                    variables = { ...variables, [filter.name]: { eq: "Site" } }
                }
            }
            else {
                if (page === 'site') {
                    variables = { ...variables, "assettype_name": { "eq": "Asset" } }
                }
                else {
                    variables = { ...variables, "assettype_name": { "eq": "Site" } }
                }
            }
        }
        else if (filter.name === 'time') {
            variables = { ...variables, "time": { "gte": timeContext?.['start'], "lte": timeContext?.['end'] } }
        }
        else if (filter.name === 'enterprise') {
            variables = { ...variables, "enterprise": { eq: portalContext['enterprise'] } }
        }
        else if (filter.name === 'region') {
            variables = { ...variables, "region": { eq: params?.redirect ? params?.redirect : portalContext['region'] } }
        }
        else if (filter.name === 'site') {
            variables = { ...variables, "site": { eq: params?.siteName ? params?.siteName : portalContext['site'] } }
        }
        else if (filter.name === 'reportingperiod') {
            variables = { ...variables, "reportingperiod": { eq: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()) } }
        }
    });
    return variables;

}

const getQuery = (page: string, params: any, tileName: string, portalContext: object, timeContext: any) => {
    const variables = getVariables(page, params, tileName, portalContext, timeContext);
    const filtersWithDatatype = getFiltersDataType(page, tileName);
    const filters = createFilters(page, tileName);
    const query = gql`
    query getTopEmitters (${filtersWithDatatype}) {

    ${GQL_paginatedEmissions_Schema_Type}(
  
     where: {
  
      and: {${filters}}
  
      }     
  
     order: { time: ASC}
  
    ) {
  
     edges {
  
      node {
  
       time
  
       actualValue
  
       kpi_type
  
       kpi_category
  
       uom

       site

       region
  
       targetHighLimit

       warningHigh
       
       sourcetag_displayname

       source_displayname

    }
  
      cursor
  
     }
  
     pageInfo {
  
      hasNextPage
  
     }
  
    }
  
   }`

    return { query, variables }
}

export const useIntensityTileData = (page: string, params: any, selectedKpiTypeFromDropdown: any) => {
    const { portalContext, timeContext } = useContext(AppContext);
    const { query, variables } = getQuery(page, params, tileNames.intensity, portalContext, timeContext);
    let { data, loading, error, refetch, networkStatus } = useQuery(query, { variables: variables, notifyOnNetworkStatusChange: true });
    let intensityTileData: any = {};

    useMemo(() => {
        if (selectedKpiTypeFromDropdown) {
            refetch({ kpi_type: { eq: selectedKpiTypeFromDropdown } });
        }
    }, [selectedKpiTypeFromDropdown]);

    if (networkStatus === NetworkStatus.refetch) {
        loading = true;
    }

    // useMemo(() => {
    // }, [loading]);
    if (!loading) {
        const { edges } = data?.paginatedEmissions;
        let currentValue = 0;
        let maxValue = 0;
        let uom: string = '';
        let intensityData: any = [];
        edges.map((obj: any, index: number) => {
            if (index === (edges.length - 1)) {
                currentValue = obj.node.actualValue;
            }
            if (obj.node.actualValue > maxValue) {
                maxValue = obj.node.actualValue;
            }
            uom = obj.node.uom;
            intensityData.push(obj.node);
        })
        intensityTileData = {
            currentValue: currentValue,
            maxValue: maxValue,
            uom: uom,
            values: intensityData
        }
    }

    return {
        intensityTileData,
        loading,
        error
    }

};

export const useCriticalSiteData = (page: string, params: any, selectedKpiTypeFromDropdown: any) => {
    let { portalContext, timeContext } = useContext(AppContext);
    const { query, variables } = getQuery(page, params, tileNames.criticalSites, portalContext, timeContext);
    let { data, loading, error, refetch, networkStatus } = useQuery(query, { variables: variables, notifyOnNetworkStatusChange: true });
    let critialSitesData: any = [];

    useMemo(() => {
        if (selectedKpiTypeFromDropdown) {
            refetch({ kpi_type: { eq: selectedKpiTypeFromDropdown } });
        }
    }, [selectedKpiTypeFromDropdown]);

    if (networkStatus === NetworkStatus.refetch) {
        loading = true;
    }

    // useMemo(() => {

    // }, [loading])
    if (!loading) {
        const { edges } = data?.paginatedEmissions;
        const nodes = edges.map((item: any) => item.node);
        let groupData: string[] = [];

        if (page === 'enterprise' || page === 'region') {
            groupData = ['region', 'site'];
        }
        if (page === 'site') {
            groupData = ['sourcetag_displayname']
        }

        let groupedCriticalSiteData: any = [];
        if (page === 'enterprise' || page === 'region') {
            groupedCriticalSiteData = nodes.reduce((group: any, arr: any) => {
                let groupName: any = arr[groupData[0]] + '_' + arr[groupData[1]];
                group[groupName] = group[groupName] ?? [];
                group[groupName]['total'] = (group[groupName]['total'] ? group[groupName]['total'] : 0) + arr.actualValue;
                group[groupName].push(arr);
                return group;
            }, {});
        }
        else {
            groupedCriticalSiteData = nodes.reduce((group: any, arr: any) => {
                group[arr[groupData[0]]] = group[arr[groupData[0]]] ?? [];
                group[arr[groupData[0]]]['total'] = (group[arr[groupData[0]]]['total'] ? group[arr[groupData[0]]]['total'] : 0) + arr.actualValue;
                group[arr[groupData[0]]].push(arr);
                return group;
            }, {});
        }

        let site_list = Object.keys(groupedCriticalSiteData)
        site_list.map((item: any) => {
            critialSitesData.push(groupedCriticalSiteData[item])
        })
        critialSitesData = critialSitesData.sort((a: any, b: any) => b['total'] > a['total'] ? 1 : -1);
        critialSitesData = critialSitesData.slice(0, 3);
    }

    return {
        critialSitesData,
        loading,
        error
    }
}

// export default useIntensityTileData;