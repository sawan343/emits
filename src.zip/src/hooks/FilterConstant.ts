export const SiteFilter = {
    scope_1:  ["Combustion", "Fugitives"],
    scope_2:  [],
    scope_3:  []
}