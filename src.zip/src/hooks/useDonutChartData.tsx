import { useQuery, gql } from "@apollo/client";
import { Configuration } from "../api/queryFieldMappings";
import { GQL_paginatedEmissions_Schema_Type, getAvailableFilterTypes, getFiltersDataType, createFilters, getReportingPeriod } from "../api/graphqlUtils";
import { useContext, useMemo } from "react";
import { AppContext } from "../store/AppContext";
import { DONUT_CHART_SCOPES, CHART_COLORS } from "../utils/constants";
import { groupDataByKey } from "../utils/utils";



const getVariables = (availableFilterTypes: any, params: any, page: string, portalContext: any, timeContext: any) => {
  let variables: any = {};
  availableFilterTypes.map((filter: any) => {
    if (filter.name === 'assettype_name') {
      if (page === 'site') {
        variables = { ...variables, [filter.name]: { eq: "Site" } }
      }
    } else if (filter.name === 'asset_name') {
      variables = { ...variables, [filter.name]: { eq: params?.siteName ? params?.siteName : portalContext?.asset } }
    } else if (filter.name === 'kpi_category') {
      variables = { ...variables, [filter.name]: { eq: "Source" } }
    } else if (filter.name === 'kpi_type') {
      variables = { ...variables, [filter.name]: { eq: "CO2e" } }
    } else if (filter.name === 'time') {
      variables = { ...variables, "time": { "gte": timeContext?.['start'], "lte": timeContext?.['end'] } }
      // variables = {
      //   ...variables, time: {
      //     gte: "2023-03-27T00:00:00.000Z",
      //     lte: "2023-03-27T23:30:00.000Z"
      //   }
      // }
    } else if (filter.name === 'reportingperiod') {
      variables = { ...variables, "reportingperiod": { eq: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()) || 'Daily' } }
    }
  });
  return variables;
};

const getQuery = (page: string, params: any, portalContext: any, timeContext: any) => {
  const { Donut_Chart } = Configuration;
  const availableFilterTypes = getAvailableFilterTypes(page, Donut_Chart);
  const filtersWithDatatype = getFiltersDataType(availableFilterTypes);
  const filters = createFilters(availableFilterTypes);
  const variables = getVariables(availableFilterTypes, params, page, portalContext, timeContext);

  const query = gql`
  query getDonutChartData (${filtersWithDatatype}) {

  ${GQL_paginatedEmissions_Schema_Type}(

   where: {${filters}}
   order: { source_displayname: ASC }
  ) {
      edges {
          node {  
            time
            actualValue  
            kpi_type  
            kpi_category  
            scope_displayname  
            asset_name  
            source_displayname
            uom
          }
      }
    }

 }`

  return { query, variables }
}

const useDonutChartData = (page: string, params: any) => {
  const { portalContext, timeContext } = useContext(AppContext);
  const { query, variables } = getQuery(page, params, portalContext, timeContext)
  const { data, loading, error } = useQuery(query, { variables: variables });
  let donutChartData: Array<any> = [];

  // useMemo(() => {
  // }, [loading]);
  if (!loading) {
    const { edges } = data?.paginatedEmissions;
    const nodes = edges.map((item: any) => item.node);
    const groupDataByDisplayName: string = 'scope_displayname';

    //Group values based on scope 
    const groupedScopeValues = groupDataByKey(nodes, groupDataByDisplayName);
    Object.keys(groupedScopeValues).map((item: any) => {
      let values: any = {
        sources: [],
        totalActualValue: 0,
        scope: '',
        color: [],
        uom: ''
      };
      let sources: any = []
      let index = 0;
      if (DONUT_CHART_SCOPES.includes(item?.toLocaleLowerCase())) {
        let sum: number = 0;
        groupedScopeValues[item].map((source: any) => {
          sum = sum + source?.actualValue;
          values.totalActualValue = sum;
          if (sources.hasOwnProperty(source?.source_displayname)) {
            values.sources[sources[source?.source_displayname]].actualValue += source?.actualValue;
          }
          else {
            sources[source?.source_displayname] = index;
            values.sources.push({ source: source?.source_displayname, actualValue: source?.actualValue });
            values.scope = source?.[groupDataByDisplayName];
            values.color.push(CHART_COLORS[source?.source_displayname]);
            values.uom = source?.uom;
            index += 1;
          }
        })
      }
      donutChartData.push(values);
    });

    const ifScope3Available = donutChartData.find((item: any) => item?.scope?.toLowerCase() === 'scope 3');
    if (!ifScope3Available) {
      donutChartData.push({
        color: ['#F1F1F1'],
        scope: "Scope 3",
        sources: [{
          actualValue: 0,
          source: "No data available"
        }],
        totalActualValue: '-',
        uom: "Tonnes"
      })
    }

    console.log('groupedScopeValues----->', groupedScopeValues);
    console.log('donutChartData----->', donutChartData);

  }

  return {
    donutChartData,
    loading,
    error,
  };
};

export default useDonutChartData;
