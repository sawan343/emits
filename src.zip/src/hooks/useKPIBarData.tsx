import { useContext } from 'react';
import { useQuery, gql } from '@apollo/client';
import { Configuration } from '../api/queryFieldMappings';
import { GQL_paginatedEmissions_Schema_Type, getReportingPeriod, getAvailableFilterTypes, getFiltersDataType, createFilters } from '../api/graphqlUtils';
import { AppContext } from '../store/AppContext';

const kpiCategories = ["Production", "Total", "Scope"];
const kpiTypes = ["CO2e", "Production"];
const kpiDisplayOrder: any = {
    'production': {order:1,'displayName':'PRODUCTION'},
    'ghg emissions in co2e': {order:2,'displayName':'GHG EMISSIONS IN CO2e'},
    'scope 1': {order:3,'displayName':'SCOPE 1 EMISSIONS (CO2e)'},
    'scope 2': {order:4,'displayName':'SCOPE 2 EMISSIONS (CO2e)'},
    'scope 3': {order:5,'displayName':'SCOPE 3 EMISSIONS (CO2e)'},
}

const getVariables = (availableFilterTypes: any, params: any, page: string, portalContext: any, timeContext: any) => {
    let variables: any = {};
    availableFilterTypes.map((filter: any) => {
        if (filter.name === 'assettype_name') {
            if (page === 'enterprise') {
                variables = { ...variables, [filter.name]: { eq: "Enterprise" } }
            }
            if (page === 'region') {
                variables = { ...variables, [filter.name]: { eq: "Region" } }
            }
            if (page === 'site') {
                variables = { ...variables, [filter.name]: { eq: "Site" } }
            }
        } else if (filter.name === 'kpi_category') {
            variables = { ...variables, [filter.name]: { in: kpiCategories } }
        } else if (filter.name === 'kpi_type') {
            variables = { ...variables, [filter.name]: { in: kpiTypes } }
        } else if (filter.name === 'time') {
            variables = { ...variables, [filter.name]: { gte: timeContext?.['start'], lte: timeContext?.['end'] } }
        } else if (filter.name === 'reportingperiod') {
            variables = { ...variables, [filter.name]: { eq: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()) || filter.defaultValue } }
        } else if (filter.name === "region") {
            variables = { ...variables, [filter.name]: { eq: params?.redirect ? params?.redirect : (portalContext[filter.name] ? portalContext[filter.name] : filter.defaultValue) } }
        } else if (filter.name === "site") {
            variables = { ...variables, [filter.name]: { eq: params?.siteName ? params?.siteName : (portalContext[filter.name] ? portalContext[filter.name] : filter.defaultValue) } }
        } else {
            variables = { ...variables, [filter.name]: { eq: portalContext[filter.name] ? portalContext[filter.name] : filter.defaultValue } }
        }
    });
    return variables;
}

const getQuery = (page: string, params: any, portalContext: any, timeContext: any) => {
    const { Kpi_Bar } = Configuration;
    const availableFilterTypes = getAvailableFilterTypes(page, Kpi_Bar);
    const filtersWithDatatype = getFiltersDataType(availableFilterTypes);
    const filters = createFilters(availableFilterTypes);
    const variables = getVariables(availableFilterTypes, params, page, portalContext, timeContext);

    const query = gql`
    query getKpiBarData (${filtersWithDatatype}) {

    ${GQL_paginatedEmissions_Schema_Type}(
  
     where: {${filters}}
     order: { time: ASC}
    ) {
        edges {
            node {                
                time
                actualValue
                kpi_type
                kpi_category
                kpi_displayname
                uom
            }
        }
      }
  
   }`

    return { query, variables }
}


const useKPIBarData = (page: string, params: any) => {
    const { portalContext, timeContext } = useContext(AppContext);
    const { query, variables } = getQuery(page, params, portalContext, timeContext);
    const { data, loading, error } = useQuery(query, { variables: variables });

    let kpiBarInputData: Array<any> = [];

    if (!loading) {
        const { edges } = data?.paginatedEmissions;
        const kpiList: Array<any> = [];

        const nodes = edges.map((item: any) => {
            if (kpiCategories.includes(item?.node?.kpi_category)) {
                return item?.node;
            }
        });

        const groupedKpiBarData = nodes?.reduce((group: any, arr: any) => {
            group[arr['kpi_displayname']] = group[arr['kpi_displayname']] ?? [];
            group[arr['kpi_displayname']].push(arr);
            return group;
        }, {});
        let kpiKeysRequired:any = Object.keys(kpiDisplayOrder).map((key:any)=>{return key?.toLowerCase()});
        let kpiKeysFromData:any = Object.keys(groupedKpiBarData).map((key:any)=>{return key?.toLowerCase()});  
        let difference = [...kpiKeysRequired].filter(x => !kpiKeysFromData.includes(x));
        Object.keys(groupedKpiBarData).map((kpi: any) => {
            let sum: number = 0;
            groupedKpiBarData[kpi].map((node: any, index: number) => {
                sum = sum + node?.actualValue;
                if (index === groupedKpiBarData[kpi].length - 1) {
                    kpiList.push({
                        displayName: node?.kpi_category === 'Scope' ? `${node?.kpi_displayname?.toUpperCase()} EMISSIONS (CO2e)` : node?.kpi_displayname?.toUpperCase()?.replace('CO2E', 'CO2e'),
                        actualValue: sum,
                        uom: node?.uom,
                        order: kpiDisplayOrder[node?.kpi_displayname?.toLowerCase()]?.order
                    })
                }
            });
        });
        difference.map((missingField:any)=>{
            kpiList.push({
                displayName: kpiDisplayOrder?.[missingField]?.displayName,
                actualValue: '-',
                uom: '',
                order: kpiDisplayOrder?.[missingField]?.order
            })
        })
        kpiBarInputData = kpiList.sort((a: any, b: any) => b.order > a.order ? -1 : 1);
    };
    return {
        kpiBarInputData,
        loading,
        error
    }
}

export default useKPIBarData;