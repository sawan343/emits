import { useQuery, gql } from "@apollo/client";
import { Configuration } from "../api/queryFieldMappings";
import {
  GQL_paginatedEmissions_Schema_Type,
  getReportingPeriod,
  getAvailableFilterTypes,
  getFiltersDataType,
  createFilters,
} from "../api/graphqlUtils";
import { useContext } from "react";
import { AppContext } from "../store/AppContext";

const getVariables = (
  availableFilterTypes: any,
  page: string,
  portalContext: any,
  timeContext: any
) => {
  let variables: any = {};
  availableFilterTypes.map((filter: any) => {
    if (filter.name === "assettype_name") {
      variables = {
        ...variables,
        [filter.name]: { eq: portalContext["assetType"] },
      };
    } else if (filter.name === "asset_name") {
      variables = {
        ...variables,
        [filter.name]: { eq: portalContext["site"] },
      };
    } else if (filter.name === "kpi_category") {
      variables = { ...variables, [filter.name]: { in: ["Source Group"] } };
    } else if (filter.name === "kpi_type") {
      variables = { ...variables, [filter.name]: { in: ["CO2e"] } };
    } else if (filter.name === "time") {
      variables = {
        ...variables,
        time: { gte: timeContext?.["start"], lte: timeContext?.["end"] },
      };
    } else if (filter.name === "reportingperiod") {
      variables = {
        ...variables,
        reportingperiod: {
          eq:
            getReportingPeriod(timeContext?.["start"], timeContext?.["end"], timeContext?.id?.toUpperCase()) ||
            "Daily",
        },
      };
    }
  });
  return variables;
};

const getQuery = (page: string, portalContext: any, timeContext: any) => {
  const { Kpi_FilterPage } = Configuration;
  const availableFilterTypes = getAvailableFilterTypes(page, Kpi_FilterPage);
  const filtersWithDatatype = getFiltersDataType(availableFilterTypes);
  const filters = createFilters(availableFilterTypes);
  const variables = getVariables(
    availableFilterTypes,
    page,
    portalContext,
    timeContext
  );

  const query = gql`
  query getFilterPageData (${filtersWithDatatype}) {

  ${GQL_paginatedEmissions_Schema_Type}(

   where: {${filters}}
   order: {scope_displayname: ASC}

  ) {
      edges {
          node {  
              kpi_type      
              kpi_category 
              scope_displayname
              source_displayname
              subsource_displayname 
          }
      }
    }

 }`;

  return { query, variables };
};
const useFilterPanelData = (page: string) => {
  const { portalContext, timeContext } = useContext(AppContext);
  const { query, variables } = getQuery(page, portalContext, timeContext);
  const { data, loading, error } = useQuery(query, { variables: variables });
  const { Kpi_FilterPage } = Configuration;
  let KpiFilterPageData: Array<any> = [];
  let scope_displayname: Array<any> = [];
  let source_displayname: Array<any> = [];
  let subsource_displayname: Array<any> = [];
  let valueByScope: Array<any> = [];
  let valueBySource: Array<object> = [];
  let scope1: Array<any> = [];
  let scope2: Array<any> = [];
  let scope3: Array<any> = [];
  let allScope: Array<any> = [];

  if (!loading) {
    const { edges } = data?.paginatedEmissions;
    Kpi_FilterPage["kpiCategories"].map((kpiCategory: any) => {
      Kpi_FilterPage["kpiTypes"].map((kpiType: any) => {
        edges.map((item: any) => {
          if (
            kpiCategory.name === item.node.kpi_category &&
            kpiType === item.node.kpi_type
          ) {
            const data = {
              kpi_category: item.node.kpi_category,
              kpi_type: kpiType,
              scope_displayname: item.node.scope_displayname,
              source_displayname: item.node.source_displayname,
            };
            const index = KpiFilterPageData.findIndex(
              (el) =>
                el.kpi_category === item.node.kpi_category &&
                el.kpi_type === item.node.kpi_type &&
                el.scope_displayname === item.node.scope_displayname &&
                el.source_displayname === item.node.source_displayname
            );
            return index > -1
              ? (KpiFilterPageData[index] = data)
              : KpiFilterPageData.push(data);
          }
        });
      });
      if (KpiFilterPageData?.length > 0) {
        for (let i in KpiFilterPageData) {
          scope_displayname.push(KpiFilterPageData[i].scope_displayname);
          source_displayname.push(KpiFilterPageData[i].source_displayname);
        }

        for (let x in scope_displayname) {
          valueByScope.push([scope_displayname[x], source_displayname[x]]);
        }

        for (let y in valueByScope) {
          if (valueByScope[y][0] === "Scope 1") {
            scope1.push({ key: "0-0-" + y, label: valueByScope[y][1] });
          }
          if (valueByScope[y][0] === "Scope 2") {
            scope2.push({ key: "1-0-" + y, label: valueByScope[y][1] });
          }
          if (valueByScope[y][0] === "Scope 3") {
            scope3.push({ key: "2-0-" + y, label: valueByScope[y][1] });
          }
        }
        allScope.push(
          { key: "0-0", label: "Scope 1", children: scope1 },
          { key: "1-0", label: "Scope 2", children: scope2 },
          { key: "2-0", label: "Scope 3", children: scope3 }
        );
        valueBySource.push({
          key: "0",
          label: "Emission By Source",
          children: allScope,
        });
      }
      console.log(valueBySource);
    });
  }
  return {
    KpiFilterPageData,
    valueBySource,
    loading,
    error,
  };
};

export default useFilterPanelData;
