import { useContext, useMemo } from 'react';
import { useQuery, gql } from '@apollo/client';
import { Configuration } from '../api/queryFieldMappings';
import { GQL_paginatedEmissions_Schema_Type, getReportingPeriod, getAvailableFilterTypes, getFiltersDataType, createFilters } from '../api/graphqlUtils';
import { AppContext } from '../store/AppContext';
import { groupDataByKey, getLastRankDataFromData, getActiveRankTime } from '../utils/utils';
import { isArray } from 'highcharts';
import { client } from '../api/ApolloClient';

const addActualvalue = (data: any, activeRank:any) => {
  let sum = data;
  if(!data) return 0;
  if(activeRank > 0) {
    sum = groupDataByKey(data, 'rank')?.[activeRank];
  }
  if (isArray(sum)) {
    return sum.reduce((a: any, b: any) => {
      return a + b.actualValue
    }, 0)
  }
  return []
}
const query = (metaData: any, portalContext: any, timeContext: any) => {
  const { scope_displayname, siteName, source_tag, source_displayname, asset_name } = metaData;
  const q = gql`{
    paginatedEmissions(
      where: {
        or: [
          {
            and: [
              { asset_name: { in: ["${asset_name}"] } }
              { kpi_category: { in: ["Source Tag"] } }
              { kpi_type: { eq: "CO2e" } }
              { reportingperiod: { eq: "${getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase())}" } }
              {
                time: {
                  gte: "${timeContext?.['start']}"
                  lte: "${timeContext?.['end']}"
                }
              }
            ]
          }
          {
            and: [
              { asset_name: { in: ["${siteName}"] } }
              { kpi_category: { in: ["Source"] } }
              { source_displayname: { eq: "${source_displayname}" } }
              { kpi_type: { eq: "CO2e" } }
              { reportingperiod: { eq: "${getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase())}" } }
              {
                time: {
                  gte: "${timeContext?.['start']}"
                  lte: "${timeContext?.['end']}"
                }
              }
            ]
          }
          {
            and: [
              { asset_name: { in: ["${siteName}"] } }
              { kpi_category: { in: ["Scope"] } }
              { kpi_type: { eq: "CO2e" } }
              { scope_displayname: { eq: "${scope_displayname}" } }
              { reportingperiod: { eq: "${getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase())}" } }
              {
                time: {
                  gte: "${timeContext?.['start']}"
                  lte: "${timeContext?.['end']}"
                }
              }
            ]
          }
        ]
      }
  
      order: { time: ASC }
    ) {
      edges {
        node {
          asset_name
  
          actualValue
  
          scope_displayname
  
          source_displayname
  
          sourcetag_displayname
  
          sourcegroup_displayname
  
          site
  
          kpi_type
  
          kpi_category
          rank
          time
        }
      }
    }
  }`;
  return q;
}


const useScopeContributionChart = (metaData: any) => {
  let { portalContext, timeContext } = useContext(AppContext);
  const { data, loading, error } = useQuery(query(metaData, portalContext, timeContext));
  const { scope_displayname, siteName, source_tag, source_displayname, asset_name } = metaData;


  let groupDataByScope: any = {};
  let groupDataBySource: any= {};
  let groupDataBySourceTag: any = {};
  let groupByRank: any = {};
  let totalScope: any = 0;
  let totalSource: any = 0;
  let totalSourceTag: any = 0;
  let allRanksKeys: any = [];
  let activeRank: number = 1;

  // useMemo(() => {
  // },[loading])
  if (!loading) {
    const { edges } = data?.paginatedEmissions;
    const nodes = edges.map((item: any) => item.node);
    if(edges.length > 0) {
      const groupBySource = groupDataByKey(nodes, 'kpi_category');
      console.log(groupBySource);
      groupDataByScope = groupDataByKey(nodes, 'scope_displayname');
      groupDataBySource = groupDataByKey(nodes, 'source_displayname');
      groupDataBySourceTag = groupDataByKey(nodes, 'asset_name');
      groupByRank = groupDataByKey(groupDataBySourceTag[asset_name], 'rank');
      activeRank = metaData?.activeRank || getLastRankDataFromData(groupDataBySourceTag[asset_name]);
      allRanksKeys = Object.keys(groupByRank);
      let groupByRankWithoutNullKey = {};
      if(allRanksKeys?.length > 0 ) {
        allRanksKeys = allRanksKeys?.filter( (e:any) => {
          if(e) {
            groupByRankWithoutNullKey = {...groupByRankWithoutNullKey, [e]: groupByRank[e] }
            return true;
          }
          return false;
        });
        groupByRank = groupByRankWithoutNullKey;
      }
      totalScope = addActualvalue(groupBySource["Scope"], false);
      totalSource = addActualvalue(groupBySource["Source"], false);
      totalSourceTag = addActualvalue(groupDataBySourceTag[asset_name], activeRank);
    }
    

  }


  return {
    scopeContributionData: {
      groupDataByScope,
      groupDataBySource,
      groupDataBySourceTag,
      totalScope,
      groupByRank,
      totalSource,
      totalSourceTag,
      allRanksKeys: allRanksKeys,
      activeRank
    },
    scopeContributionLoading: loading,
    scopeContributionError: error
  }
}
export default useScopeContributionChart;