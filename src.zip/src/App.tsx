import React from 'react';
import { AppContextProvider } from './store/AppContext';
import { ApolloProvider } from '@apollo/client';
import { client } from './api/ApolloClient';
import { Emissions } from './Emissions';

function App() {
  return (
    <React.Fragment>
      <ApolloProvider client={client}>
        <AppContextProvider>
          <Emissions />
        </AppContextProvider>
      </ApolloProvider>
    </React.Fragment>
  );
}

export default App;
