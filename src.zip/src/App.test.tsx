import React from 'react';
import { render, screen } from '@testing-library/react';
import ReactDOM from 'react-dom/client';
import { act } from 'react-dom/test-utils';

import App from './App';

let container:any;

test('renders Emissions text', () => {  
  render(<App />);
  const linkElement = screen.getByTestId('Emissions');
  expect(linkElement).toBeInTheDocument();
});
