// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.


import React, { useContext, useEffect, useMemo } from "react";
import { AppContext } from './store/AppContext';
import { RouterProvider } from "react-router-dom";
import { router } from "./routes/Router";
import { getLocaleOptions } from './locale/utils'

//theme
import "primereact/resources/themes/lara-light-indigo/theme.css";
//core
import "primereact/resources/primereact.min.css";

//import "/node_modules/primeflex/primeflex.css";
import './styles/main.scss';

const root = document.getElementsByTagName('html')[0]; // '0' to assign the first (and only `HTML` tag)
root.setAttribute('class', 'light');
export const Emissions = () => {
    const { setLocale } = useContext(AppContext);


//portal context handler function starts here


//portal context handler function ends here


    useEffect(() => {
        setLocale(getLocaleOptions(navigator.language));
    }, [navigator.language]);

    return <RouterProvider router={router} />
}
