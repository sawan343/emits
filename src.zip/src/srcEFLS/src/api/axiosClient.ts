import axios from "axios";
// import { API_TIMEOUT_NAME } from "../constant/global";

export const AUTHORIZE_API_BASE_PATH = process.env.REACT_APP_API_AUTHORIZE_PATH as string;

 export const API_BASE_PATH = process.env.REACT_APP_API_BASE_PATH as string;
 export const API_BASE_RELATIVE_PATH = process.env.REACT_APP_API_RELATIVE_PATH || '/v1/api/';

export const token = sessionStorage.access_token;

export const tenantId = sessionStorage.getItem('tenantId');

export const axiosInstance = axios.create({    
    baseURL: API_BASE_PATH + tenantId + API_BASE_RELATIVE_PATH
});


axiosInstance.interceptors.request.use((config:any) => {
    config.headers = { ...config.headers, ...authHeader() };
    config.timeout =  3000000; 
    return config;
 }, (error:any) => {
    return Promise.reject(error);
});

export function authHeader() {
    return {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json',
        'cache': 'no-cache'
    };
}