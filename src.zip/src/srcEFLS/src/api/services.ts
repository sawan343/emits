import { AUTHORIZE_API_BASE_PATH, authHeader, axiosInstance, token } from './axiosClient';
import { ENDPOINT } from "./api-enums";
import { COOKIE_SET_ERROR, INTERNAL_SERVER_ERROR, INTERNAL_SERVER_ERROR_MESSAGE, SESSION_VALID, UNKOWN_ERROR, UN_AUTHORIZED_ERROR, UN_AUTHORIZED_ERROR_MESSAGE, XSRF_SESSION_DURATION, XSRF_SESSION_NAME } from '../constant/global';
import EflsConfigDetail from '../models/EflsConfigDetail';
import {tenantId} from './axiosClient';
import axios from 'axios';

export const getUserRoles = async () => {    
    // return { 
    // //    userPermission: ['Emission Factor Standard Viewer'], 
    //   userPermission: ['Emission Factor Standard Configurator'], 
    //    errorMessage: []
    // };

    try {
        const config = { headers: { "content-type": "application/json",  'Authorization': 'Bearer ' + token } };

        const response = await axios.post(AUTHORIZE_API_BASE_PATH, '', config);
        if (response && response.data && (response.status >= 200 && response.status < 300)){
            return { 
                userPermission: response.data.userPermission, 
               errorMessage: []
            };
        }
        else if (response.status.toString().includes('401') || response.status.toString().includes('403')) {
            return { 
                errorMessage: UN_AUTHORIZED_ERROR,
                userPermission: [] 
           };
        }
        else
            return { 
                errorMessage: INTERNAL_SERVER_ERROR, 
                userPermission: []
            };        
    } catch (e: any) {
        console.info(e);
        if (e.message.toString().includes('401') || e.message.toString().includes('403')) {
            return { 
                errorMessage: UN_AUTHORIZED_ERROR_MESSAGE,
                userPermission: [] 
           };
        }
        if (e.message.toString().includes('500') || e.message.toString().includes('502') || e.message.toString().includes('503') || e.message.toString().includes('504')) {
            return { errorMessage: INTERNAL_SERVER_ERROR_MESSAGE, userPermission: [] };
        }
    }
    return { errorMessage: UNKOWN_ERROR, userPermission: [] };
}

export const getAssets = async (params: any[]) => {
    try {
        const config = { headers: { "content-type": "application/json" } };
        const response = await axiosInstance.post(`${ENDPOINT.GETASSETS}?tenant=${tenantId}`, params, config);
        if (response && response.data && response.data.result) {
            return response.data.result;
        }
    } catch (e: any) {
        console.info(e);
        const errorObject = {
            isError: true,
            status: e?.response?.status,
            errorMessage: e?.response?.message
        }
        return errorObject;
    }
}

export const getEmissionFactorfStandard = async (data: any) => {
    try {
        const config = { headers: { "content-type": "application/json" } };
        let response = await axiosInstance.get(`${ENDPOINT.GETEFSTANDARD}?path=${data}`, config);
        if (response && response.data && response.data.result) {
            return response.data.result;
        }
    } catch (e: any) {
        console.error(e);
        const errorObject = {
            isError: true,
            status: e?.response?.status,
            message: e?.response?.statusText
        }
        return errorObject;
    }
}

export const getAssetTypes = async (params: any[]) => {
    try {
        const config = { headers: { "content-type": "application/json" } };
         let response = await axiosInstance.post(ENDPOINT.GETASSETTYPES + `?tenant=${tenantId}`, params, config);
        // let response = await axiosInstance.get(ENDPOINT.GETASSETTYPES + `?tenant=${tenantId}`, config);
        return response.data.result;
    } catch (e: any) {
        console.error(e);
        const errorObject = {
            isError: true,
            status: e?.response?.status,
            message: e?.response?.statusText
        }
        return errorObject;
    }
}

export const saveEflsConfigDetails = async (params: any[]) => {
    try {
        const config = { headers: { "content-type": "application/json" } };
        const response = await axiosInstance.post(`${ENDPOINT.SAVEEFLSCONFIGDETAIL}?tenant=${tenantId}`, params, config);
        response.data.forEach((ele:any) => {
            if(!ele.isSuccess){
                return  {
                    isSuccess: false                    
                }
            }
        });
        return { isSuccess: true };
    } catch (e: any) {
        console.error(e);
        const errorObject = {
            isSuccess: false,
            status: e?.response?.status,
            message: e?.response?.statusText
        }
        return errorObject;
    }
}

export const getAllEflsConfigDetails = async () => {
    try {
        const config = { headers: { "content-type": "application/json" } };        
        const response = await axiosInstance.get(`${ENDPOINT.GETALLEFLSCONFIGDETAIL}?tenant=${tenantId}`, config);

        return response.data.result as EflsConfigDetail[];
    } catch (e: any) {
        console.error(e);
        const errorObject = {
            isError: true,
            status: e?.response?.status,
            message: e?.response?.statusText
        }
        return errorObject;
    }
}

export const deleteEflsConfigDetails = async (params: any[]) => {
    try {
        const config = { headers: { "content-type": "application/json" } };
        const response = await axiosInstance.post(`${ENDPOINT.DELETEEFLSCONFIGDETAIL}?tenant=${tenantId}`, params, config);

        response.data.forEach((ele:any) => {
            if(!ele.isSuccess){
                return {
                    isSuccess: false                    
                }
            }
        });
        return { isSuccess: true };
    } catch (e: any) {
        console.error(e);
        const errorObject = {
            isSuccess: false,
            status: e?.response?.status,
            message: e?.response?.statusText
        }
        return errorObject;
    }
}


export const getEFLSBrowsableAPIData = async (data: any) => {
    try {
        const config = { headers: { "content-type": "application/json" } };
        let response = await axiosInstance.get(`${ENDPOINT.GETEFSTANDARD}?path=${data}`, config);
        if (response && response.data && response.data.result) {
            return response.data.result;
        }
    } catch (e: any) {
        console.error(e);
        const errorObject = {
            isError: true,
            status: e?.response?.status,
            message: e?.response?.statusText
        }
        return errorObject;
    }
}





