export enum ENDPOINT {
  GETAUTHTOKEN = "AuthToken",
  GETUSERROLES = "AuthorizeUser_v1",
  GETASSETTYPES = "assettypes",
  GETASSETS = "assetsbyassettypes",
  GETEFSTANDARD = "getemissionfactorstoredetailsbypath",
  SAVEEFLSCONFIGDETAIL = "eflsconfigdetails",
  DELETEEFLSCONFIGDETAIL = "deleteeflsconfigdetails",
  GETALLEFLSCONFIGDETAIL = "getalleflsconfigdetails"
}