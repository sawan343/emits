
import './Configuration.scss'
import { Card } from 'primereact/card';
import 'primeicons/primeicons.css';

import React, { useEffect, useRef, useState } from 'react';
import { DataTable, DataTableSelectAllChangeEvent } from 'primereact/datatable';

import { Column } from 'primereact/column';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { deleteEflsConfigDetails, getAllEflsConfigDetails, getAssetTypes, getAssets, getEFLSBrowsableAPIData, getEmissionFactorfStandard, getUserRoles, saveEflsConfigDetails } from '../../api/services';
import AssetDetail from '../../models/Assets';
import AssetType from '../../models/AssetType';
import EflsConfigDetail from '../../models/EflsConfigDetail';
import EmissionFactorfStandard from '../../models/EmissionFactorStandard';
import isEmpty from '../../utils/isEmpty';
import { CONFIGURED_ASSETTYPES, CRITICAL_DESC, CRITICAL_TITLE, DELETE_FAILED_DESC, DELETE_SUCCESS_DESC, EDIT_DISABLED, FAILED_DESC, FAILED_TITLE, ROLE_EMISSION_EFLS_CONFIGURATOR, ROLE_EMISSION_EFLS_VIEWER, SAVE_FAILED_DESC, SUCCESS_DESC, SUCCESS_TITLE, UN_AUTHORIZED_ERROR_MESSAGE, DELETE_DISABLED, EFLS_SUBTITLE, EFLS_TITLE } from '../../constant/global';
import { Toast } from 'primereact/toast';
import { showNotification } from '../../Notification/Notification';
import { ProgressSpinner } from 'primereact/progressspinner';
import { Tooltip } from 'primereact/tooltip';

import { Tree, TreeNodeTemplateOptions, TreeTogglerTemplateOptions } from 'primereact/tree';
import { TreeNode } from 'primereact/treenode';

function EflsConfiguration() {

    const [showSpinner, setShowSpinner] = useState(false);
    const toast = useRef<Toast>(null);
    const [isFormvalid, setIsFormvalid] = useState<boolean>(false);
    const [isEnableEditBtn, setIsEnableEditBtn] = useState<boolean>(false);
    const [isEnableDeleteBtn, setIsEnableDeleteBtn] = useState<boolean>(false);
    const [configurationslist, setConfigurationsList] = useState<EflsConfigDetail[]>([]);
    const [getconfigurationslist, setGetConfigurationsList] = useState<EflsConfigDetail[]>([]);

    const [efstandarddata, setEfstandarddata] = useState<string[]>(['']);

    const [allAssetTypedata, setAllAssetTypedata] = useState<AssetType[]>();
    const [allAssetdata, setAllAssetdata] = useState<AssetDetail[]>();

    const [maxRowIndex, setMaxRowIndex] = useState<number>(0);

    const [isPageLoading, setIsPageLoading] = useState(true);
    const [eflsConfiguratorRole, setEflsConfiguratorRole] = useState<boolean>(false);
    const [eflsViewerRole, setEflsViewerRole] = useState<boolean>(false);
    const [errorMessageToDisplay, setErrorMessageToDisplay] = useState<string>('');
    const [deletedEflsConfigData, setDeletedEflsConfigData] = useState<EflsConfigDetail[]>([]);
    const [guidInitialId] = useState('00000000-0000-0000-0000-000000000000');

    const [eflsConfigDefaultRow, setEflsConfigDefaultRow] = useState<EflsConfigDetail>(

        {
            id: guidInitialId,
            customerId: guidInitialId,
            customerName: '',
            assetId: guidInitialId,
            assetName: '',
            assetDisplayName: '',
            assetTypeId: '',
            assetTypeName: '',
            parentId: guidInitialId,
            parentName: '',
            scope1: false,
            scope2: false,
            scope3: false,
            eFstandard: '',
            editMode: false,
            eFversion: '',
            instancelist: [],
            versionlist: [],
            isAssetTypedropdownValid: true,
            isAssetdropdownValid: true,
            iseFStandarddropdownValid: true,
            iseFVersiondropdownValid: true,
            isShowAddBtn: true,
            isEnableAddBtn: false,
            isRowValid: false,
            rowIndex: 0,
            editFlag: false,
            enableRowEdit: true,
            isAllowEditDelete: true,
            firstRow: true
        }
    );

    const [configurations, setConfigurations] = useState<EflsConfigDetail[]>([{ ...eflsConfigDefaultRow }]);
    const [saveConfigurations, setSaveConfigurations] = useState<EflsConfigDetail[]>([]);
    const [browseViewConfigurations, setBrowseViewConfigurations] = useState<EflsConfigDetail[]>([]);
    const [browseView, setBrowseView] = useState<boolean>(false);
    const [browseTreeNodes, setBrowseTreeNodes] = useState<any[]>([]);
    const [copyBrowsePath, setBrowsePath] = useState<string>('');
    const [selectedTreeNodeKey, setSelectedTreeNodeKey] = useState<any>('');


    const addnewrow = (type: any, rowindex: any) => {

        let firstrowdata = configurationslist.find(p => p.rowIndex === 0) as any;

        firstrowdata.rowIndex = maxRowIndex;
        firstrowdata.firstRow = false;
        firstrowdata.enableRowEdit = false;
        configurationslist.splice(0, 0, { ...eflsConfigDefaultRow });
        setConfigurationsList([...configurationslist]);
    }

    const getAssetTypeOptions = () => {
        return allAssetTypedata?.map((item: any) => {
            return {
                value: item.assetTypeId,
                label: item.assetTypeName
            }
        });
    }
    const bindassettypedata = (options: any) => {
        return (
            (options.firstRow) ? <>
                <Dropdown
                    className={(options.isAssetTypedropdownValid ? "valid-dropdown" : "invalid-dropdown")}
                    value={options.assetTypeId}
                    options={getAssetTypeOptions()}
                    onChange={(e) => handleAssetTypedropdownchange(options, e.value)}
                    placeholder="Select a Asset Type"
                    panelClassName='efls-config-dropdown-panel'
                    disabled={eflsViewerRole && !eflsConfiguratorRole}
                />
            </> :
                (options.enableRowEdit) ? <>
                    <Tooltip className='efls-tooltip-error-info' position="top" target=".tooltip-info" />
                    <div className='disabled-column'>{options.assetTypeName}</div>
                    <span data-pr-tooltip={EDIT_DISABLED} className='tooltip-info display-error-info'>{infoIcon()} </span>

                </>
                    :
                    <><div> {options.assetTypeName} </div></>
        )
    };

    const bindinstancedata = (options: any) => {
        return ((options.firstRow) ?
            <>
                <Dropdown
                    className={options.isAssetdropdownValid ? "valid-dropdown custom-dropdown" : "invalid-dropdown"}
                    value={options.assetId}
                    options={options.instancelist}
                    onChange={(e) => handleInstancedatachange(options, e.value)}
                    placeholder="Select a Instance Name"
                    panelClassName='efls-config-dropdown-panel'
                />
            </>
            :
            (options.enableRowEdit) ? <>

                <Tooltip className='efls-tooltip-error-info' position="top" target=".tooltip-info" />
                <div className='disabled-column'>{options.assetName}</div>
                <span data-pr-tooltip={EDIT_DISABLED} className='tooltip-info display-error-info'>{infoIcon()} </span>
            </>
                :
                <>
                    <div> {options.assetName} </div>
                </>
        );
    };

    const bindefstandarddata = (options: any) => {
        return (
            (options.firstRow) ? <>
                <Dropdown
                    className={options.iseFStandarddropdownValid ? "valid-dropdown" : "invalid-dropdown"}
                    value={options.eFstandard}
                    options={efstandarddata}
                    onChange={(e) => handleEFdropdownchange(options, e.value)}
                    placeholder="Select a Emission Factor Standard"
                    panelClassName='efls-config-dropdown-panel'
                    disabled={options.editMode ? !options.isAllowEditDelete : false}
                />
            </>
                :
                (options.enableRowEdit && !options.isAllowEditDelete) ? <>
                    <Tooltip className='efls-tooltip-error-info' position="top" target=".tooltip-info" />
                    <div className='disabled-column'>{options.eFstandard}</div>
                    <span data-pr-tooltip={EDIT_DISABLED} className='tooltip-info display-error-info'>{infoIcon()} </span>
                </>
                    :
                    (options.enableRowEdit && options.isAllowEditDelete) ? <>
                        <Dropdown
                            className={options.iseFStandarddropdownValid ? "valid-dropdown" : "invalid-dropdown"}
                            value={options.eFstandard}
                            options={efstandarddata}
                            onChange={(e) => handleEFdropdownchange(options, e.value)}
                            placeholder="Select a Emission Factor Standard"
                            panelClassName='efls-config-dropdown-panel'
                        />
                    </>
                        :
                        <><div>{options.eFstandard}</div></>
        );
    };

    const bindversionyeardata = (options: any) => {
        return (
            (options.enableRowEdit) ? <Dropdown
                className={options.iseFVersiondropdownValid ? "valid-dropdown" : "invalid-dropdown"}
                value={options.eFversion}
                options={options.versionlist}
                onChange={(e) => handleVersiondropdownchange(options, e.value)}
                placeholder="Select a Version"
                panelClassName='efls-config-dropdown-panel'

            /> :
                <> <div> {options.eFversion} </div></>
        );
    };

    const handleAssetTypedropdownchange = (options: any, value: any) => {

        const rowdata: any = configurationslist.find(p => p.rowIndex === options.rowIndex);
        rowdata.assetTypeName = allAssetTypedata?.find(p => p.assetTypeId === value)?.assetTypeName;
        rowdata.assetTypeId = value;
        rowdata.isAssetTypedropdownValid = !isEmpty(value);
        rowdata.assetId = '';
        rowdata.assetName = '';
        rowdata.isEnableAddBtn = checkRowValid(options);
        rowdata.instancelist = getAssetDropDownDataByAssetType(value) as any[];
        setConfigurationsList([...configurationslist]);
    }

    const handleInstancedatachange = (options: any, value: any) => {
        configurationslist.forEach(p => {
            if (p.rowIndex === options.rowIndex) {
                (p.assetName as any) = allAssetdata?.find(p => p.id === value)?.assetName;
                p.assetId = value;
                p.isAssetdropdownValid = !isEmpty(value);
                p.isEnableAddBtn = checkRowValid(options);
            };
        }
        );
        setConfigurationsList([...configurationslist]);
    }

    const handleEFdropdownchange = (options: any, value: any) => {
        configurationslist.forEach(p => {
            if (p.rowIndex === options.rowIndex) {
                p.eFstandard = value;
                p.iseFStandarddropdownValid = !isEmpty(value);
                p.eFversion = '';
                p.isEnableAddBtn = checkRowValid(options);
            }
        });
        setConfigurationsList([...configurationslist]);

        setShowSpinner(true);

        Promise.all([
            fetchVersion(options, value)
        ]).then(function (responses) {
            setShowSpinner(false);
        }).then(function (data) {
        }).catch(function (error) {
            setShowSpinner(false);
        });
    }

    const handleVersiondropdownchange = (options: any, value: any) => {
        configurationslist.forEach(p => {
            if (p.rowIndex === options.rowIndex) {
                p.eFversion = value;
                p.iseFVersiondropdownValid = !isEmpty(value);
                p.isEnableAddBtn = checkRowValid(options);
            }
        });
        setConfigurationsList([...configurationslist]);
    }



    const infoIcon = () => {
        return (<>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7 9.4V7M7 4.6H7.006M13 7C13 10.3137 10.3137 13 7 13C3.68629 13 1 10.3137 1 7C1 3.68629 3.68629 1 7 1C10.3137 1 13 3.68629 13 7Z" stroke="#005EAC" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        </>)
    }
    const deleteIcon = () => {

        return (<>
            <svg width="12" height="14" viewBox="0 0 12 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M1 3.4H2.11111M2.11111 3.4H11M2.11111 3.4V11.8C2.11111 12.1183 2.22817 12.4235 2.43655 12.6485C2.64492 12.8736 2.92754 13 3.22222 13H8.77778C9.07246 13 9.35508 12.8736 9.56345 12.6485C9.77183 12.4235 9.88889 12.1183 9.88889 11.8V3.4H2.11111ZM3.77778 3.4V2.2C3.77778 1.88174 3.89484 1.57652 4.10322 1.35147C4.31159 1.12643 4.5942 1 4.88889 1H7.11111C7.4058 1 7.68841 1.12643 7.89679 1.35147C8.10516 1.57652 8.22222 1.88174 8.22222 2.2V3.4" stroke="#303030" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>

        </>)

    };
    const editIcon = () => {

        return (
            <>  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M6.36744 2.26512H2.19276C1.87642 2.26512 1.57304 2.39078 1.34935 2.61447C1.12567 2.83816 1 3.14154 1 3.45788V11.8072C1 12.1236 1.12567 12.427 1.34935 12.6506C1.57304 12.8743 1.87642 13 2.19276 13H10.5421C10.8585 13 11.1618 12.8743 11.3855 12.6506C11.6092 12.427 11.7349 12.1236 11.7349 11.8072V7.63256M10.8403 1.37054C11.0776 1.13329 11.3994 1 11.7349 1C12.0704 1 12.3922 1.13329 12.6295 1.37054C12.8667 1.6078 13 1.92959 13 2.26512C13 2.60065 12.8667 2.92244 12.6295 3.15969L6.96382 8.82532L4.57829 9.42171L5.17468 7.03618L10.8403 1.37054Z" stroke="#303030" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            </>);
    }

    const addIcon = () => {
        return (
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M6.94737 0.947368C6.94737 0.424151 6.52322 0 6 0C5.47678 0 5.05263 0.424151 5.05263 0.947368V5.05263H0.947368C0.424151 5.05263 0 5.47678 0 6C0 6.52322 0.424151 6.94737 0.947368 6.94737H5.05263V11.0526C5.05263 11.5758 5.47678 12 6 12C6.52322 12 6.94737 11.5758 6.94737 11.0526V6.94737H11.0526C11.5758 6.94737 12 6.52322 12 6C12 5.47678 11.5758 5.05263 11.0526 5.05263H6.94737V0.947368Z" fill="#005EAC" />
            </svg>
        );
    }

    const searchIcon = () => {
        return (<>   <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14 14L11.1 11.1M12.6667 7.33333C12.6667 10.2789 10.2789 12.6667 7.33333 12.6667C4.38781 12.6667 2 10.2789 2 7.33333C2 4.38781 4.38781 2 7.33333 2C10.2789 2 12.6667 4.38781 12.6667 7.33333Z" stroke="#303030" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        </>);
    }

    const checkRowValid = (data: any) => {
        let isvalidcheckflag = true;
        setRowEnableDisableFlag(data.rowIndex, true);

        configurationslist.forEach(p => {
            if (data.assetTypeId === p.assetTypeId && p.assetId === data.assetId && p.eFstandard === data.eFstandard && data.eFversion === p.eFversion && p.rowIndex !== data.rowIndex) {
                isvalidcheckflag = false;
                setRowEnableDisableFlag(data.rowIndex, false);
            }
        });

        const isValid = (!isEmpty(data.eFversion) && !isEmpty(data.assetId) && !isEmpty(data.assetTypeId) && !isEmpty(data.eFstandard));
        data.isRowValid = (isValid && isvalidcheckflag);

        checkFormValid(data);
        return (isValid && isvalidcheckflag);
    }

    const checkFormValid = (data: any) => {
        const emptyrow = configurationslist.find(p => (isEmpty(p.eFversion) && isEmpty(p.assetId) && isEmpty(p.assetTypeId) && isEmpty(p.eFstandard)
            && p.isAssetTypedropdownValid && p.isAssetdropdownValid && p.iseFStandarddropdownValid && p.iseFVersiondropdownValid));
        let result;
        if (emptyrow === undefined) {
            result = configurationslist.find(p => p.isRowValid === false)
        }
        else {
            result = configurationslist.find(p => p.isRowValid === false && p.rowIndex !== emptyrow.rowIndex)
        }

        if (result === undefined) {
            let firstRowData = configurationslist.find(p => p.firstRow === true &&
                (!isEmpty(p.eFversion) && !isEmpty(p.assetId) && !isEmpty(p.assetTypeId) && !isEmpty(p.eFstandard)) &&
                (p.isAssetTypedropdownValid && p.isAssetdropdownValid && p.iseFStandarddropdownValid && p.iseFVersiondropdownValid)) as any;
            if (firstRowData) {
                const flag = saveConfigurations.findIndex(p => p.assetId === firstRowData?.assetId);
                if (flag === -1) {
                    setSaveConfigurations([firstRowData, ...saveConfigurations]);
                }
            }
            else if (data !== null) {
                const rowdata: any = configurationslist.find(p => p.rowIndex === data.rowIndex);
                setSaveConfigurations([rowdata, ...saveConfigurations]);
            }
        }
        setIsFormvalid(result === undefined);
    }

    const setRowEnableDisableFlag = (rowIndex: number, flag: boolean) => {

        const row: any = configurationslist.find((item: any) => item.rowIndex === rowIndex);
        row.isAssetTypedropdownValid = flag;
        row.isAssetdropdownValid = flag;
        row.iseFStandarddropdownValid = flag;
        row.iseFVersiondropdownValid = flag;
    }

    const handleCancelClick = () => {
        resetForm();
        setBrowseView(false);
        setBrowseTreeNodes([]);
    }

    const resetForm = () => {
        setIsEnableEditBtn(false);
        setIsEnableDeleteBtn(false);
        setEflsConfigDefaultRow({ ...eflsConfigDefaultRow, rowIndex: 0 });
        setConfigurations([eflsConfigDefaultRow]);
        setIsFormvalid(false);
        setDeletedEflsConfigData([]);
        setSaveConfigurations([]);
        const data = getconfigurationslist.map(item => ({ ...item }));
        setConfigurationsList(data);
    }

    const handlesaveclick = async (e: any) => {

        e.preventDefault()
        setShowSpinner(true);

        const data = configurationslist.filter((obj) => {
            return obj.assetTypeId !== '' && obj.assetName !== '' && obj.eFstandard !== '';
        });

        const emptyrow = configurationslist.find(p => (isEmpty(p.eFversion) && isEmpty(p.assetId) && isEmpty(p.assetTypeId) && isEmpty(p.eFstandard)));

        if (emptyrow !== undefined) {
            const data = configurationslist.filter((obj) => {
                return obj.assetTypeId !== '' && obj.assetId !== '' && obj.eFstandard !== '' && obj.eFversion !== '';
            });
            setConfigurations(data);
        }


        const filterDeletedData = deletedEflsConfigData.filter(p => p.id !== '00000000-0000-0000-0000-000000000000')
        let successFlag = true;
        await Promise.all([
            (saveConfigurations.length > 0 ? saveEflsConfigDetails(saveConfigurations) : handleclick()),
            (filterDeletedData.length > 0 ? deleteEflsConfigDetails(filterDeletedData) : handleclick())
        ]).then(function (responses: any) {
            responses.forEach((ele: any) => {
                if (!ele.isSuccess) {
                    setShowSpinner(false);
                    showNotification(FAILED_TITLE, SAVE_FAILED_DESC, toast, 'failed');
                    successFlag = false;
                    resetForm();
                }
            });
            if (successFlag) {
                resetForm();
            }
            Promise.all([fetchAllEFLSConfigDetails(),
            fetchAssets()]).then(function (p) {
                setShowSpinner(false);
            }).then(function (data) {
                showNotification(SUCCESS_TITLE, SUCCESS_DESC, toast, 'success');
            }).catch(function (error) {
                setShowSpinner(false);
                showNotification(FAILED_TITLE, FAILED_DESC, toast, 'failed');
            });

        }).catch(function (error) {
            setShowSpinner(false);
            showNotification(FAILED_TITLE, FAILED_DESC, toast, 'failed');
        });
    }

    const handledeleteclick = async (e: any) => {
        e.preventDefault()
        setShowSpinner(true);
        await deleteEflsConfigDetails(deletedEflsConfigData).then(function (responses) {
            if (responses.isSuccess) {
                resetForm();
                Promise.all([fetchAllEFLSConfigDetails(),
                fetchAssets()]).then(function (p) {
                    setShowSpinner(false);
                    showNotification(SUCCESS_TITLE, DELETE_SUCCESS_DESC, toast, 'success');
                }).then(function (data) {
                }).catch(function (error) {
                    setShowSpinner(false);
                    showNotification(FAILED_TITLE, DELETE_FAILED_DESC, toast, 'failed');
                });
            }
            else {
                setShowSpinner(false);
                showNotification(FAILED_TITLE, DELETE_FAILED_DESC, toast, 'failed');
            }
        }).catch(function (error) {
            setShowSpinner(false);
            showNotification(FAILED_TITLE, DELETE_FAILED_DESC, toast, 'failed');
        });
    }

    useEffect(() => {
        let isanyrole: boolean = false;
        setShowSpinner(true);
        setIsPageLoading(true);
        getUserRoles().then((rolesdata) => {
            if (isEmpty(rolesdata.errorMessage)) {

                rolesdata.userPermission?.forEach((role: any) => {
                    if (role === ROLE_EMISSION_EFLS_CONFIGURATOR) {
                        setEflsConfiguratorRole(true);
                        isanyrole = true;
                        return;
                    };
                    if (role === ROLE_EMISSION_EFLS_VIEWER) {
                        setEflsViewerRole(true);
                        isanyrole = true;
                    };
                });

                if (!isanyrole) {
                    setShowSpinner(false);
                    setErrorMessageToDisplay(UN_AUTHORIZED_ERROR_MESSAGE);
                    setIsPageLoading(false);
                }
                Promise.all([
                    fetchAssetType(),
                    fetchAssets(),
                    fetchIntialEFstandards(),
                    fetchAllEFLSConfigDetails(),
                ]).then(function (responses) {
                    setShowSpinner(false);
                    setIsPageLoading(false);
                }).catch(function (error) {
                    setShowSpinner(false);
                    setIsPageLoading(false);
                    showNotification(CRITICAL_TITLE, CRITICAL_DESC, toast, 'failed');
                    console.log(error);
                });
            } else {
                setEflsViewerRole(false);
                setShowSpinner(false);
                setEflsConfiguratorRole(false);
                setErrorMessageToDisplay(rolesdata.errorMessage.toString());
                setIsPageLoading(false);
            }
        });
    }, []);

    const fetchAssetType = async () => {
        let assettypes = await getAssetTypes(CONFIGURED_ASSETTYPES);
        if (assettypes && assettypes.length > 0) {
            console.log(assettypes);
            setAllAssetTypedata(assettypes.sort((a: any, b: any) => b['assetTypeName'] > a['assetTypeName'] ? -1 : 1));
        }
    }

    const fetchAssets = async () => {
        let assetsbytypes = await getAssets(CONFIGURED_ASSETTYPES);
        if (assetsbytypes && assetsbytypes.length > 0) {
            console.log(assetsbytypes);
            setAllAssetdata(assetsbytypes);
        }
    }

    const fetchIntialEFstandards = async () => {
        let efstandards = await getEmissionFactorfStandard("%20");
        if (efstandards && efstandards?.folders?.length > 0) {
            console.log(efstandards.folders);
            const efstandardsname = (efstandards.folders as EmissionFactorfStandard[]).map(p => p.name).sort();
            setEfstandarddata(efstandardsname);
        }
        else
            setEfstandarddata([]);
    }

    const fetchVersion = async (options: any, data: any) => {

        let efstandards = await getEmissionFactorfStandard(data);

        const row: any = configurationslist.find((item: any) => item.rowIndex === options.rowIndex);

        if (efstandards && efstandards.folders.length > 0) {
            console.log(efstandards.folders);
            const efstandardsname = (efstandards.folders as EmissionFactorfStandard[]).map(p => p.name).sort();
            row.versionlist = efstandardsname;
        }
        else {
            row.versionlist = [];
        }
    }

    const fetchAllEFLSConfigDetails = async () => {
        let eflsConfigdata = await getAllEflsConfigDetails() as EflsConfigDetail[];

        if (eflsConfigdata && eflsConfigdata.length > 0) {
            let data = eflsConfigdata.map((obj: EflsConfigDetail, index: number) => {
                return {
                    ...obj,
                    rowIndex: index + 1,
                    isShowAddBtn: false,
                    isEnableAddBtn: false,
                    isAssetTypedropdownValid: true,
                    isAssetdropdownValid: true,
                    iseFStandarddropdownValid: true,
                    iseFVersiondropdownValid: true,
                    instancelist: [],
                    versionlist: [],
                    enableRowEdit: false
                }
            });

            const result = [...data.slice(0, 0), { ...eflsConfigDefaultRow }, ...data.slice(0)];
            setMaxRowIndex(eflsConfigdata.length);
            setConfigurationsList(result);
            const response = result.map(item => ({ ...item }));
            setGetConfigurationsList(response);
            setBrowseViewConfigurations([{ ...result[1] }])
        } else {
            setConfigurationsList([{ ...eflsConfigDefaultRow }]);
            setMaxRowIndex(1);
        }
    }
    const handleclick = () => {
        return { isSuccess: true };
    }
    const handleblankclick = () => {

    }

    const getAssetDropDownDataByAssetType = (assetTypeId: any, currentAssetId: any = "") => {

        let filteredArray = allAssetdata;
        //if (!editflag) 
        {
            const eflsconfigassetidlist = configurationslist.map(p => p.assetId);

            let excludeAssetIds = [...eflsconfigassetidlist];

            const index = excludeAssetIds.indexOf(currentAssetId);

            excludeAssetIds.splice(index, 1);


            filteredArray = allAssetdata?.filter((p) =>
                !excludeAssetIds.some((x) => x === p.id)
            );
        }

        return filteredArray?.filter(p => p.assetTypeId === assetTypeId).map((item: any) => {
            return {
                value: item.id,
                label: item.assetName
            }
        }).sort((a: any, b: any) => b['label'].toLowerCase() > a['label'].toLowerCase() ? -1 : 1);
    }

    const fetchVersionListByName = async (data: any) => {
        let efstandardsname = [""];
        let efstandards = await getEmissionFactorfStandard(data);
        if (efstandards?.isError) {
            showNotification(FAILED_TITLE, FAILED_DESC, toast, 'failed');
            return;
        }
        else if (efstandards && efstandards.folders.length > 0) {
            efstandardsname = (efstandards.folders as EmissionFactorfStandard[]).map(p => p.name)
            return efstandardsname;
        }
        return efstandardsname;
    }

    const setBrowseTableRowAction = (options: any, props: any) => {
        return (
            <Dropdown
                className="config-row-actions"
                placeholder="Select a Asset Type"
                panelClassName='efls-config-dropdown-panel'
                dropdownIcon={<span className="config-row-dropdown-icon pi pi-chevron-down" />}
                disabled={true}
            />);
    }

    const setRowAction = (options: any, props: any) => {
        return (
            (options.firstRow) ?
                (options.isShowAddBtn && eflsConfiguratorRole) ?
                    <Button
                        className={options.isEnableAddBtn ? 'add-btn-active' : 'add-btn-in-active'}
                        disabled={options.isEnableAddBtn ? false : true}
                        onClick={() => options.isEnableAddBtn ? addnewrow(options.type, props.rowIndex) : ''}
                    >
                        {addIcon()}
                    </Button> : ''
                : ((options.enableRowEdit) ?

                    <Button className='cancel-Row-edit-Icon' onClick={() => cancelRowEdit(options)}>
                        {cancelRoweditIcon()}
                    </Button>
                    :
                    <Dropdown
                        className="config-row-actions"
                        options={eflsConfiguratorRole ? (options.isAllowEditDelete ? actionoptions : actionWithNoDeleteoptions) : browseoption}
                        placeholder="Select a Asset Type"
                        panelClassName='efls-config-dropdown-panel'
                        dropdownIcon={<span className="config-row-dropdown-icon pi pi-chevron-down" />}
                        itemTemplate={configRowOptionTemplate}
                        onChange={(e) => handleConfigRowActionsdropdownchange(options, e.value)}
                    />));
    }

    const cancelRowEdit = (data: any) => {
        data.enableRowEdit = false;
        setConfigurationsList([...configurationslist]);

        const prevrowdata: any = getconfigurationslist.find(p => p.rowIndex === data.rowIndex);
        saveConfigurations.splice(saveConfigurations.findIndex(a => a.assetId === data.assetId), 1);

        const rowdata: any = configurationslist.find(p => p.rowIndex === data.rowIndex);
        if (prevrowdata !== null) {
            rowdata.eFstandard = prevrowdata.eFstandard;
            rowdata.eFversion = prevrowdata.eFversion;
        }
        rowdata.enableRowEdit = false;
        setConfigurationsList([...configurationslist]);
    }

    const cancelRoweditIcon = () => {
        return (<><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14 2L2 14M2 2L14 14" stroke="#005EAC" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        </>)
    }

    const actionoptions = [
        { label: 'Browse', value: 'Browse', iconsrc: searchIcon() },
        { label: 'Edit', value: 'Edit', iconsrc: editIcon() },
        { label: 'Delete', value: 'Delete', iconsrc: deleteIcon(), }
    ];

    const browseoption = [
        { label: 'Browse', value: 'Browse', iconsrc: searchIcon() }
    ];

    const actionWithNoDeleteoptions = [
        { label: 'Browse', value: 'Browse', iconsrc: searchIcon() },
        { label: 'Edit', value: 'Edit', iconsrc: editIcon() },
        { label: 'Delete', value: 'Delete', iconsrc: deleteIcon(), deleteError: true }
    ];

    const configRowOptionTemplate = (option: any) => {
        return (
            <div id="config-row-actions-options" className={(option?.deleteError === true) ? 'btn-disabled-delete' : ''}>
                <span className="config-row-actions-icons">{option?.iconsrc}</span>
                <span className="config-row-actions-text">{option?.label}</span>
                <span style={{ width: '20%' }}></span>
            </div>
        );
    };


    const handleConfigRowActionsdropdownchange = async (rowdata: EflsConfigDetail, value: any) => {
        if (value === "Edit") {
            setShowSpinner(true);
            await Promise.all([fetchVersionListByName(rowdata.eFstandard)]).then(function (data: any[]) {
                rowdata.enableRowEdit = true;
                rowdata.versionlist = data[0] as any[];
                rowdata.instancelist = getAssetDropDownDataByAssetType(rowdata.assetTypeId, rowdata.assetId) as any[];
                rowdata.isAssetTypedropdownValid = true;
                rowdata.isAssetdropdownValid = true;
                rowdata.iseFStandarddropdownValid = true;
                rowdata.iseFVersiondropdownValid = true;
                rowdata.enableRowEdit = true;
                rowdata.editMode = true;
                setConfigurationsList([...configurationslist]);
                setShowSpinner(false);
            }).catch(function (error) {
                setShowSpinner(false);
                console.log(error);
            });
        }
        else if (value === "Browse") {
            setShowSpinner(true);
            setBrowseView(true);
            setBrowseViewConfigurations([{ ...rowdata }]);
            var efs = rowdata.eFstandard;
            var ver = rowdata.eFversion;
            const data = await getBrowseAPIPaths(efs + '/' + ver) as any;
            setBrowseTreeNodes(data);
            setShowSpinner(false);
        }
        else {
            if (rowdata.isAllowEditDelete) {
                checkFormValid(null);
                configurationslist.splice(configurationslist.findIndex(a => a.assetId === rowdata.assetId), 1);
                setConfigurationsList(configurationslist);
                if (rowdata.id === '00000000-0000-0000-0000-000000000000') {
                    saveConfigurations.splice(saveConfigurations.findIndex(a => a.assetId === rowdata.assetId), 1);
                    setSaveConfigurations(saveConfigurations);
                }
                setDeletedEflsConfigData([rowdata, ...deletedEflsConfigData]);
            }
        }
    }

    const getBrowseAPIPaths = async (data: string) => {

        let efstandards = await getEFLSBrowsableAPIData(data);
        if (efstandards?.isError) {
            // showNotification(FAILED_TITLE, "Failed to fetch data", toast, 'failed');
            return;
        }
        else if (efstandards && efstandards.folders.length > 0) {
            return (efstandards.folders as EmissionFactorfStandard[])
                .map((item: any) => {
                    return {
                        key: (10 * Math.random()).toString(),
                        label: item.name,
                        leaf: false,
                        icon: 'copyIcon',
                        path: efstandards.path
                    }
                });
        }
        else {
            return ([{
                key: (10 * Math.random()).toString(),
                label: efstandards.path,
                leaf: true,
                icon: 'copyIcon',
                path: efstandards.path
            }]);
        }
    }

    const loadOnExpand = async (event: any) => {
        if (!event.node.children) {
            setShowSpinner(true);

            setTimeout(async () => {
                let node = { ...event.node };

                node.children = [];
                const path = event.node.path + "/" + event.node.label;
                const data = await getBrowseAPIPaths(path);
                if (data && data.length > 0) {
                    setBrowsePath(path);
                    event.node.children = data;
                } else {
                    event.node.children = [{
                        key: (10 * Math.random()).toString(),
                        label: event.node.path + '/' + event.node.label,
                        leaf: true,
                        icon: 'copyIcon',
                        path: event.node.path + '/' + event.node.label
                    }];
                }
                setShowSpinner(false);
            }, 200);
        }
    }

    const handleCopyBrowsePath = (node: any) => {
        if (node.leaf) {
            navigator.clipboard.writeText(node.label);
        } else {
            navigator.clipboard.writeText(node.path + '/' + node.label);
        }
    }

    const rowClassName = (data: any) => (data.enableRowEdit ? 'tr-edit-mode' : '');

    const nodeTemplate = (node: TreeNode, options: TreeNodeTemplateOptions) => {
        return <><div className={options.className}>{node.label} </div>;
            <span data-pr-tooltip="Copy Path" className="showCopyIcon copy-tooltip-info" onClick={() => handleCopyBrowsePath(node)} ></span>
            <Tooltip className='efls-copy-path-tooltip-error-info' position="bottom" target=".copy-tooltip-info" />
        </>
    }

    return (
        <div id="div-main-configuration">
            {showSpinner &&
                <div className='div-spinner'>
                    <ProgressSpinner className='spinner' strokeWidth="4" />
                </div>
            }

            {((eflsConfiguratorRole || eflsViewerRole)) &&
                <>
                    <Toast ref={toast} position="top-right" />
                    <div id='title-card' title="CONFIGURATION">
                        <span id='div-config-title'>
                            {EFLS_TITLE}
                        </span>
                    </div>

                    <div id='div-table-tobe-configured-title-card' title="CONFIGURATION">
                        <span id='div-config-sub-title'>
                            {EFLS_SUBTITLE}
                        </span>
                    </div>
                    <div id="div-config-details-with-buttons">
                        <span id='div-config-desc'>
                            Select from the drop down to configure and save to add to the list.
                        </span>

                        <div id="btn-save-cancel-group">
                            {browseView && <Button id="btn-cancel" className='btn-cancel' label="Go Back" onClick={() => { handleCancelClick() }} />}
                            {(eflsConfiguratorRole && !browseView) &&
                                <>
                                    <Button id="btn-cancel" className='btn-cancel' label="Cancel" onClick={() => { handleCancelClick() }} />
                                    <Button id="btn-save" className={isFormvalid ? 'btn-save save-btn-active' : 'btn-save save-btn-in-active'} label="Save" onClick={isFormvalid ? handlesaveclick : handleblankclick} />
                                </>}
                        </div>
                    </div>

                    {!browseView && (<Card id="table-to-be-configured" className='p-fluid'>
                        <DataTable id="data-table-to-be-configured" value={configurationslist} //editMode="row" 
                            rowClassName={rowClassName} dataKey="rowIndex" tableStyle={{ minWidth: '50rem' }}>
                            <Column field="assetTypeName" header="ASSET TYPE" body={(options) => bindassettypedata(options)} style={{ width: '20%' }}></Column>
                            <Column field="assetName" header="INSTANCE NAME" body={(options) => bindinstancedata(options)} style={{ width: '20%' }}></Column>
                            <Column field="eFstandard" header="EMISSION FACTOR STANDARD" body={(options) => bindefstandarddata(options)} style={{ width: '20%' }}></Column>
                            <Column field="eFversion" header="VERSION" body={(options) => bindversionyeardata(options)} style={{ width: '20%' }}></Column>
                            <Column rowEditor body={setRowAction} style={{ width: '2%' }}></Column>
                        </DataTable>
                    </Card>
                    )}

                    {browseView && (<><Card id="table-to-be-configured" className='p-fluid div-browsable-api'>
                        <DataTable id="data-table-to-be-configured" value={browseViewConfigurations} editMode="row" dataKey="rowIndex"
                            tableStyle={{ minWidth: '50rem' }}>
                            <Column field="assetTypeName" header="ASSET TYPE" body={(options) => bindassettypedata(options)} style={{ width: '20%' }}></Column>
                            <Column field="assetName" header="INSTANCE NAME" body={(options) => bindinstancedata(options)} style={{ width: '20%' }}></Column>
                            <Column field="eFstandard" header="EMISSION FACTOR STANDARD" body={(options) => bindefstandarddata(options)} style={{ width: '20%' }}></Column>
                            <Column field="eFversion" header="VERSION" body={(options) => bindversionyeardata(options)} style={{ width: '20%' }}></Column>
                            <Column rowEditor body={setBrowseTableRowAction} style={{ width: '2%' }}></Column>
                        </DataTable>
                    </Card>


                        <div id='div-browse-tree' className="card flex justify-content-left">

                            <Tree value={browseTreeNodes} nodeTemplate={nodeTemplate}
                                onExpand={loadOnExpand}
                            />

                        </div>
                    </>
                    )}
                </>}

            {(!isPageLoading && (!eflsConfiguratorRole && !eflsViewerRole)) &&
                <div id="div-no-data-message">
                    <span >{errorMessageToDisplay}</span>
                </div>
            }
            {(!isPageLoading) &&
                <div id="div-no-data-message">

                </div>
            }
        </div>
    );
}
export default EflsConfiguration;
