import React from 'react';
import './Notification.scss'

export function showNotification(title: string , message : string, toast: any, type: any) {

  switch(type){
    case 'success' :
      toast.current?.show({
        severity: "success",
        //sticky: true,
        life: 3000,
        content: (
          <div className="toast-card">
            <span id="budge-span-success">
              <span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                className="budge-icon"
                fill="currentColor"
                viewBox="0 0 14 14"
              >
                <path d="M2.5 8a5.5 5.5 0 0 1 8.25-4.764.5.5 0 0 0 .5-.866A6.5 6.5 0 1 0 14.5 8a.5.5 0 0 0-1 0 5.5 5.5 0 1 1-11 0z" />
                <path d="M15.354 3.354a.5.5 0 0 0-.708-.708L8 9.293 5.354 6.646a.5.5 0 1 0-.708.708l3 3a.5.5 0 0 0 .708 0l7-7z" />
              </svg>
              </span>
              <span id='info-success'>
                  SUCCESS
              </span>            
            </span>
            {"  "}
            <div className="toast-message">{title}</div>
            <div className="toast-desc">{message}</div>
          </div>
        )
      });    
    break;
    case 'failed':
      toast.current?.show({
        severity: "failed",
       // sticky: true,
        life: 3000,
        content: (
          <div className="toast-card">
            <span id="budge-span-failed">
              <span>
                <svg width="16" height="16" 
                  className="budge-icon"
                  viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M3.28634 3.28671L12.713 12.7134M14.6663 8.00004C14.6663 11.6819 11.6816 14.6667 7.99967 14.6667C4.31778 14.6667 1.33301 11.6819 1.33301 8.00004C1.33301 4.31814 4.31778 1.33337 7.99967 1.33337C11.6816 1.33337 14.6663 4.31814 14.6663 8.00004Z" 
                  stroke="#D60B13" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </span>
              <span id='info-failed'>
                  FAILED
              </span>            
            </span>
            {"  "}
            <div className="toast-message">{title}</div>
            <div className="toast-desc">{ message }</div>
          </div>
        )
      })
    break;
    case 'info':
      toast.current?.show({
        severity: "success",
        sticky: true,
        life: 3000,
        content: (
          <div className="toast-card">
            <span id="budge-span-success">
              <span>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M3.28634 3.28671L12.713 12.7134M14.6663 8.00004C14.6663 11.6819 11.6816 14.6667 7.99967 14.6667C4.31778 14.6667 1.33301 11.6819 1.33301 8.00004C1.33301 4.31814 4.31778 1.33337 7.99967 1.33337C11.6816 1.33337 14.6663 4.31814 14.6663 8.00004Z" 
                  stroke="#D60B13" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </span>
              <span id='info-success'>
                  FAILED
              </span>            
            </span>
            {"  "}
            <div className="toast-message">{title}</div>
            <div className="toast-desc">{ message }</div>
          </div>
        )
      })
      break;
    }    
  };