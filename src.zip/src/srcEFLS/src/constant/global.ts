export enum CONSTANTS {
  SORT_BY_ASCENDING = "asc",
  SORT_BY_DESCENDING = "dsc",
}

export const XSRF_SESSION_NAME: string = "BULKCONFIGUI_APISID";
export const XSRF_SESSION_DURATION: number = 8;
export const API_TIMEOUT_NAME: string = 'API_TIMEOUT';

export const UN_AUTHORIZED_ERROR = "UnAuthorizedError";
export const INTERNAL_SERVER_ERROR = "InternalServerError";
export const SERVER_ERROR = "ServerError";
export const COOKIE_SET_ERROR = "CookieSetError";
export const SESSION_VALID = "SessionOK";
export const UNSUPPORTED_BROWSER_ERROR = "UnSupportedBrowserError"
export const DISABLED_COOKIE_ERROR = "CookiedNotEnabledError"
export const UNSUPPORTED_DEVICE_ERROR = "UnSupportedDeviceError"

export const UNKOWN_ERROR = "UnkownError. Please contact the administrator to get support.";
export const UN_AUTHORIZED_ERROR_MESSAGE = "You don't have configuration access to this page. Please contact the administrator to get the access.";
export const INTERNAL_SERVER_ERROR_MESSAGE = "We apologize for the inconvenience, but we are unable to process your request at this time. Please contact the administrator to get support.";
export const UNSUPPORTED_BROWSER_ERROR_MESSAGE = "It looks like you may be using a web browser version that we dont support. Make sure you are using the most recent version of your browser.";
export const CONFIGURED_ASSETTYPES: String[] = ['Enterprise', 'Region', 'Site']

export const SUCCESS_TITLE = "Information saved.";
export const SUCCESS_DESC = "The configured data has been successfully mapped and saved.";

export const DELETE_SUCCESS_DESC = "The configured data has been deleted successfully.";

export const FAILED_TITLE = "Information not saved.";
export const FAILED_DESC = "Incorrect field selection, kindly map the right data.";

export const SAVE_FAILED_DESC = "Unable to Save the data.";
export const DELETE_FAILED_DESC = "Unable to Delete the data.";

export const CRITICAL_TITLE = "";
export const CRITICAL_DESC = "Something wasn’t right";
export const ROLE_EMISSION_EFLS_CONFIGURATOR = "Emission Factor Standard Configurator";
export const ROLE_EMISSION_EFLS_VIEWER= "Emission Factor Standard Viewer";

export const EDIT_DISABLED  = "This standard is used in the model and calculations. Once these are de-referenced the Edit is allowed.";

export const DELETE_DISABLED  = "This standard is used in the model and calculations. Once these are de-referenced the delete is allowed.";

export const EFLS_SUBTITLE  = "Emission Factor Standard Mapping & List.";
export const EFLS_TITLE  = "Emission Factor Standard Configuration.";




