export default interface  EmissionFactorfStandard{
    displayName: string,
    name: string,
    path: string,
}