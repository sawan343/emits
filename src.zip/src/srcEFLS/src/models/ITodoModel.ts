export default interface ITodoModel {
    id?: string;
    title: string;
    description?: string;
    dateCreated?: Date;
    completed?: boolean;
}