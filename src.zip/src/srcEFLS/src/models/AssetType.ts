export default interface AssetType {

    assetTypeId: string,
    customerId: string,
    assetTypeName: string,
    displayname: string,
    labels: any,
    createdOn: Date,
    createdBy: string,
    modifiedOn: Date,
    modifiedBy: string
    
}