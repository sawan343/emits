export default interface EflsConfigDetail{
      id: string,
      customerId: string
      customerName: string,
      assetId: string
      assetName: string,
      assetDisplayName: string,
      assetTypeId: string
      assetTypeName: string,
      parentId: string
      parentName: string,
      scope1: boolean,
      scope2: boolean,
      scope3: boolean,
      eFstandard: string,
      eFversion: string,
      editMode : boolean;


      instancelist: any[],
      versionlist: any[]


      isAssetTypedropdownValid: boolean,
      isAssetdropdownValid: boolean,
      iseFStandarddropdownValid: boolean,
      iseFVersiondropdownValid: boolean,

      isShowAddBtn : boolean,
      isEnableAddBtn : boolean,
      isRowValid : boolean,
      rowIndex: number,
      editFlag: boolean,
      enableRowEdit: boolean,
      firstRow: boolean,
      isAllowEditDelete:boolean
}