export default interface AssetDetail{
    customerId: string,
      id: string,
      assetName: string,
      externalId: string,
      displayName: string,
      pathLocation: string,
      qualifiedPath: string,
      assetTypeId: string,
      assetTypeName: string,
      parentId: string,
      parent: string,
      createdOn?: Date,
      createdBy: string,
      modifiedOn?: Date,
      modifiedBy: string
}