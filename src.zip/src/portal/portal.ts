// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

import { useContext, useEffect } from 'react';
import { contentId, assetViewId } from '../api/config';
import { PortalInteractionSubscriber, PortalContextSubscriber } from '@hcp-portal/hcp-portal-messaging-system';

const messagingInteraction = new PortalInteractionSubscriber('Emission-content', undefined);
messagingInteraction.connect();

export const messagingContext = new PortalContextSubscriber('Emission-content', undefined);
messagingContext.connect();


const contextResponse = {
    correlationId: "1676838799240",
    subject: {
        alias: [
            {
                authority: "PIAssets",
                id: "Enterprise1"
            },
            {
                authority: "PIAssets",
                id: "Enterprise1"
            }
        ],
        displayName: "Region 1",
        id: "a09b40ce-f50a-4de5-ad9b-645fd06a875d",
        view: {
            displayName: "Asset Hierarchy",
            id: "045d7cb6-bbdd-4ec8-ac35-73218719ad70"
        }
    },
    time: {
        resolved: {
            start: "2023-05-13T18:30:00.000Z",
            end: "2023-05-18T08:40:06.000Z",
            id: "Start of the week to now",
            alias: [
                {
                    "id": "Start of the week to now",
                    "authority": "CoreTimeService"
                }
            ]
        },
        config: {
            start: {
                anchor: "week"
            },
            end: {
                anchor: "now"
            }
        }
    }
}



export const getPortalContext = () => {

    // return contextResponse;
}

export const getPortalCurrentContext = async () => {
    return await messagingContext.current();
}

export const portalNavigateToContent = async (message: any) => {
    return await messagingInteraction.navigateToContent(message);
}

export const portalAssetNavigation = (assetId: any) => {
    const messageInfo: any = {
        correlationId: "",
        asset: {
            assetId: assetId,
            assetViewId: assetViewId,
            contentId: contentId,
        }
    }
    messagingContext.changed(messageInfo);

}