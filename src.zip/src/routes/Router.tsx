import React from 'react';

import ReactDOM from 'react-dom/client';
import { createBrowserRouter, createRoutesFromElements, Route } from "react-router-dom";

import EnterPrise, { EnterPriseLoader } from '../pages/Enterprise/Enterprise';
import Region from '../pages/Region/Region';
import Site from '../pages/Site/Site';
import Layout from '../pages/Layout/Layout';
import Landing from '../pages/Landing/Landing';
import NoPage from '../pages/Landing/Landing';
import { SiteDetails } from '../pages/SiteDetail/SiteDetails';
import { Trends } from '../pages/SiteDetail/pages/trends/Trends';
import { Source } from '../pages/SiteDetail/pages/Source';
import { MapView } from '../pages/SiteDetail/pages/MapView/MapView';
import { SourceDetail } from '../pages/SourceDetail/SourceDetail';
import EflsConfiguration from '../srcEFLS/src/components/Configuration/Configuration';
import ErrorBoundary from '../components/ErrorBoundry/ErrorBoundary';

export const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path="/" element={<Layout />} errorElement={<ErrorBoundary />} >
      <Route index element={<Landing />} />
      <Route path="Enterprise" element={<EnterPrise />} />
      <Route path="Region" element={<Region />} />
      <Route path="Site" element={<Site />} />
      <Route path="sitedetail" element={<SiteDetails />} >
        <Route path="source" element={<Source />} />
        <Route path="mapview" element={<MapView />} />
        <Route path="trends" element={<Trends />} />
      </Route>
      <Route path="source_detail" element={<SourceDetail />} />
      <Route path="efls" element={<EflsConfiguration />} />
      <Route path="*" element={<NoPage />} />
    </Route>
  )
);