// Honeywell confidential. For internal use only.
// Property of and copyright ownership by Honeywell International Inc. and/or its affiliates.
// Use of source code must follow all Honeywell policies including the
// HCE Source Code Access Policy [http://go.honeywell.com/hce-code-access-policy].
// External use or distribution prohibited without written approval per Honeywell policies.

import { isArray, isNumber } from "highcharts";

export const defaultTimeRange = () => {
    let date = new Date();
    let startDate = new Date(date.getFullYear(), date.getMonth(), 1);
    let time = {
        resolved: {
            start: startDate,
            end: new Date(),
            id: "Start of the month to now"
        }
    }
    return time;
}

export const deepCloneEmission = (data: any) => {
    return JSON.parse(JSON.stringify(data));
}

export const groupDataByKey = (nodes: Array<any>, key: string) => {
    return nodes.reduce((group: any, arr: any) => {
        group[arr[key]] = group[arr[key]] ?? [];
        group[arr[key]].push(arr);
        return group;
    }, {});
}

export const getLocaleDate = (value: any, options: any) => {
    const date = new Date(value);
    return date.toLocaleDateString(navigator.language, options);
}

export const getLocaleTime = (value: any, options: any) => {
    const date = new Date(value);
    return date.toLocaleTimeString(navigator.language, options);
}

export const getLocaleMonth = (value: any, options: any) => {
    const date = new Date(value);
    return date.toLocaleString(navigator.language, options);
}

export const getLocaleNumber = (value: any) => {
    if (isNaN(value)) return value;
    return value?.toLocaleString(navigator.language);
}

export const getLocalePercentNumber = (value: any) => {
    const numberValue = Number(value.replace(/%/, ''));
    if (isNaN(numberValue)) {
        return value;
    }
    const formattedValue = (numberValue / 100).toLocaleString(navigator.language, { style: 'percent', minimumFractionDigits: 2 });
    return formattedValue;
};

export const precisionDecimal = (data: any) => isNaN(data) ? 0 : Number(data).toFixed(3);

export const findMixAndMax = (data: any, key: string) => {
    try {
        if (data.length === 1) {
            return {
                highest: data[0][key],
                lowest: 0
            }
        }
        let lowest = Number.POSITIVE_INFINITY;
        let highest = Number.NEGATIVE_INFINITY;
        let tmp;
        for (let i = data.length - 1; i >= 0; i--) {
            tmp = data[i][key];
            if (tmp < lowest) lowest = tmp;
            if (tmp > highest) highest = tmp;
        }
        if (!isFinite(highest) || !isFinite(lowest)) {
            return { highest: 0, lowest: 0 }
        }
        return { highest, lowest }
    } catch (error) {
        return false
    }
};

export const emissionNavigator = (navigator: any, page: string, redirectData: any, forWardSlash: string = '') => {
    return navigator(forWardSlash + page, {
        replace: false,
        state: { page: page, params: redirectData },
    });
};

export const goBack = (navigator: any) => navigator(-1);

export function nFormatter(num: any) {
    if (isNaN(num)) return num;

    if (num >= 1000000000) { return (num / 1000000000).toFixed(2).replace(/\.0$/, '') + 'B'; }
    if (num >= 1000000) { return (num / 1000000).toFixed(2).replace(/\.0$/, '') + 'M'; }
    if (num >= 1000) { return (num / 1000).toFixed(2).replace(/\.0$/, '') + 'K'; }
    return num.toFixed(2).replace(/\.0$/, '');
}

export function addZeroes(num: any) {
    if (isNaN(num)) return num;
    return num.toLocaleString(navigator.language, { useGrouping: false, minimumFractionDigits: 2 })
}

export const getSumOfValues = (data: Array<any>, key: any) => {
    return data.reduce((a, b) => { return a + b[key]; }, 0);
}

export const getHighestValueEntry = (data: Array<any>, key: any) => {
    if(isArray(data) && data?.length > 0) {
        return data?.reduce((prev: any, current: any) => (prev.level > current.level) ? prev : current);
    }
    return [];
}

export const getLastRankDataFromData = (data: Array<any>) => {
    let activeRank:any;
    try {
        const timeWiseData = getHighestValueEntry(data, 'time');
        return timeWiseData?.rank;
    } catch (error) {
        activeRank =  1
    }
   
    return activeRank;
};

export const getActiveRankTime = (timeContext: any) => {
    const { end, id } = timeContext;
    const date = new Date(end);
    date.setHours(date.getHours() - 1);
    date.setMinutes(date.getMinutes()  + 1);
    return {
        end: end,
        id: id,
        start: date
    }
};


export const sourceTagInfo = (
    actualValue: any,
    imageUrl: any,
    kpi_category: any,
    rank: any,
    scope_displayname: any,
    siteName: any,
    source_displayname: any,
    source_tag: any,
    sourcegroup_displayname: any,
    sourcetag_displayname: any,
    subsource_displayname: any,
    uom: any,
    asset_name:any
  ) => {
      return {
      actualValue: actualValue,
      imageUrl: imageUrl,
      kpi_category: kpi_category,
      activeRank: rank,
      scope_displayname: scope_displayname,
      siteName: siteName,
      source_displayname: source_displayname,
      source_tag: source_tag,
      sourcegroup_displayname: sourcegroup_displayname,
      sourcetag_displayname: sourcetag_displayname,
      subsource_displayname: subsource_displayname,
      uom: uom,
      asset_name: asset_name
    };
  };