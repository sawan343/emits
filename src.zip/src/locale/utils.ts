import { addLocale, localeOptions } from 'primereact/api';

import en from './en.json';
import de from './de.json';

const localizationObject:any = {
    'en': en,
    'de': de
}

export const getLocaleOptions = (locale = 'en') => {
    if (localizationObject[locale]) {   
        addLocale(locale, localizationObject[locale])
        return localeOptions(locale)
    }
    addLocale('en', localizationObject['en'])
    return localeOptions('en')
}





