import { Wrapper } from "@googlemaps/react-wrapper";
import React, { useRef, useEffect, useState, Fragment } from "react";
import MarkerFactory from "./MarkerFactory";
import useAssetLatLongData from "../../hooks/useAssetLatLongData";
import { useLocation } from "react-router-dom";
import { MapLoader } from "../mapLoader/MapLoader";
import { useContext } from "react";
import { AppContext } from '../../store/AppContext';

const render = (status: any) => {
  switch (status) {
    case "LOADING":
      return  <MapLoader />;
    case "FAILURE" :
      return <p>{status.FAILURE} </p>;
    case "SUCCESS":
      return <p>{status.SUCCESS} </p>;
  }
  return <p> {status.LOADING} </p>
};

const host = window.location.hostname;
const googleMapKey =  host === 'localhost' ? 'AIzaSyBAj5TNlQv8mxpOfoFDqZ5hmb-PsoBUS18' : 'AIzaSyCcdODyCWIHMWNCXI9aHOZ5tCgJqZH_im4';
let maxZoomLevel = 20;
const enterprisePageDefaultZoomLevel = 4;
const sitePageDefaultZoomLevel = 16;
const mapOptions:any = {
  mapId: googleMapKey,
  center: { lat: 40.6970174, lng: -74.3100061 },
  zoom: 4,
  disableDefaultUI: true,
  mapTypeId:  "satellite",
  zoomControl: true,
};

function MapComponent(props:any) {
  let maxZoomService:any;
  let newMap:any;
  const { locale } = useContext(AppContext);
  const { markerData, maxZoom, showTooltip } = props;
  const [map, setMap] = useState() as any;
  const [zoomLevel,setZoomLevel] = useState(maxZoom?sitePageDefaultZoomLevel:enterprisePageDefaultZoomLevel);
  const ref:any = useRef();

  useEffect(() => {
    if(markerData?.length > 0) {
      const lastMarker = markerData?.[markerData?.length - 1 ];
      mapOptions.center = lastMarker.position;
      newMap = new window.google.maps.Map(ref.current, mapOptions);
      maxZoomService = new google.maps.MaxZoomService();
    } else {
      newMap = new window.google.maps.Map(ref.current, mapOptions);
    }
    setMap(newMap);
  }, []);

  useEffect(() =>{
    if(maxZoomService && maxZoom) {
      showMaxZoom(mapOptions.center)
    }
  },[map]);

  useEffect(()=>{
    map?.setZoom(zoomLevel);
  },[zoomLevel])

  function showMaxZoom(e:any) {
    maxZoomService.getMaxZoomAtLatLng(e, (result:any) => {
      console.log(e);
      maxZoomLevel = result?.zoom || maxZoomLevel;
      newMap.setZoom(sitePageDefaultZoomLevel);
    });
  };
  const setZoomLevelFunction = (zoomFun:any) =>{
      if(zoomFun === '+' && map?.getZoom() !== maxZoomLevel)
        {
          setZoomLevel(map?.getZoom() + 1);          
        }
      else if(zoomFun === '-' && map?.getZoom() !==0)
        {
          setZoomLevel(map?.getZoom() - 1);
        }
      else if(zoomFun === 'Reset')
        {
          if(maxZoom) {
            setZoomLevel(sitePageDefaultZoomLevel);
          }
          else{
            setZoomLevel(enterprisePageDefaultZoomLevel);
          }
          
        }
  }
  return (
    <div className="map-container">
      <div ref={ref} id="map">
      </div>
       {map && markerData?.length > 0 && <MarkerFactory map={map} markerData = {markerData} markerInstance = {google.maps.marker.AdvancedMarkerElement} showTooltip={showTooltip} />}
       <div className="zoom-btn-bar flex justify-content-center align-items-center text-sm">
        <div className="action-btn zoom-btn" onClick={() => { setZoomLevelFunction('-');  }} >-</div>
        <div className="action-btn zoom-btn" onClick={() => {setZoomLevelFunction('+');}} >+</div>
        <div className="zoom-value text-center">{Math.round((zoomLevel/maxZoomLevel)*100)+'%'}</div>
        <div className="action-btn reset-btn" onClick={() => {setZoomLevelFunction('Reset');}} >{locale['Reset']}</div>
        </div>  
      <div className="map-legend-container flex">
        <div className="map-legends flex">
            <div className="map-legend bad-emission">
              <div className="color _background_color_mainRed"></div>
              <div className="text _color_shadeWhite"> {locale['critical']} </div>
            </div>
            <div className="map-legend good-emission">
              <div className="color _background_color_lightGreen"></div>
              <div className="text _color_shadeWhite"> {locale['noIssues']} </div>
            </div>
            <div className="map-legend no-data">
              <div className="color _background_color_greyWhite"></div>
              <div className="text _color_shadeWhite"> {locale['targetNotSet']} </div>
            </div>
        </div>
      </div>
    </div>
  );
}

export default function AerialMap(props:any) {
  const {data, maxZoom, showTooltip} = props;
  return (
    <Wrapper
      apiKey={googleMapKey}
      version="beta"
      libraries={['marker']}
      render = {render}
    >
      <MapComponent markerData = {data} maxZoom = {maxZoom} showTooltip = {showTooltip}/>
    </Wrapper>
  );
}

