import { createRoot } from 'react-dom/client';
import { AppContext } from '../../store/AppContext';
import React, { useRef, useEffect, useState, Fragment, memo, useContext } from "react";
import GreenMarker from "../../assets/images/greenMarker.png";
import RedMarker from "../../assets/images/redMarker.png";
import GreyMarker from "../../assets/images/greyMarker.png";
import { Tooltip } from 'primereact/tooltip';
import { getLocaleNumber, precisionDecimal } from '../../utils/utils';


const Marker = memo((props: any) => {
  const { map, children, position, i } = props;
  const markerRef: any = useRef();
  const rootRef: any = useRef();
  const clickMarker = (e: any) => {
    console.log(e)
  }
  useEffect(() => {
    if (!rootRef.current) {
      const container = document.createElement('div');
      rootRef.current = createRoot(container);
      const collide = google.maps.CollisionBehavior.OPTIONAL_AND_HIDES_LOWER_PRIORITY;
      markerRef.current = new google.maps.marker.AdvancedMarkerElement({
        position,
        content: container,
        collisionBehavior: collide
      });
      markerRef.current.addListener("click", clickMarker, false);

    }
  }, []);

  useEffect(() => {
    rootRef.current.render(children);
    markerRef.current.position = position;
    markerRef.current.map = map;
  }, [map, children, position]);

  return <></>;
});

const MapToolTip = (props: any) => {
  const { locale } = useContext(AppContext);
  const { regionName, tooltip, pageName, label, criticalSiteslabel, tags } = props.singleMarkerData;
  return (
    <div className='map-tool-tip'>
      <div className="box">
        <header className="tooltip-header">
          {label}
          {
            tags &&
            <div className='map-tooltip-tags'>
              {tags.length > 0 && tags.map((item: string, i: number) => <p key={i} className='tags'> <span>{item}</span></p>)}
            </div>
          }
        </header>
        <section>
          <h3>{criticalSiteslabel} </h3>
          {tooltip && tooltip?.sort((a: any, b: any) => b.actualValue - a.actualValue)?.map((item: any, index: number) => {
            return (
              <main>
                <p className="label-name">{item?.asset_name}</p>
                <section className='data-section flex'>
                  <div className='quantity'>{getLocaleNumber(precisionDecimal(item?.actualValue))}</div>
                  <div className='quantity-label'> {item?.kpi_type} <span>({item?.uom})</span> </div>
                </section>
              </main>
            )
          })}
        </section>

      </div>
    </div>
  )
}

const getMarkerImage = (status: string) => {
  let image = GreyMarker;
  if (status?.toLowerCase() === "good") image = GreenMarker;
  if (status?.toLowerCase() === "bad") image = RedMarker;
  return image;
};

const MapSingleMarker = (marker: any) => {
  const tooltipRef: any = useRef();

  const [showTooltip, setShowTooltip] = useState(false);

  const showToolTipHandle = (e: any) => tooltipRef.current.show(e);
  const hideToolTip = (e: any) => tooltipRef.current.hide(e);
  const onClickHandler = (e: any) => {
    tooltipRef.current.hide(e);
    marker.clickHandler();
  }

  if (marker?.showTooltip) {
    return (
      <div className={'map-marker ' + 'marker_tooltip' + marker?.i} onClick={onClickHandler} onMouseEnter={showToolTipHandle} onMouseLeave={hideToolTip}>
        <img src={getMarkerImage(marker?.status)} alt="emission marker" />
        <span className='marker-label'>{marker?.label}</span>
        <Tooltip className="map-prime-tooltip" target={'.marker_tooltip' + marker?.i} ref={tooltipRef}>
          <MapToolTip singleMarkerData={marker} />
        </Tooltip>
      </div>
    )
  } else {
    return (
      <div className={'map-marker ' + 'marker_tooltip' + marker?.i} >
        <img src={getMarkerImage(marker?.status)} alt="emission marker" />
        <span className='marker-label marker-label__dark'>{marker?.label}</span>
      </div>
    )
  }

}

export default memo(function MarkerFactory(props: any) {
  const { map, markerData, showTooltip } = props;
  const [data, setData] = useState(markerData);


  return (
    <Fragment>
      {
        // [data[0]] need to be replace with "data" 
        data.map((marker: any, index: number) => {
          return (
            <Marker key={index} map={map} position={marker.position} i={index} >
              <MapSingleMarker  {...marker} i={index} showTooltip={showTooltip} />
            </Marker>
          )
        })
      }
    </Fragment>
  );
})
