import React, { useState, useContext } from "react";
import { AppContext } from "../../store/AppContext";
import { Dropdown } from "primereact/dropdown";
import { Image_Mapping, TileViewImageMapping } from "../../utils/constants";
import { getLocaleNumber, precisionDecimal } from "../../utils/utils";
import { Tooltip } from 'primereact/tooltip';

const calculateDataAccordingToRank = (data:any, activeRank:any) => {
  let sum = 0
  if(data[activeRank]?.length > 0 && activeRank) {
    sum =  data[activeRank].reduce((a: any, b: any) => {
      return a + b.actualValue
    }, 0)
  }else {
    if(data[0]?.length > 0) {
      sum =  data[0].reduce((a: any, b: any) => {
        return a + b.actualValue
      }, 0)
    }
  }
  return sum;
}
const createDropDown = (items:any) => {
  return items.map((item:any) => {
    return ({
      name: item,
      code: item
    });
  })
}
export function InfoCard(props: any) {
  const { locale } = useContext(AppContext);
  const { activeRank } = props;
  const {
    sourcetag_displayname,
    source_displayname,
    scope_displayname,
    uom,
    kpi_type   
  } = props.sourceTagMetaData;
  const { totalSourceTag, allRanksKeys, groupByRank } = props.scopeContributionData;
  let imageUrl = TileViewImageMapping.Combustion;
  if (TileViewImageMapping.hasOwnProperty(source_displayname)) {
    imageUrl = TileViewImageMapping[source_displayname];
  }
  return (
    <div className="info-card-container">
      <div className="info-bar">
        <div className="left">
        <div className="rank-drop-down">
             <h3>{locale['rank']}: {activeRank}</h3>
          </div>
          <h3 className="source-tag-tooltip">{sourcetag_displayname} 
              <Tooltip className="tooltip" target={'.source-tag-tooltip'} >
                   {sourcetag_displayname}
              </Tooltip>
          </h3>

          <div className="sub-header souce-horizontal">
          <span>{scope_displayname}</span> | <span>{source_displayname}</span>{" "}
            | <span>{sourcetag_displayname}</span>
              <Tooltip target={'.souce-horizontal'} >
              <span>{scope_displayname}</span> | <span>{source_displayname}</span>{" "}
            | <span>{sourcetag_displayname}</span>
              </Tooltip>
          </div>
          <div className="quantity">
            <div className="exact-value">{getLocaleNumber(precisionDecimal(calculateDataAccordingToRank(groupByRank, activeRank)))}</div>
            <div className="unit">{uom}</div>
          </div>
          <div className="source-tag-title">{kpi_type}</div>
          <p className="general-text gas-name">{locale['actualGhgEmissions']}</p>
        </div>
        <div className="right">
          <div className="tile-icon">
            <div className="tile-circle">
              {imageUrl && <img
                src={`data:image/svg+xml;base64,${btoa(
                  imageUrl
                )}`}
                alt="image source tag"
              />}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
