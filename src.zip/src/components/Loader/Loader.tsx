import React from "react";

export const Loader = () => {
  return (
    <div className="emission-loader">
      <svg
        className="spinner"
        width="64"
        height="64"
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <rect width="64" height="64" fill="white" />
        <path
          fill-rule="evenodd"
          clip-rule="evenodd"
          d="M0.307047 36.4508C0.104633 34.9962 0 33.5103 0 32C0 14.3269 14.3269 0 32 0C49.6731 0 64 14.3269 64 32C64 49.6731 49.6731 64 32 64C28.6407 64 25.4024 63.4824 22.3603 62.5225L24.1738 57.4411C26.6482 58.2013 29.2763 58.6105 32 58.6105C46.6966 58.6105 58.6105 46.6966 58.6105 32C58.6105 17.3034 46.6966 5.38947 32 5.38947C17.3034 5.38947 5.38947 17.3034 5.38947 32C5.38947 33.288 5.48099 34.5547 5.65786 35.7938L0.307047 36.4508Z"
          fill="#F5F5F5"
        />
        <mask
          id="mask0_5937_431852"
          style={{ maskType: "luminance" }}
          maskUnits="userSpaceOnUse"
          x="0"
          y="0"
          width="64"
          height="64"
        >
          <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M0.307047 36.4508C0.104633 34.9962 0 33.5103 0 32C0 14.3269 14.3269 0 32 0C49.6731 0 64 14.3269 64 32C64 49.6731 49.6731 64 32 64C28.6407 64 25.4024 63.4824 22.3603 62.5225L24.1738 57.4411C26.6482 58.2013 29.2763 58.6105 32 58.6105C46.6966 58.6105 58.6105 46.6966 58.6105 32C58.6105 17.3034 46.6966 5.38947 32 5.38947C17.3034 5.38947 5.38947 17.3034 5.38947 32C5.38947 33.288 5.48099 34.5547 5.65786 35.7938L0.307047 36.4508Z"
            fill="white"
          />
        </mask>
        <g mask="url(#mask0_5937_431852)">
          <rect x="-8" y="-9" width="81" height="81" fill="#A0A0A0" />
        </g>
        <path
          fill-rule="evenodd"
          clip-rule="evenodd"
          d="M22.3603 62.5227L24.1738 57.4412C14.4668 54.4587 7.1251 46.0732 5.65782 35.7939L0.307007 36.4509C2.02293 48.782 10.7658 58.8643 22.3603 62.5227Z"
          fill="#F5F5F5"
        />
        <mask
          id="mask1_5937_431852"
          style={{ maskType: "luminance" }}
          maskUnits="userSpaceOnUse"
          x="0"
          y="35"
          width="25"
          height="28"
        >
          <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M22.3603 62.5227L24.1738 57.4412C14.4668 54.4587 7.1251 46.0732 5.65782 35.7939L0.307007 36.4509C2.02293 48.782 10.7658 58.8643 22.3603 62.5227Z"
            fill="white"
          />
        </mask>
        <g mask="url(#mask1_5937_431852)">
          <rect x="-8" y="-6" width="80" height="80" fill="white" />
        </g>
      </svg>
    </div>
  );
};
