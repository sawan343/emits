import React, { useReducer, useContext, memo, useEffect } from 'react';
import { AppContext } from '../../store/AppContext';
import { ProgressSpinner } from 'primereact/progressspinner';
import { useLocation } from 'react-router-dom';
import { Dropdown } from 'primereact/dropdown';
import useKPISelectorData from '../../hooks/useKPISelectorData';
import { KPI_TYPES_NAME_MAPPING } from '../../utils/constants';


export const KpiSelector = memo((props:any) => {
  const { page, params, kpiSelectorCallback } = props;
  const { timeContext } = useContext(AppContext);

  useEffect(() =>{
    if(typeof kpiSelectorCallback === "function") {
      kpiSelectorCallback("CO2e")
    }
  },[timeContext?.start, timeContext?.end])

  const location = useLocation();
  const { options, loading, error } = useKPISelectorData(page, params);
  const [state, setState] = useReducer((oldState: any, newState: any) => (
    { ...oldState, ...newState }), {
    selectedKpi: 'CO2e'
  })

  // useMemo(() => {
  //   if (!loading) {
      
  //     return setState({ options });
  //   }
  // }, [loading])


  const setSelectedValue = (e: any) => {
    const value = e.value;
    setState({ selectedKpi: value });
    if(typeof kpiSelectorCallback === "function") {
      kpiSelectorCallback(value)
    }
  }

  return (
    <React.Fragment>
      <Dropdown
        value={state.selectedKpi}
        onChange={(e) => setSelectedValue(e)}
        options={options}
        optionLabel="name"
        placeholder="Select a kpi"
        className="w-full" />
    </React.Fragment>
  );
});



