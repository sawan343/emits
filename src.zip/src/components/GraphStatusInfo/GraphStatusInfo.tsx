import React,  { useContext } from "react";
import { AppContext } from "../../store/AppContext";
export const GraphStatusInfo = () => {
    const { locale } = useContext(AppContext);

    return (<div className="graph-status-container">
    <div className="graph-status-item">
      <span className="shape color-lowest"></span>
      <span className="text"> Lowest</span>
    </div>
    <div className="graph-status-item">
      <span className="shape color-highest"></span>
      <span className="text"> Highest</span>
    </div>
    <div className="graph-status-item">
      <span className="shape color-current"></span>
      <span className="text"> Current</span>
    </div>
  </div>)
}