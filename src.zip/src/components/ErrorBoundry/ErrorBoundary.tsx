import React, { useContext } from "react";
import { useRouteError } from "react-router-dom";
import { AppContext } from "../../store/AppContext";

function ErrorBoundary() {
    let error = useRouteError();
    const { locale } = useContext(AppContext);
    console.error(error);
    // Uncaught ReferenceError: path is not defined
    return <div className="error-boundry">{locale["somethingwentwrong"]}</div>;
  }

export default ErrorBoundary;