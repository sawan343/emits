import React, {memo} from "react";
export const BackgroudImage = memo(() => {
    return <div className = "max-h-full full-bg-image" ></div>
});