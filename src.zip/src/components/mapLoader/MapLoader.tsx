import React from 'react';

export const MapLoader = () => {
  return (
    <div className="map-loader">
        <div className="pin"></div>
        <div className="pulse"></div>
    </div>
  );
};
