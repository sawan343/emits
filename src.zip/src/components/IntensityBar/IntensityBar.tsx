import * as React from "react";
import { useContext } from "react";
import { AppContext } from "../../store/AppContext";
import { getLocalePercentNumber, getLocaleNumber, precisionDecimal } from "../../utils/utils";

const Vectoricon = <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M7 4.6V7M7 9.4H6.994M1 7C1 3.68629 3.68629 1 7 1C10.3137 1 13 3.68629 13 7C13 10.3137 10.3137 13 7 13C3.68629 13 1 10.3137 1 7Z" stroke="#303030" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
function nFormatter(num:number) {
    if (num >= 1000000000) {
       return (num / 1000000000).toFixed(2).replace(/\.0$/, '') + 'G';
    }
    if (num >= 1000000) {
       return (num / 1000000).toFixed(2).replace(/\.0$/, '') + 'M';
    }
    if (num >= 1000) {
       return (num / 1000).toFixed(2).replace(/\.0$/, '') + 'K';
    }
    return num;
}

const removeChemicalNames = (str:any) => {
  let newColumnName = str;
  try{
    if(str?.includes("(CO2e)")) {
      newColumnName = str?.replace("(CO2e)", "");
    }
  
    if(str?.includes("(CH4)")) {
      newColumnName = str?.replace("(CH4)", "");
    }
  
    if(str?.includes("(CO2)")) {
      newColumnName = str?.replace("(CO2)", "");
    }
  
    if(str?.includes("(N2O)")) {
      newColumnName = str?.replace("(N2O)", "");
    }
  
    if(str?.includes("(R-134a)")) {
      newColumnName = str?.replace("(R-134a)", "");
    }
  } catch(e) {
    newColumnName = str;
  }
  return newColumnName;
}

export const IntensityBar = (props: any) => {
  const { locale } = useContext(AppContext);
  const {
    gasData,
    unit,
    sourceTag
  } = props;

  if(gasData.length < 1) {
    <p>{locale["errorMessage"]}</p>
  }
  return (
    <div className="range-container">
      <div className="header">
        <h4 className="heading-boiler">
        {locale["contributionOf"]} {sourceTag}
        </h4>
        <span> ({unit}) </span>
        <div className="icon-tooltip">
          {Vectoricon}
          <span className="tooltipName info-tooltip-text">
          {locale["note"]}
          </span>
        </div>
      </div>
      

      <div className="gas-contributor-container">
        {
            gasData && gasData.map((item:any, index:number, array:any) => {
                const filledCSS = { width: `${item.percentage}%`, borderColor: `${item.color}` }
                return (
                  
                        <div className="gas-contributor" key={`gas-contributor${index}`}>
                            <p className="upper-percent scopeName_contribution ellipses"> { getLocalePercentNumber(`${Math.round(item.percentage)}%`) || 0} </p>
                            <hr className="empty" />
                            {item.percentage > 0  && <hr className="filled" style= {{ ...filledCSS }} /> }
                            { (array.length ) > index && index > 0 && <div className="vertical"></div> }
                            <div className="bottom-container">
                            <p className="bottom-text ellipses"> {removeChemicalNames(item.columnName)} <span className="tooltipName">{removeChemicalNames(item.columnName)}</span></p>
                            <p className="bottom-unit bottom-item ellipses"> {`${unit}`}</p>
                            <p className="bottom-value bottom-item ellipses"> {getLocaleNumber(precisionDecimal(item.value))}  <span className="tooltipName">{item.value}</span></p>

                            </div>
                        </div>
                       
                    
                );
            })
        }
      
        
      </div>
    </div>
  );
};
