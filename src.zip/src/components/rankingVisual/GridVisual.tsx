import React, { useMemo } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ChartVisual } from "./ChartVisual";
import { Button } from 'primereact/button';
import { emissionNavigator, getLocaleNumber, getSumOfValues, precisionDecimal } from "../../utils/utils";
import { TileViewImageMapping } from '../../utils/constants';


interface IProps {
    rankingVisualData: any,
    latestRanks: any,
    params: any,
    navigate: any,
    EFLSData: any
}

export const GridVisual = (props: IProps) => {
    const { rankingVisualData, latestRanks, params, navigate, EFLSData } = props;

    const getAssetList = () => {
        const nodes = Object.keys(rankingVisualData)?.map((node: any, index: number) => {
            const latestTimeData = rankingVisualData[node]?.reduce((prev: any, current: any) => (prev.time > current.time) ? prev : current);
            return { id: index, ...latestTimeData }
        });
        console.log('assetList------>', nodes);
        return nodes;
    };

    //hierarchy will be: scope_display_name | source_display_name | source_tag_display_name
    const hierarchyInfo = (node: any) => {
        return `${node.scope_displayname} | ${node.source_displayname} | ${node.sourcegroup_displayname}`
    }

    const chartVisual = (node: any) => {
        const asset = rankingVisualData[node.asset_name];
        return <div className="flex">
            <ChartVisual source={asset} />
            {/* {node.actualValue} */}
        </div>
    }

    const ghgEmissionValue = (node: any) => {
        const asset = rankingVisualData[node.asset_name];
        return getLocaleNumber(precisionDecimal(getSumOfValues(asset, 'actualValue')));
    }

    const gotoSourceDetails = (selectedData: any, event: any) => {
        emissionNavigator(navigate, 'source_detail', { ...params, ...selectedData, isNavigatedFromRanking: true }, '/')
    }

    const navigateToSourceDetail = (node: any, columnInfo: any) => {
        const imageUrl = TileViewImageMapping[node?.source_displayname];
        return <Button label={node?.[columnInfo?.field]} link onClick={(event: any) => gotoSourceDetails({ imageUrl, ...node }, event)} />
    }

    const latestRank = (node: any) => {
        return <div className='active-rank'> {latestRanks?.[node?.asset_name] ? `Rank ${latestRanks?.[node?.asset_name]}` : 'NA'}</div>
    }

    const getEFLSData = (node: any, columnInfo: any) => {
        return EFLSData?.[node?.asset_name][columnInfo?.field]
    }

    const columns = [
        { header: 'EMISSION SOURCE TAG', field: 'sourcetag_displayname', body: navigateToSourceDetail },
        { header: 'EMISSION HIERARCHY', body: hierarchyInfo },
        { header: 'RANK', body: latestRank },
        { header: 'GHG EMISSIONS (CO2e)', body: ghgEmissionValue },
        { header: 'UOM', field: 'uom' },
        { header: 'GHG EMISSIONS (CO2e) TREND', body: chartVisual },
        { header: 'EMISSION FACTOR STANDARD', field: 'emissonfactorstandard', body: getEFLSData },
        { header: 'VERSION', field: 'emissionfactorversion', body: getEFLSData }
    ];

    return (
        <DataTable value={getAssetList()} scrollable scrollHeight="48rem" tableStyle={{ minWidth: '50rem' }}>
            {columns.map((col: any, i: number) => (
                console.log("col", col),
                <Column key={col.field} field={col.field} header={col.header} sortable={(col.header === "EMISSION SOURCE TAG" || col.header === "EMISSION FACTOR STANDARD" || col.header === "RANK" || col.header === "GHG EMISSIONS (CO2e)") ? true : false} body={col.body} style={{ width: '12.5%' }} />
            ))}
        </DataTable>
    )

}