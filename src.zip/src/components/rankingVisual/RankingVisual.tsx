import * as React from "react";
import { useState, useContext } from "react";
import { DataView } from "primereact/dataview";
import { ChartVisual } from "./ChartVisual";
import { Card } from "primereact/card";
import { Tooltip } from "primereact/tooltip";
import { Tag } from "primereact/tag";
import useRankingVisualData from "../../hooks/useRankingVisualData";
import { useLocation, useNavigate } from "react-router-dom";
import {TileViewImageMapping} from '../../utils/constants';
import {addZeroes,getLocaleNumber, emissionNavigator, getSumOfValues, getHighestValueEntry, precisionDecimal} from '../../utils/utils';
import {
  Paginator,
  PaginatorPageChangeEvent,
  PaginatorCurrentPageReportOptions,
} from "primereact/paginator";
import { AppContext } from "../../store/AppContext";
import { GridVisual } from "./GridVisual";
import { GraphStatusInfo } from "../GraphStatusInfo/GraphStatusInfo";
interface ICardProps {
  data: Array<any>;
  values: Array<any>;
  selectionProperties: any;
}

export const RankingVisual = (props: any) => {
  const { selectSourceTag, siteName } = props;
  const { locale, portalContext, siteDetailFilter } = useContext(AppContext);
  const location = useLocation();
  const navigate = useNavigate();

  const { RankingVisualData, latestRanks, loading, EFLSData,  error } = useRankingVisualData(
    location?.state?.pageName?.toLowerCase() ||
    location?.pathname?.replace('/', '').toLocaleLowerCase(), siteName, siteDetailFilter
  );

  console.log('RankingVisualData ---------->', RankingVisualData);

  let AssetList: any = Object.keys(RankingVisualData);
  AssetList = AssetList.map((item: any, i: number) => { return { id: i, item: item } })
  const [first, setFirst] = useState<number>(0);
  const [rows, setRows] = useState<number>(12);
  const [currentPage, setCurrentPage] = useState<any>(1);

  let page = location?.state?.page || location?.pathname?.replace('/', '').toLocaleLowerCase();
  let params = location?.state?.params || { siteName: portalContext.site };

  function gotoSourceDetails(selectedData: any, event: any) {
    console.log(event);
    console.log(selectedData);
    emissionNavigator(navigate, 'source_detail', { ...params, ...selectedData, isNavigatedFromMap:false, isNavigatedFromRanking: true, rank: latestRanks?.[selectedData?.asset_name] }, '/')
  }


  //when text is overflowing out of the card ellipsis have been added
  const addEllipsis = (name: any, n: any) => {
    name = (name?.length > n) ? (name.substring(0, n - 3) + '...') : name
    return name
  }

  //hierarchy will be: scope_display_name | source_display_name | source_tag_display_name
  const getHierarchyInfo = (product: any) => {
    return `${product.scope_displayname} | ${product.source_displayname} | ${product.sourcegroup_displayname}`
  }

  //rendering of every card
  const gridItem = (assetName: any) => {
    let asset: any = RankingVisualData[assetName];

    if (asset) {
      let imageUrl = TileViewImageMapping.Combustion;
      if (TileViewImageMapping.hasOwnProperty(asset[0].source_displayname)) {
        imageUrl = TileViewImageMapping[asset[0].source_displayname];
      }
      const hierarchyText = getHierarchyInfo(asset[0]);
      return (
        <div className="col-12 sm:col-12 md:col-6 lg:col-3 xl:col-3 p-1" >
          <Card
            className="cardComponent"
            onClick={gotoSourceDetails.bind(null, { imageUrl, ...asset[0] })}
          >
            <div className="AssetDetails">
              <div className="image">
                <div className="p-avatar p-component p-avatar-md AvatarImg" style={{ width: "100%", height: "100%" }}>
                  <img
                    src={`data:image/svg+xml;base64,${btoa(
                      imageUrl
                    )}`}
                    alt=""
                  />
                </div>
              </div>
              <div className="Assets">
                <div>
                  <Tag
                    className='RankTag'
                  >
                    {latestRanks?.[assetName] ? `Rank ${latestRanks?.[assetName]}` : 'NA'}
                  </Tag>
                </div>
                <div className="Asset_Name" >
                  <Tooltip target={`.title-text-${asset[0].index}`} className='ranking-card-tooltip' />
                  <span className={`title-text-${asset[0].index}`} data-pr-tooltip={asset[0].sourcetag_displayname} data-pr-position="top">
                    {addEllipsis(asset[0].sourcetag_displayname, 22)}
                  </span>
                </div>
                <div className="value_details">
                  <Tooltip target={`.title-text-hierarchy-${asset.index}`} className='ranking-card-tooltip' />
                  <span className={`title-text-hierarchy-${asset.index}`} data-pr-tooltip={hierarchyText} data-pr-position="top">
                    {addEllipsis(hierarchyText, 35)}
                  </span>
                </div>
              </div>
            </div>

            <div className="LineChart">
              <ChartVisual
                source={asset}
              />
            </div>
            <div className="footer">
              <div className="name">{locale['ghgEmissionco2e']}</div>
              <Tooltip target={`.emissionValue-${asset[asset.length-1].index}`} className='ranking-card-tooltip' />
              <div className={`unit emissionValue-${asset[asset.length-1].index}`} data-pr-tooltip={addZeroes((getHighestValueEntry(asset, 'time'))?.actualValue)}>
                <b className="">{getLocaleNumber(precisionDecimal(getSumOfValues(asset, 'actualValue')))}</b> {asset[0].uom}
              </div>
            </div>
          </Card>
        </div>

      );
    }
  };

  const itemTemplate = (cardDetails: any, layout: string) => {
    if (!cardDetails) {
      return;
    } else if (layout === "grid") {
      return gridItem(cardDetails.item);
    }
  };

  const onPageChange = (options: PaginatorCurrentPageReportOptions) => {
    setFirst(options.first);
    setRows(options.rows);
    console.log("page", first, rows);
    //return options;
  };

  const pageReportsAndFiltersApplied = {
    layout: "CurrentPageReport",
    CurrentPageReport: (options: PaginatorCurrentPageReportOptions) => {
      console.log("option", options);
      return (
        <span
          style={{
            color: "var(--text-color)",
            userSelect: "none",
            width: "270px"
          }}
        >
          {options.first} - {options.last} of {options.totalRecords} | {locale['noFiltersApplied']}
        </span>
      );
    },
  };

  return (
    <div className="card">
      <div className="ranking-header">
        {loading || (
          <>
            <Paginator
              template={pageReportsAndFiltersApplied}
              first={first}
              rows={rows}
              totalRecords={Object.keys(RankingVisualData).length}
              className="justify-content-start total-paging"
            />
          </>
        )}
      </div>

      {params?.layout === "grid" ? (
        <DataView
          dataKey="id"
          paginator={Object.keys(RankingVisualData).length > 12 ? true : false}
          rows={Object.keys(RankingVisualData).length > 12 ? 12 : 0}
          value={AssetList}
          itemTemplate={itemTemplate}
          layout={"grid"}
          first={first}
          onPage={(options: any) => onPageChange(options)}
          loading={loading || false}
        />
      ) : (
        <GridVisual
          rankingVisualData={RankingVisualData}
          latestRanks={latestRanks}
          params={params}
          navigate={navigate}
          EFLSData = {EFLSData}
        />
      )}
    </div>
  );
};
