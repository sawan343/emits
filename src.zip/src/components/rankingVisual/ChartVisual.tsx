
import * as React from "react";
import * as Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { CHART_COLORS } from '../../utils/constants';
import { getLocaleDate, getLocaleNumber, precisionDecimal } from '../../utils/utils';
interface IProps {
    source: string;
}



export const ChartVisual = (props: any) => {
    const { source } = props;
    const getXAxis = () => {
        let xAxis: any = [];
        source?.map((item: any) => {
            xAxis.push(item.time);
        });
        return xAxis;
    };

    const getSeries = () => {
        let series: any = [];
        source?.map((item: any) => {
            series.push(item?.actualValue);
        })
        const lastIndex = series?.length - 1;
        const y_last = series?.[lastIndex];
        const highestValue = Math.max(...series);
        const lowestValue = Math.min(...series);
        const highestIndex = series.indexOf(highestValue);
        const lowestIndex = series.indexOf(lowestValue);
        series[lastIndex] = { y: y_last, color: "#1792E5", tooltip_text: "Current", marker: { enabled: true, radius: 4 } };
        if (highestIndex !== lastIndex) {
            const y_highest = series[highestIndex];
            series[highestIndex] = { y: y_highest, tooltip_text: "Highest", color: "#EE3124", marker: { enabled: true, radius: 4 } }
        }
        if (highestIndex !== lowestIndex && lastIndex !== lowestIndex) {
            const y_lowest = series[lowestIndex];
            series[lowestIndex] = { y: y_lowest, color: "#279D2B", tooltip_text: "Lowest", marker: { enabled: true, radius: 4 } };
        }
        return series
    }

    const getDateFormat = (ISOdate: any) => {
        const options = {
            year: "numeric",
            month: "long",
            day: "numeric",
            hour: 'numeric',
            minute: 'numeric',
            hour12: false
        };
        const text = getLocaleDate(ISOdate, options);
        return text;
    }

    const options = {
        chart: {
            width: 280,
            height: 50,
            backgroundColor: 'transparent'
        },
        credits: {
            enabled: false
        },
        title: {
            text: '',
            align: 'left'
        },

        subtitle: {
            text: '',
            align: 'left'
        },

        xAxis: {
            visible: false,
            lineColor: 'transparent',
            categories: getXAxis()
        },

        yAxis: {
            visible: false,
            lineColor: 'transparent',
        },
        legend: {
            enabled: false
        },
        plotOptions: {
            series: {
                marker: { enabled: false },
            }
        },
        tooltip: {
            outside: true,
            enabled: true,
            useHTML: true,
            backgroundColor: '#FFFFFF',
            shadow: 'none',
            borderWidth: 0,
            style: {
                color: '#303030', borderRadius: '0.25rem', Width: '13.75rem', Height: '3.648rem', paddingTop: '0.5rem', paddingRight: '0.75rem', paddingLeft: '0.5rem'
            },
            formatter(): any {
                const unitText = source?.[0]?.uom;
                return `<div>
                    <div style='font-weight: 700; font-size: 0.75rem;'>${getDateFormat(new Date((this as any).x))}</div>
                    <div style='font-weight: 500; font-size: 1rem; margin-top:0.5rem'>
                    <span style='font-weight: 900;'><strong>${(this as any).point?.tooltip_text || 'Value'}: ${getLocaleNumber(precisionDecimal(+((this as any).y)))}</strong></span>${unitText}
                    </div>
                    </div>`
            },
        },
        series: [
            {
                name: '',
                data: getSeries(),
                color: CHART_COLORS?.[source?.[0]?.source_displayname],
                visible: true
            }
        ],

        responsive: {
            rules: [{
                condition: {
                    maxWidth: 300
                },
            }]
        }

    };
    return (<div className="chart">
        <HighchartsReact highcharts={Highcharts} options={options} />
    </div>)
};