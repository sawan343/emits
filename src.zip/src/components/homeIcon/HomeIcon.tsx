import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { emissionNavigator } from '../../utils/utils';
import { AppContext } from '../../store/AppContext';



export const HomeIcon = (props: any) => {
    const navigate = useNavigate();
    const { img } = props;
    const onClickHandler = () => {
        emissionNavigator(navigate, "/", { pageName: 'landing' });
    }
    return (
        <>
            <div className='home-icon cursor-pointer' onClick={onClickHandler}>
                <img id="home" src={img} className='imgDimensions' />
            </div>
        </>
    );
}
