import React from 'react';

export const ResponsiveExample = () => {
  return (
    <div className="card">
      <div className="grid card-container indigo-container">
        <div className="w-full  md:w-3  h-4rem _background_color_darkBlue text-white font-bold text-center p-4 border-round">
          1
        </div>
        <div className="w-full sm:mt-3  md:w-3 h-4rem _background_color_darkBlue text-white font-bold text-center p-4 border-round mx-4">
          2
        </div>
        <div className="w-full sm:mt-3  md:w-3 h-4rem _background_color_darkBlue text-white font-bold text-center p-4 border-round">
          3
        </div>
      </div>
    </div>
  );
};
