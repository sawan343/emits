import React, {useContext} from "react";
import { AppContext } from "../../store/AppContext";
import useGetAll_KPI_TYpesBySourceTag from "../../hooks/useGetAll_KPI_TYpesBySourceTag";
import { Loader } from "../Loader/Loader";
import { TREND_KPI_TYPE_MAPPING } from "../../utils/constants";
import { getLocaleNumber, precisionDecimal } from "../../utils/utils";

export const GasesTable = (props:any) => {
  const { locale } = useContext(AppContext);
  const { activeRank } = props;
  const {asset_name, sourcetag_displayname}  = props.sourceTagMetaData;
  const {
    kpi_values,
    headers,
    loading,
    uom,
    error,
  } =  useGetAll_KPI_TYpesBySourceTag("",asset_name, activeRank);

  if(loading) return <Loader />;

  return (
    <div className="gasesTable">
      <div className="table" id="results">
        <div className="theader">
          <div className="table_header">{locale["emissionsSources"]}</div>

          {
            headers?.map((item:any,i:number) =>   <div className="table_header" key={i+"gases_header"}> {TREND_KPI_TYPE_MAPPING[item?.toLowerCase()].displayName} (TONNES) </div>)
          }
        </div>
        <div className="table_row">
          <div className="table_small">
            <div className="table_cell">{locale["emissionsSources"]}</div>
            <div className="table_cell">{sourcetag_displayname}</div>
          </div>
          {
            headers?.map((item:any, i:number) =>(
            <div className="table_small" key={i+"table_small"}>
            <div className="table_cell" key={i+"table_cell1"}> {item} <span>({uom}) </span></div>
            <div className="table_cell" key={i+"table_cell2"}>{getLocaleNumber(precisionDecimal(kpi_values[item]))}</div>
          </div>) )
          }
        </div>
      </div>
    </div>
  );
};
