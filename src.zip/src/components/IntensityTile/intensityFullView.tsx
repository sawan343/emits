import React, { useContext} from "react";
import { ChartVisual } from "./lineChartVisual";
import { tileNames,KPI_TYPES_NAME_MAPPING } from "../../utils/constants";
import { getLocaleNumber, precisionDecimal} from "../../utils/utils";
import { AppContext } from '../../store/AppContext';

import minimizeWhite from '../../assets/images/minimizeWhite.png';
import minimizeBlack from '../../assets/images/minimizeBlack.png';

const IntensityTileFullView = (props: any) => {
    const { currentValue, maxValue, uom, values } = props.intensityData;
    const { locale } = useContext(AppContext);
    const { page, zoomHandler, selectedKpiTypeFromDropdown } = props;
    return (
        <div className={`${page==='site'?'lightBackground':'darkBackground'}`}>
            <div className={'p-4 pl-5'}>
                <div className='header text-xs font-bold text-base flex justify-content-between'>
                    {KPI_TYPES_NAME_MAPPING?.[selectedKpiTypeFromDropdown?.toLowerCase()]?.tileDisplayName || KPI_TYPES_NAME_MAPPING?.['co2e']?.tileDisplayName}
                    <img src={page==='site'?minimizeBlack:minimizeWhite} onClick={() => {
                        if(page!=='site'){
                            const test = document.getElementsByClassName("map-legend-container");
                            (test?.[0] as any).hidden=false;
                        }
                        zoomHandler(props.intensityData);
                    }} />
                </div>
                <div className="ValueDetails flex justify-content-end mt-3">
                    <div className="currentValueDetails">
                        <div className = "currentText text-base font-normal">{locale['currentValue']}</div>
                        <div className = "currentValue text-2xl ml-1">{getLocaleNumber(precisionDecimal(currentValue))}</div>
                        <div className = {'units font-medium ml-1'}>{uom}</div>
                    </div>
                    <div className = 'maximumValueDetails ml-5'>
                        <span className="maximumText font-normal text-base">{locale['maximumValue']}</span>
                        <span className="MaximumValue text-2xl ml-1">{getLocaleNumber(precisionDecimal(maxValue))}</span>
                        <div className={'units font-medium ml-1'}>{uom}</div>
                    </div>
                </div>
            </div>
            <div className={'LineChart p-4'}>
                <ChartVisual
                    style={{ width: '90%', height: '60%' }}
                    color={'#FFC527'}
                    chartValue={values}
                    tileName={tileNames.intensityZoom}
                    page={page}
                    uom={uom}
                    selectedKpiTypeFromDropdown = {selectedKpiTypeFromDropdown}
                />
            </div>
        </div>
    )
}

export default React.memo(IntensityTileFullView);