
import React, { useContext } from "react";
import * as Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { CHART_COLORS, tileNames, TREND_KPI_TYPE_MAPPING } from '../../utils/constants';
import { getLocaleDate, getLocaleNumber, getLocaleTime, getLocaleMonth, precisionDecimal } from "../../utils/utils";
import { getReportingPeriod } from "../../api/graphqlUtils";
import { AppContext } from '../../store/AppContext';
interface IProps {
    values: Array<any>
    productIndex: number;
    source: string;
}



export const ChartVisual = (props: any) => {
    const { chartValue, tileName, page, source, uom, style, selectedKpiTypeFromDropdown } = props;
    const { timeContext } = useContext(AppContext);

    const getXAxis = () => {
        let xAxis: any = [];
        chartValue?.map((item: any) => {
            xAxis.push(item.time);
        });
        return xAxis;
    };

    const getSeries = (fieldName: any) => {
        let series: any = [];
        chartValue?.map((item: any) => {
            series.push(item?.[fieldName]);
        })
        const lastIndex = series.length - 1;
        const y_last = series[lastIndex];
        if ((tileName === tileNames.criticalSites || tileName === tileNames.criticalSitesZoom) && page === 'site') {
            const highestValue = Math.max(...series);
            const lowestValue = Math.min(...series);
            const highestIndex = series.indexOf(highestValue);
            const lowestIndex = series.indexOf(lowestValue);
            series[lastIndex] = { y: y_last, color: "#64C3FF", tooltip_text: "Current", marker: { enabled: true } };
            if (highestIndex !== lastIndex) {
                const y_highest = series[highestIndex];
                series[highestIndex] = { y: y_highest, tooltip_text: "Highest", color: "#EE3124", marker: { enabled: true, radius: 4 } }
            }
            if (highestIndex !== lowestIndex && lastIndex !== lowestIndex) {
                const y_lowest = series[lowestIndex];
                series[lowestIndex] = { y: y_lowest, color: "#279D2B", tooltip_text: "Lowest", marker: { enabled: true, radius: 4 } };
            }
        }
        else if (tileName === tileNames.intensity && fieldName === 'actualValue') {
            series[lastIndex] = { y: y_last, tooltip_text: "Current", marker: { enabled: true, radius: 4 } };
        }
        return series
    }

    const getDateFormat = (ISOdate: any) => {
        const options = {
            year: "numeric",
            month: "long",
            day: "numeric",
            hour: 'numeric',
            minute: 'numeric',
            hour12: false
        };
        const text = getLocaleDate(ISOdate, options);
        return text;
    }

    const getColor = (page: any, tileName: any, lineName: any) => {
        if (page === 'site') {
            if (tileName === tileNames.intensity || tileName === tileNames.intensityZoom) {
                if (lineName === 'actualValue') {
                    return '#64C3FF'
                }
                else if (lineName === 'targetHighLimit') {
                    return '#303030'
                }
                else if (lineName === 'warningHigh') {
                    return '#EE3124'
                }
            }
            else {
                if (lineName === 'actualValue') {
                    return CHART_COLORS[source]
                }
                if (lineName === 'targetHighLimit') {
                    return '#303030'
                }
                else if (lineName === 'warningHigh') {
                    return '#EE3124'
                }
            }

        }
        else {
            if (lineName === 'actualValue') {
                if (tileName === tileNames.intensity || tileName === tileNames.intensityZoom) {
                    return '#64C3FF'
                }
                else {
                    return '#EE3124'
                }
            }
            else if (lineName === 'targetHighLimit') {
                return '#F4F4F4'
            }
            else if (lineName === 'warningHigh') {
                return '#EE3124'
            }
        }
    }

    const getXAxisLabels = (reportingPeriod: any, value: any) => {
        if (reportingPeriod === 'Hourly') {
            return getLocaleTime(value, { hour: 'numeric', minute: 'numeric', hour12: false });
        }
        if (reportingPeriod === 'Daily') {
            return getLocaleDate(value, { day: '2-digit' });
        }
        if (reportingPeriod === 'Monthly') {
            return getLocaleDate(value, { month: "long" });
        }
    }

    const getXAxisTitle = (values: any, reportingPeriod: any) => {
        const date = new Date(values?.[0]);
        if (reportingPeriod === "Daily") {
            return `${getLocaleMonth(values?.[0], { month: "long" })} ${date.getFullYear()}`;
        }
        if (reportingPeriod === "Hourly") {
            return `${getLocaleDate(values?.[0], { day: '2-digit' })} ${getLocaleMonth(values?.[0], { month: "long" })} ${date.getFullYear()}`;
        }
        if (reportingPeriod === "Monthly") {
            return `${date.getFullYear()}`;
        }
        return '';
    };

    const getYAxisTitle = (selectedKpiTypeFromDropdown: any) => {
        let gasName = TREND_KPI_TYPE_MAPPING?.[selectedKpiTypeFromDropdown?.toLowerCase()]?.displayName || TREND_KPI_TYPE_MAPPING?.['co2e']?.displayName;
        return `<div><div>${gasName}</div><div>${uom}<div></div>`;
    };

    const getOptions = () => {
        return {
            chart: {
                backgroundColor: 'transparent'
            },
            credits: {
                enabled: false
            },
            title: {
                text: '',
                align: 'left'
            },

            subtitle: {
                text: '',
                align: 'left'
            },

            xAxis: {
                visible: true,
                categories: getXAxis(),
                gridLineWidth: 0,//Set this to zero,
                lineWidth: 1,
                lineColor: '#8C8C8C',
                title: {
                    text: (tileName === tileNames.intensityZoom || tileName === tileNames.criticalSitesZoom) ? getXAxisTitle(getXAxis(), getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase())) : '',
                    margin: 20,
                    style: {
                        fontSize: "1rem",
                        color: page === 'site' ? '#8C8C8C' : '#FFFFFF',
                    }
                },
                labels: {
                    enabled: (tileName === tileNames.intensityZoom || tileName === tileNames.criticalSitesZoom) ? true : false,
                    formatter: function () {
                        const current: any = this;
                        if (current.value) {
                            return getXAxisLabels(getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()), current.value);
                        }
                    },
                    style: {
                        color: page === 'site' ? '#8C8C8C' : '#FFFFFF',
                    }
                }
            },

            yAxis: {
                visible: true,
                gridLineWidth: 0,//Set this to zero,
                lineWidth: 1,
                lineColor: '#8C8C8C',
                title: {
                    useHTML: true,
                    text: (tileName === tileNames.intensityZoom || tileName === tileNames.criticalSitesZoom) ? getYAxisTitle(selectedKpiTypeFromDropdown) : '',
                    margin: 20,
                    style: {
                        fontSize: "1rem",
                        color: page === 'site' ? '#8C8C8C' : '#FFFFFF',
                    }
                },
                labels: {
                    enabled: (tileName === tileNames.intensityZoom || tileName === tileNames.criticalSitesZoom) ? true : false,
                    style: {
                        color: page === 'site' ? '#8C8C8C' : '#FFFFFF',
                    }
                }
            },
            legend: {
                enabled: (tileName === tileNames.intensityZoom || tileName === tileNames.criticalSitesZoom) ? true : false,
                title: {
                    text: '',
                    style: {
                        textTransform: "uppercase",
                        fontWeight: 500,
                        textDecoration: 'none'
                    }
                },
                itemStyle: {
                    fontWeight: 500,
                    fontSize: "1rem",
                    letterSpacing: '0.01rem',
                    textDecoration: 'none',
                    color: page === 'site' ? '#8C8C8C' : '#FFFFFF'
                },
                itemHoverStyle: {
                    color: "#DEF9FF"
                },
                align: "left",
                symbolRadius: 2,
                margin: 50
            },
            plotOptions: {
                series: {
                    marker: { enabled: false },
                }
            },
            tooltip: {
                outside: true,
                enabled: true,
                useHTML: true,
                backgroundColor: '#FFFFFF',
                shadow: 'none',
                borderWidth: 0,
                style: {
                    color: '#303030', borderRadius: '0.25rem', Width: '13.75rem', Height: '3.648rem', paddingTop: '0.5rem', paddingRight: '0.75rem', paddingLeft: '0.5rem'
                },
                formatter(): any {
                    const unitText = uom;
                    return `<div>
                    <div style='font-weight: 700; font-size: 0.75rem;'>${getDateFormat(new Date((this as any).x))}</div>
                    <div style='font-weight: 500; font-size: 1rem; margin-top:0.5rem'>
                    <span style='font-weight: 900;'><strong>${(this as any).point?.tooltip_text || 'Value'}: ${getLocaleNumber(precisionDecimal(+((this as any).y)))}</strong> </span>${unitText}
                    </div>
                    </div>`
                },
            },
            series: [
                {
                    name: 'Actual Value',
                    lineWidth: (tileName === tileNames.criticalSites && page === 'site') ? 2 : 4,
                    data: getSeries('actualValue'),
                    color: getColor(page, tileName, 'actualValue'),
                    visible: true,

                },
                {
                    //target high
                    name: (tileName === tileNames.intensityZoom || tileName === tileNames.criticalSitesZoom) ? 'Target High' : '',
                    lineWidth: 1,
                    data: (tileName === tileNames.criticalSites && page === 'site') ? [] : getSeries('targetHighLimit'),
                    color: getColor(page, tileName, 'targetHighLimit'),
                    label: {
                        onArea: false,
                        position: 'right',
                        style: {
                            fontSize: '0.75rem'
                        }

                    }
                },
                // {
                //     //target low
                //     name: (tileName === tileNames.intensityZoom || tileName ===tileNames.criticalSitesZoom)?'Target Low':'',
                //     lineWidth: 1,
                //     data: (tileName === tileNames.criticalSites && page==='site') ? [] : getSeries('targetLowLimit'),
                //     color: getColor(page,tileName,'targetLowLimit'),
                //     visible: false,
                //     label:{
                //         onArea: false,
                //         position:'right',
                //         style:{
                //             fontSize: '0.75rem'
                //         }

                //     }
                // },
                {
                    //warning high
                    name: (tileName === tileNames.intensityZoom || tileName === tileNames.criticalSitesZoom) ? 'Warning High' : '',
                    lineWidth: 1,
                    data: (tileName === tileNames.criticalSites && page === 'site') ? [] : getSeries('warningHigh'),
                    color: getColor(page, tileName, 'warningHigh'),
                    dashStyle: 'dash',
                    label: {
                        onArea: false,
                        position: 'right',
                        style: {
                            fontSize: '0.75rem',
                        }

                    }
                },
                // {
                //     //warning low
                //     name: (tileName === tileNames.intensityZoom || tileName ===tileNames.criticalSitesZoom)?'Warning Low':'',
                //     data: (tileName === tileNames.criticalSites && page==='site') ? [] : getSeries('warningLow'),
                //     color: getColor(page,tileName,'warningLow'),
                //     dashStyle: 'dash',
                //     visible: false,
                //     label:{
                //         onArea: false,
                //         position:'right',
                //         style:{
                //             fontSize: '0.75rem'
                //         }

                //     }
                // }
            ],

            responsive: {
                rules: [{
                    condition: {
                        maxWidth: 500
                    },
                }]
            }
        }
    };
    return (<div className="chart">
        <HighchartsReact highcharts={Highcharts} options={getOptions()} containerProps={{ style: style }} />
    </div>)
};