import React, { useReducer } from "react";
import { useContext } from "react";
import { AppContext } from '../../store/AppContext';
import { ChartVisual } from './lineChartVisual';
import { useIntensityTileData } from '../../hooks/useIntensityTileData';
import { useLocation } from "react-router-dom";
import { ProgressSpinner } from 'primereact/progressspinner';
import { KPI_TYPES_NAME_MAPPING } from "../../utils/constants";
import { tileNames } from "../../utils/constants";
import {getLocaleNumber, precisionDecimal} from '../../utils/utils';
import maximizeWhite from '../../assets/images/maximizeWhite.png';
import maximizeBlack from '../../assets/images/maximizeBlack.png';

interface ILineBarProps {
    page:any;
    params:any;
    selectedKpiTypeFromDropdown:any
    zoomHandler:any
}
const IntensityCardContainer = (props: ILineBarProps) => {
    const {page, params, selectedKpiTypeFromDropdown, zoomHandler} = props;
    const { locale } = useContext(AppContext);
    const location = useLocation();
    const { intensityTileData, loading, error } = useIntensityTileData(page, params, selectedKpiTypeFromDropdown);
    const { currentValue, maxValue, uom, values } = intensityTileData;
    console.log('intensityTileData ---------->',intensityTileData);
    return (
        <>
            {loading ?
                <div className='flex justify-content-center align-items-center'>
                    <ProgressSpinner
                        className="spinner"                                                                                    
                        animationDuration=".5s"
                        pt={{
                            circle: {
                                style: { stroke: '#A0A0A0', strokeWidth: 3, animation: '0s' },
                            },
                        }} />
                </div> :
                <>
                    <div className={`header text-xs flex justify-content-between ${page==='site'?'lightBackground':'darkBackground'}`}>
                        {KPI_TYPES_NAME_MAPPING?.[selectedKpiTypeFromDropdown?.toLowerCase()]?.tileDisplayName || KPI_TYPES_NAME_MAPPING?.['co2e']?.tileDisplayName}
                        <img src={page==='site'?maximizeBlack:maximizeWhite} onClick={() => {
                            if(page!=='site'){
                                const test = document.getElementsByClassName("map-legend-container");
                                (test?.[0] as any).hidden=true;
                            }
                            zoomHandler(intensityTileData);
                        }} />
                    </div>
                    <div className="ValueDetails">
                        <div className="currentValueDetails mt-3 ">
                            <div className="currentText text-sm mr-5 font-bold">{locale['currentValue']}</div>
                            <div className="currentValue text-base">{getLocaleNumber(precisionDecimal(currentValue))}</div>
                            <div className={`units font-medium ml-1 ${page==='site'?'lightBackground':'darkBackground'}`}>{uom}</div>
                        </div>
                        <div className="maximumValueDetails mt-2 ">
                            <span className="maximumText font-bold text-sm mr-3">{locale['maximumValue']}</span>
                            <span className="MaximumValue font-bold text-base">{getLocaleNumber(precisionDecimal(maxValue))}</span>
                            <div className={`units font-medium ml-1 ${page==='site'?'lightBackground':'darkBackground'}`}>{uom}</div>
                        </div>
                    </div>

                    <div className="LineChart mt-2">
                        <ChartVisual
                            color={'#FFC527'}
                            chartValue = {values}
                            tileName = {tileNames.intensity}
                            page = {page} 
                            uom = {uom}
                            style = {{ width: '18.625rem' , height:'2.844rem'}}
                        />
                    </div>
                </>}

        </>
    )
}

export default React.memo(IntensityCardContainer);