import React from 'react';
import "primereact/resources/themes/lara-light-indigo/theme.css"; // theme
import "primereact/resources/primereact.css"; // core css
import "primeflex/primeflex.css";
import "./KpiBar.scss";
import { Toolbar } from "primereact/toolbar";
import useKPIBarData from '../../hooks/useKPIBarData';
import { ProgressSpinner } from 'primereact/progressspinner';
import { useLocation } from 'react-router-dom';
import {getLocaleNumber, precisionDecimal} from '../../utils/utils';
interface BarProps {
  page:any;
  params:any;
}

export const KpiBar = React.memo((props: BarProps) => {
  const {page, params} = props;

  const location = useLocation();
  const { kpiBarInputData, loading, error } = useKPIBarData(page, params);
  const Content = (
    <div className="lg:flex w-full">
      {loading ? <div className='flex w-full justify-content-center'>
        <ProgressSpinner
          style={{ width: '3.125rem', height: '3.125rem'}}
          animationDuration=".5s"
          pt={{
            circle: {
              style: { stroke: '#A0A0A0', strokeWidth: 3, animation: '0s' },
            },
          }}
        />
      </div> :
        kpiBarInputData.map((item: any, index: number) => {
          return <div className="w-full lg:mb-0 sm:mb-4  list1" key={index}>
            <div className="name text-xs font-bold">{item.displayName}</div>
            <div className="unit font-medium mt-1">{item.uom}</div>
            <div className="val text-2xl font-bold">{getLocaleNumber(precisionDecimal(item.actualValue))}</div>
          </div>
        })}


    </div>
  );

  return (
    <>
      <Toolbar className="Prod pt-3 pb-2 pl-5 pr-0 mt-3" start={Content} />
    </>
  );
});



