import React, { useContext } from "react";
import { ChartVisual } from "../IntensityTile/lineChartVisual";
import { tileNames } from "../../utils/constants";
import { AppContext } from '../../store/AppContext';
import { getLocaleNumber, precisionDecimal } from "../../utils/utils";
import minimizeWhite from '../../assets/images/minimizeWhite.png';
import minimizeBlack from '../../assets/images/minimizeBlack.png';

const CriticalSiteFullView = (props: any) => {
    const { locale } = useContext(AppContext);
    const { page, criticalSiteZoomHandler, selectedKpiTypeFromDropdown, criticalSiteData } = props;
    let len = criticalSiteData?.length
    return (
        <div className={`critical_site_container_full_view ${page === 'site' ? 'lightBackground' : 'darkBackground'}`}>
            <div className={'criticalSite_full_view p-4 pl-5'}>
                <div className='header_full_view font-bold text-base'>
                    {page === 'site' ? criticalSiteData[0].sourcetag_displayname : criticalSiteData[0].site + ' , ' + criticalSiteData[0].region}
                    <img src={page === 'site' ? minimizeBlack : minimizeWhite} onClick={() => {
                        if (page !== 'site') {
                            const test = document.getElementsByClassName("map-legend-container");
                            (test?.[0] as any).hidden = false;
                        }
                        criticalSiteZoomHandler(criticalSiteData);
                    }} />
                </div>
                <div className="ValueDetails flex justify-content-end  mt-3">
                    <div className="valueDisplay flex-column">
                        <div>
                            <span className="text-2xl">
                                {getLocaleNumber(precisionDecimal(criticalSiteData?.[len - 1]?.actualValue))}
                            </span>
                            <span className="unitText font-medium"> {criticalSiteData?.[0]?.uom} </span>
                        </div>
                        {page !== 'site' &&
                            <div className="deltaValueDetails text-xl">
                                {criticalSiteData?.[len - 1]?.targetHighLimit > 0 && getLocaleNumber(precisionDecimal(criticalSiteData?.[len - 1]?.targetHighLimit - criticalSiteData?.[len - 1]?.actualValue))}
                            </div>
                        }
                    </div>
                </div>
                
            </div>
            <div className={'LineChart p-4'}>
                <ChartVisual
                    style={{ width: '90%', height: '60%' }}
                    color={'#FFC527'}
                    chartValue={criticalSiteData}
                    tileName={tileNames.criticalSitesZoom}
                    page={page}
                    uom={criticalSiteData[0].uom}
                    source={criticalSiteData[0].source_displayname}
                    selectedKpiTypeFromDropdown={selectedKpiTypeFromDropdown}
                />
            </div>
        </div>
    )
}

export default React.memo(CriticalSiteFullView);