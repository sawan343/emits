import * as React from "react";
import { useContext } from "react";
import { AppContext } from '../../store/AppContext';
import "./criticalSiteTiles.scss";
import { ChartVisual } from "../IntensityTile/lineChartVisual";
import { useCriticalSiteData } from "../../hooks/useIntensityTileData";
import { redirect, useNavigate } from "react-router-dom";
import { ProgressSpinner } from 'primereact/progressspinner';
import { useLocation } from "react-router-dom";
import { NO_DATA_SAVED, tileNames } from "../../utils/constants";
import { emissionNavigator } from "../../utils/utils";
import { getLocaleNumber, precisionDecimal } from '../../utils/utils';
import { portalAssetNavigation } from "../../portal/portal";
import maximizeWhite from '../../assets/images/maximizeWhite.png';
import maximizeBlack from '../../assets/images/maximizeBlack.png';
interface ILineBarProps {
  page: any;
  params: any;
  selectedKpiTypeFromDropdown: any;
  criticalSiteZoomHandler: any;
}

export const CriticalSitesContainer = (props: ILineBarProps) => {
  const location = useLocation();
  const { page, params, selectedKpiTypeFromDropdown,criticalSiteZoomHandler } = props;
  const { locale } = useContext(AppContext);
  const { critialSitesData, loading, error } = useCriticalSiteData(page, params, selectedKpiTypeFromDropdown);
  console.log('criticalSiteData -------->', critialSitesData);
  const navigate = useNavigate();

  const navigateToPage = (navigator: any, page: string, redirectData: any, forWardSlash: string = '') => {
    let localAssetDetails: any = JSON.parse(sessionStorage.getItem('assetData')!);
    let siteName = localAssetDetails?.filter((item: any) => item?.name == redirectData?.siteName);
    console.log({ localAssetDetails })
    console.log("siteName : ", siteName)
    if (siteName && siteName.length == 1) {
      //portalAssetNavigation(siteName[0]?.id);  // portal navigation stopped as it was doing dual navigation, to be enabled once Portal team come up with the solution of selecting hierarchy without navigating.
    }
    return emissionNavigator(navigator, page, redirectData, forWardSlash);
  }

  return (
    <div className="critical_site_container">
      <div className="HeaderTile p-3 mt-3 text-xs"> {page === 'site' ? locale['criticalSourceTags'] : locale['criticalSitesName']}</div>
      {loading ?
        <div className="flex">
          <ProgressSpinner
            className="spinner"
            animationDuration=".5s"
            pt={{
              circle: {
                style: { stroke: '#A0A0A0', strokeWidth: 3, animation: '0s' },
              },
            }}
          />
        </div>
        :
        <React.Fragment>
          {
            (critialSitesData?.length > 0) ?
              critialSitesData.map((item: any, index: any) => {
                return (
                  <div className="criticalSite p-3 mt-2" key={index}>
                    <div className="flex justify-content-between">
                    <div
                      className="header text-base font-bold"
                      onClick={() => {
                        navigateToPage(navigate, 'site', { siteName: item?.[0]?.site, redirect: item?.[0]?.region }, '/');
                      }}
                    >
                      {page === 'site' ? item?.[0]?.sourcetag_displayname : `${item?.[0]?.site}, ${item?.[0]?.region}`}
                    </div>
                    <img src={page==='site'?maximizeBlack:maximizeWhite} height='16px' width='16px' onClick={() => {
                            if(page!=='site'){
                                const test = document.getElementsByClassName("map-legend-container");
                                (test?.[0] as any).hidden=true;
                            }
                            criticalSiteZoomHandler(item);
                        }} />
                    </div>
                    
                    <div className="valueTrendContainer mt-4">
                      <div className="valueContainer">
                        <div className="currentValueDetails">
                          <span className="valueDisplay text-base">
                            {getLocaleNumber(precisionDecimal(item?.[item?.length - 1]?.actualValue))}
                          </span>
                          <span className="unitText font-medium"> {item?.[0]?.uom} </span>
                        </div>
                        {page !== 'site' && <div className="deltaValueDetails text-sm">
                          {item?.[item?.length - 1]?.targetHighLimit > 0 && getLocaleNumber(precisionDecimal(item?.[item?.length - 1]?.targetHighLimit - item?.[item?.length - 1]?.actualValue))}
                        </div>}
                      </div>
                      <div className="LineChart ml-4">
                        <ChartVisual
                          color={'#EE3124'}
                          chartValue={item}
                          tileName={tileNames['criticalSites']}
                          page={page}
                          source={item[0]?.source_displayname}
                          uom={item[0]?.uom}
                          style = {{ width: '12rem' , height:'2.844rem'}}
                        />
                      </div>
                    </div>
                  </div>
                );
              }) : <div className="criticalSite p-3 mt-2" >
                <div className={`noDataAvailable ${page === 'site' ? 'siteTextColor' : 'enterpriseTextColor'}`}>
                  {NO_DATA_SAVED}
                </div>
              </div>
          }
        </React.Fragment>
      }
    </div>
  );
};
