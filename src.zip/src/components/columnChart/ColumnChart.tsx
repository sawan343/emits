import React, { useContext, useEffect, useMemo, useReducer } from "react";
import HighchartsReact from "highcharts-react-official";
import Highcharts from "highcharts";
import NoDataToDisplay from "highcharts/modules/no-data-to-display";
import ColumnChartData from "../../hooks/useColumnChartData";
import { deepCloneEmission, precisionDecimal } from "../../utils/utils";
import { AppContext } from "../../store/AppContext";
import { ProgressSpinner } from "primereact/progressspinner";
import { DrillUPImage } from "../../utils/constants";

export const ColumnChart = (props: any) => {
  const { siteName, selectedTrendNode, setSelectedColumnNode, getSelectedNodeList, isUnitLevel, siteDetailFilter } = props;
  const { portalContext, timeContext } = useContext(AppContext);
  const [state, setState] = useReducer((oldState: any, newState: any) => (
    { ...oldState, ...newState }), {
    selectedCategory: [],
    series: [],
    xAxis: [],
    xAxisTitle: '',
    stacking: '',
    loading: true
  })

  useEffect(() => {
    (async () => {
      setState({ loading: true });
      const { series, xAxis, xAxisTitle, stacking } = await ColumnChartData(state.selectedCategory, portalContext, timeContext, siteName, isUnitLevel, siteDetailFilter);
      NoDataToDisplay(Highcharts);
      return setState({ series, xAxis, xAxisTitle, stacking, loading: false });
    })();
   
  }, [state.selectedCategory, timeContext, JSON.stringify(siteDetailFilter)]);

  useMemo(() => {
    setState({ selectedCategory: [] })
  }, [isUnitLevel])

  const getParent = () => {
    const { selectedCategory } = state;
    return selectedCategory[selectedCategory.length - 1]?.displayName;
  }

  const onDrillUp = () => {
    const { selectedCategory } = deepCloneEmission(state);
    console.log("pop selec ", selectedCategory)
    selectedCategory?.pop();
    return setState({ selectedCategory });
  }

  useEffect(() => {
    if (selectedTrendNode) {
      changeSelectedNode()
    }

  }, [JSON.stringify(selectedTrendNode)])
  
  useEffect(()=>{
getSelectedNodeList(state.selectedCategory)
},[state.selectedCategory])

  const changeSelectedNode = () => {
    let selectedCategoryNodes = deepCloneEmission(state.selectedCategory)
    let nodeCheck=selectedCategoryNodes.filter((item:any)=>item.uid==selectedTrendNode.uid);
    if(nodeCheck.length>0){
      return false
    }
    let selectedCategory=checkNodeLevelTree(selectedCategoryNodes, selectedTrendNode)
    selectedCategory.push({
      level: selectedTrendNode.level + 1,
      displayName: selectedTrendNode.name,
      parent: selectedTrendNode.parent,
      uid: selectedTrendNode.uid
    })
    console.log('selectedCategory', selectedCategory);
    return setState({ selectedCategory });
  }

  const checkNodeLevelTree=(allNodes:any, newNode:any)=>{
    let selectedNodes=deepCloneEmission(allNodes);
    let newNodeLevel=newNode.level+1;
    if(newNodeLevel<=selectedNodes.length){
      selectedNodes.length=newNode.level;
      return selectedNodes;
    }
    else{
      return selectedNodes;
    }
  }
  const onClick = (event: any) => {
    const { selectedCategory } = deepCloneEmission(state);
    if (isUnitLevel) {
      if (state.selectedCategory.length == 1) {
        return false;
      }
      else {
        let trenGridNode = {
          node: {
            level: event?.point?.series?.userOptions?.level - 1,
            name: event?.point?.series?.name,
            parent: [...event?.point?.series?.userOptions?.parent],
            uid: event?.point?.series?.userOptions?.uid
          }
        };
        selectedCategory.push({
          level: event?.point?.series?.userOptions?.level,
          displayName: event?.point?.series?.name,
          parent: [...event?.point?.series?.userOptions?.parent],
          uid: event?.point?.series?.userOptions?.uid
        })

        setSelectedColumnNode(trenGridNode);
        return setState({ selectedCategory });
      }

    }
    else {
      if (state.selectedCategory.length == 3) {
        return false;
      }
      else {

        let trenGridNode = {
          node: {
            level: event?.point?.series?.userOptions?.level - 1,
            name: event?.point?.series?.name,
            parent: [...event?.point?.series?.userOptions?.parent],
            uid:event?.point?.series?.userOptions?.uid
          }
        };
        selectedCategory.push({
          level: event?.point?.series?.userOptions?.level,
          displayName: event?.point?.series?.name,
          parent: [...event?.point?.series?.userOptions?.parent],
          uid:event?.point?.series?.userOptions?.uid
        })

        setSelectedColumnNode(trenGridNode);
        return setState({ selectedCategory });
      }
    }

  }

  const getOptions = () => {
    const { series, xAxis, xAxisTitle } = state;
    return {
      chart: {
        height: '322rem',
        backgroundColor: 'transparent'
      },
      title: {
        text: ""
      },
      xAxis: {
        title: {
          text: xAxisTitle,
          margin: 20,
          style: {
            fontFamily: "Arial",
            //fontWeight: 700,
            fontSize: "1rem"
          }
        },
        labels: {
          style: {
            fontFamily: "Arial",
            //fontWeight: 700,
            fontSize: '0.8rem'
          }
        },
        categories: xAxis
      },
      yAxis: {
        min: 0,
        title: {
          text: "CO2e (Tonnes)",
          margin: 20,
          style: {
            fontFamily: "Arial",
            //fontWeight: 700,
            fontSize: '1rem'
          }
        },
        labels: {
          style: {
            fontFamily: "Arial",
            fontWeight: 700,
            fontSize: '0.8rem'
          }
        }
      },
      tooltip: {
        outside: true,
        enabled: true,
        useHTML: true,
        backgroundColor: '#FFFFFF',
        shadow: 'none',
        borderWidth: 0,
        style: {
          color: '#303030', borderRadius: '0.25rem', Width: '13.75rem', Height: '3.648rem', paddingTop: '0.5rem', paddingRight: '0.75rem', paddingLeft: '0.5rem'
        },
        formatter: function (this: any) {
          return `<div style='font-size: 1rem; font-weight: 700; border-radius:0.25rem;'>
                ${this.point.series.name}: ${precisionDecimal(this.point.y)}
            </div>`
        },
      },
      legend: {
        title: {
          text: '',
          style: {
            textTransform: "uppercase",
            fontWeight: 500,
            textDecoration: 'none'
          }
        },
        itemStyle: {
          fontWeight: 500,
          fontSize: "1rem",
          letterSpacing: '0.01rem',
          textDecoration: 'none'
        },
        itemHoverStyle: {
          textDecoration: 'none'
        },
        align: 'left',
        symbolRadius: 2,
        margin: 50
      },
      plotOptions: {
        column: {
          stacking: state.stacking,
          pointPadding: 0.2,
          borderWidth: 0
        },
        series: {
          pointWidth: 10,
          borderRadius: 2,
          cursor: "pointer",
          point: {
            events: {
              click: (event: any) => onClick(event)
            }
          }
        }
      },
      series: series,
      lang: {
        noData: "No data to display"
      },
      noData: {
        style: {
          fontWeight: "bold",
          fontSize: "15px",
          color: "#303030"
        }
      },
      credits: {
        enabled: false
      }
    };
  };
  console.log("hello selec cafegories", state.selectedCategory)
  return (
    state.loading ? (
      <div className='flex justify-content-center align-items-center loader-height'>
        <ProgressSpinner
          className="spinner"
          animationDuration=".5s"
          pt={{
            circle: {
              style: { stroke: "#A0A0A0", strokeWidth: 3, animation: "0s" },
            },
          }}
        />
      </div>
    ) :
      <div id="columnChart" className="mt-5">
        <HighchartsReact
          highcharts={Highcharts}
          options={getOptions()}
        />
        <div className="parent-drillup">
          <div>{getParent()}</div>
          {
            getParent() && <div><img onClick={onDrillUp} src={`data:image/svg+xml;base64,${btoa(DrillUPImage)}`} alt="" /></div>
          }
        </div>
      </div>
  );
};
