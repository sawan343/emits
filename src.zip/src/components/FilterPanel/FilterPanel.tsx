import React, { useContext, useEffect, useState } from "react";
import { AppContext } from "../../store/AppContext";
import { Tree } from "primereact/tree";
import { Button } from "primereact/button";


interface IFilterPanelProps {
  FilterPanelData: any;
}
const FilterPanel: any = (props: IFilterPanelProps) => {
  const { FilterPanelData } = props;
  const { locale, setSiteDetailFilter, siteDetailFilter } = useContext(AppContext);
  const [nodes, setNodes] = useState([]);
  const [selectedKeys, setSelectedKeys] = useState<any>(null);
  const [labelsWithParentId, setLabelswithParentId] = useState<any>(null);
  const [visible, setVisible] = useState(false);
  const closeIcon = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14 2L2 14M2 2L14 14" stroke="#606060" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  const NodeValue = {
    getTreeNodesData() {
      return FilterPanelData;
    },

    getTreeNodes() {
      return Promise.resolve(this.getTreeNodesData());
    },
  };
  useEffect(() => {
    if(FilterPanelData) {
      NodeValue.getTreeNodes().then((data: any) => setNodes(data));
    }
  }, [FilterPanelData]);

  useEffect(() => {
    if(selectedKeys && FilterPanelData) {
      setLabelswithParentId(getSelectedValuesWithParentId(FilterPanelData[0]?.children , selectedKeys));
    }
  },[selectedKeys])

  const getSelectedValues = (data:any, selectedObj:any, res = []) => {
    console.log('res', res);
    let arr:any = [...res];
    console.log('arr1', arr);

    data.forEach((element:any) => {
      const key = element?.key;
      if(selectedObj[key]?.checked || selectedObj[key]?.partialChecked) {
        console.log('arr2', arr);
        arr.push(element?.label);
      }
      if(element?.children) {
        console.log('arr3', arr);
        arr = getSelectedValues(element?.children, selectedObj, arr);
        console.log("children", arr);
      }
    });
    return arr;
  };

  const getSelectedValuesWithParentId = (data:any, selectedObj:any, res = []) => {
    let arr:any = [...res];
    data.forEach((element:any) => {
      const key = element?.key;
      if(selectedObj[key]?.checked || selectedObj[key]?.partialChecked) {
        if(element?.children) {
          element?.children?.forEach((child:any) =>{
            child["parentId"] = key;
          })
        }
        arr.push(element);
      }
      if(element?.children) {
        arr = getSelectedValuesWithParentId(element?.children, selectedObj, arr);
      }
    });
    return arr;
  };

  const closeFilter = () => setVisible(false);

  const applyFilterHandler: any = (e: any) => {
    if(!FilterPanelData[0]?.children || !selectedKeys) {
      setSiteDetailFilter([])
      return [];
    }
    let Data: any = getSelectedValues(FilterPanelData[0]?.children , selectedKeys);
    console.log("Data", Data);
    setSiteDetailFilter(Data);
    closeFilter();
  };

  const clearAll = () => {
    setSelectedKeys(null);
  };

  const footerContent = (
    <div>
      <Button
        label="Clear filter"
        className="buttonTextColor"
        onClick={clearAll}
        link
      />
      {/* <Button
        label="Cancel"
        onClick={() => setVisible(false)}
        className="p-button-text"
      /> */}
      <Button
        label="Apply"
        onClick={applyFilterHandler}
        autoFocus
        type="submit"
        className="filterSubmit"
      />
    </div>
  );

  const isLoading = (nodes?.length > 0) ? false : true;
  function  removeFilter(tagInfo:any) {
   // delete selectedKeys['1-0-4'];
    const keyToremove = tagInfo?.key;
    let itemsToDelete = [];

    const selectedKeys_copy = JSON.parse(JSON.stringify(selectedKeys));
    console.log("tagInfo", tagInfo);
    console.log("selectedKeys_copy", selectedKeys_copy);
    console.log("labelsWithParentId",   labelsWithParentId);
    itemsToDelete = labelsWithParentId?.filter((filterSingle:any) => filterSingle?.key === keyToremove || filterSingle?.parentId === keyToremove );
    console.log("itemsToDelete",itemsToDelete);
    //below condition is to remove parent if no child of that parent present
    if(itemsToDelete?.length === 1) {
      const parentIdofDeletedTag = itemsToDelete[0]?.parentId
    if(parentIdofDeletedTag) {
      //to check if onlyone child present of this parent
      const numberOfChild = labelsWithParentId?.filter((filterSingle:any) => filterSingle?.parentId === parentIdofDeletedTag  );
      if(numberOfChild?.length === 1) {
        //itemsToDelete = [...itemsToDelete, numberOfChild]
        delete selectedKeys_copy[numberOfChild[0]?.parentId];
      }
    };
    }
    

    itemsToDelete?.forEach((item:any) =>  delete selectedKeys_copy[item?.key]);
    console.log("selectedKeys_copy2",selectedKeys_copy);
    setSelectedKeys(selectedKeys_copy);
  };

  const FilterTags = ({tags}:any) => {
   const seletedTags = labelsWithParentId;
   return ( <>
   { 
      seletedTags &&  seletedTags?.length >  0 && seletedTags.map((tag:any, i:number) => <>
              <span className="filter-tag"> 
              <span key={i+"tags"} className="tag-label"> {tag?.label} </span> 
              <span className="tag-remove" onClick={removeFilter.bind(null, tag)}>
                    <img src={`data:image/svg+xml;base64,${btoa(closeIcon)}`} alt="image source tag"/>
              </span>
              </span>
              </> )
    }
   </>);
  };

  const Tags  = (e:any) => {
    const search =  e.element;
    const tagsWithSearch = <div className="custom-header-filter"> <div className="search">{ e.element}</div> <div className="tags-container"><FilterTags tags={siteDetailFilter}/></div></div>
    return tagsWithSearch;
  }
  return (
    <>
      <div className="filter-sort">
        <div className="filter-icon">
            <Button
              icon="pi pi-filter"  
              className="popUpButton"
              onClick={() => setVisible(!visible)}
            />
            { siteDetailFilter?.length > 0 && <span className="total-count"><span>{siteDetailFilter?.length}</span></span> }
        </div>
       <div  className="site-details-container">
         {visible && <header> <h3>Filter By</h3>  <span onClick = {closeFilter}>  <img src={`data:image/svg+xml;base64,${btoa(closeIcon)}`} alt="close filter"/></span></header>} 
          { visible && <Tree
                filterTemplate = {Tags}
                expandedKeys = {{'0': true, '0-0': true}}
                value={nodes}
                selectionMode="checkbox"
                selectionKeys={selectedKeys}
                filter
                filterPlaceholder="search the (placeholder)"
                onSelectionChange={(e: any) => {
                  setSelectedKeys(e.value)
                }}
                loading = { isLoading }
                footer = {footerContent}
              /> }
       </div>
      </div>
    </>
  );
};

export default FilterPanel;
