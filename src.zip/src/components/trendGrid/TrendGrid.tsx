import React, { useReducer, useEffect, useState, useContext } from 'react';
import { AppContext } from '../../store/AppContext';
import "primereact/resources/themes/lara-light-indigo/theme.css";
import "primereact/resources/primereact.css";
import "primeicons/primeicons.css";
import { Column } from "primereact/column";
import { TreeTable } from "primereact/treetable";
import { Image_Mapping } from "../../utils/constants";
import TrendPageData from '../../hooks/useTrendGridData';
import { addZeroes, deepCloneEmission, getLocaleNumber, precisionDecimal } from "../../utils/utils";

export const TrendGrid = (props: any) => {
    const [loadTrend, setLoadTrend] = useState(true);
    const { siteName, setSelectedTrendNode, selectedColumnNode, isUnitLevel, selectedNodeList, siteDetailFilter } = props;

    useEffect(() =>{
        setLoadTrend(false);
        setState({ expandedKeys:{}});
    },[JSON.stringify(siteDetailFilter)])

    useEffect(() =>{
        if(!loadTrend){
            setLoadTrend(true);
        }
    },[loadTrend])

    const { portalContext, timeContext } = useContext(AppContext);
    const [state, setState] = useReducer(
        (oldState: any, newState: any) => ({ ...oldState, ...newState }),
        {
            loading: true,
            trendsHeader: [],
            trendsNodes: [],
            selectedNodeKey: {},
            expandedKeys:null,
            
        }
    );

    const getHeader = (item: any) => {
        return <div>{item}</div>;
    };

    const headerActionTemplate = (data: any, options: any) => {
        return (
            <div>

                {Image_Mapping[data?.value] ? (
                    <React.Fragment>
                        <div>
                            <img
                                src={`data:image/svg+xml;base64,${btoa(
                                    Image_Mapping[data?.value]
                                )}`}
                                alt=""
                            />
                        </div>
                        <div>
                            {data?.data[options?.field]}
                        </div>
                    </React.Fragment>
                ) : (
                    <React.Fragment>
                        <span>
                            {data?.data[options?.field]}
                        </span>
                    </React.Fragment>
                )}
            </div>
        );
    };

    const rowsActionTemplate = (data: any, options: any) => {
        return (
            <div className={`toolTipContainer ${data?.data?.level === 0 ? "bold" : ""}`}>
                {/* <span className="tooltiptext"> {addZeroes(data?.data[options?.field])}</span> */}
                {getLocaleNumber(precisionDecimal(data?.data[options?.field]))}
            </div>
        );
    };

    const onExpand = async (e: any) => {
        console.log("helle expand ", e)
        let nodeBody = {
            level: e.node.level,
            parent: e.node.parent,
            name: e.node.name,
            uid:e.node.uid
        }
        setSelectedTrendNode(nodeBody)
        fetchNodeData(e);
        // setState({ expandedRowKey: e?.node?.key });
    };

    const fetchNodeData = async (e: any) => {
        if (!e.node.children) {
            setState({ loading: true });
            let newData = await TrendPageData(e.node.level + 1, e.node, portalContext, timeContext, siteName, isUnitLevel, siteDetailFilter)
            if (newData) {
                let lazyNode = { ...e.node };
                lazyNode.children = newData.dataValues;
                let _nodes = setChildrenData(e.node, state.trendsNodes, newData.dataValues)
                setState({ loading: false, trendsNodes: _nodes });
            }

        }
    }

    const setChildrenData = (node: any, currentData: any, newRecords: any) => {
        let parentRecords: any = node.parent;
        let parentLength: any = parentRecords.length
        let localRecords = deepCloneEmission(currentData);
        switch (parentLength) {
            case 1:
                localRecords.filter((item: any) => item.name == parentRecords[0])[0].children = newRecords;
                console.log("local 1", { localRecords })
                return localRecords
                break;
            case 2:
                localRecords.filter((item: any) => item.name == parentRecords[0])[0].children.filter((item: any) => item.name == parentRecords[1])[0].children = newRecords;
                console.log("local 2", { localRecords })
                return localRecords
                break;
            case 3:
                localRecords.filter((item: any) => item.name == parentRecords[0])[0].children.filter((item: any) => item.name == parentRecords[1])[0].children.filter((item: any) => item.name == parentRecords[2])[0].children = newRecords;
                console.log("local 3", { localRecords })
                return localRecords
                break;
            case 4:
                localRecords.filter((item: any) => item.name == parentRecords[0])[0].children.filter((item: any) => item.name == parentRecords[1])[0].children.filter((item: any) => item.name == parentRecords[2])[0].children.filter((item: any) => item.name == parentRecords[3])[0].children = newRecords;
                console.log("local 4", { localRecords })
                return localRecords
                break;
            default:
                break;
        }

    }


    const onCollapse = (e: any) => {
        setState({ expandedRowKey: "" });
    };

    const rowClassName = (node: any) => {
        return { "p-highlight": state.expandedRowKey === node?.key };
    };

    const getData = async () => {
        return await TrendPageData(0, '', portalContext, timeContext, siteName, isUnitLevel, siteDetailFilter)
    }

    const expandTrendRows=()=>{
        let newExpandedNodes={};
        if(selectedNodeList.length!==0){
            setState({ expandedKeys:{}})
            selectedNodeList.forEach((element:any, Index:any) => {
                   let val=element.displayName.replaceAll(' ','');
                newExpandedNodes={...newExpandedNodes,[val]:true}
                   
            });
            setState({ expandedKeys:newExpandedNodes})
        }
    }
    
    useEffect(()=>{
        setState({expandedKeys:null})
        expandTrendRows();
    },[selectedNodeList])

    useEffect(() => {
        getData().then((response: any) => {
            setState({ loading: false });
            if (response && response.dataValues) {
                setState({
                    trendsHeader: response.dataValues.headers,
                    trendsNodes: response.dataValues.nodes
                });
            }
        }).catch((err: any) => {
            setState({ loading: false });
            console.log(err)
        })
    }, [timeContext , JSON.stringify(siteDetailFilter)])

    useEffect(() => {
        if(selectedColumnNode){
            fetchNodeData(selectedColumnNode);
        }
    }, [JSON.stringify(selectedColumnNode), JSON.stringify(siteDetailFilter)])

    useEffect(()=>{
        console.log("source changes ", isUnitLevel)
        setState({ loading: true });
        getData().then((response: any) => {
            setState({ loading: false });
            if (response && response.dataValues) {
                setState({
                    trendsHeader: response.dataValues.headers,
                    trendsNodes: response.dataValues.nodes
                });
            }
        }).catch((err: any) => {
            setState({ loading: false });
            console.log(err)
        })
    },[isUnitLevel , JSON.stringify(siteDetailFilter)])

    console.log("trendsNodes ",state.trendsNodes)
    if(!loadTrend) return <></>;
    return (
        <div className='trend-tree-container'>
            <div className="card">
                <TreeTable
                    onExpand={onExpand}
                    onCollapse={onCollapse}
                    scrollHeight="21rem"
                    scrollable={true}
                    value={state.trendsNodes}
                    loading={state.loading}
                    rowClassName={rowClassName}
                    expandedKeys={state.expandedKeys}
                    onToggle={(e) =>{
                        console.log(e);
                        setState({expandedKeys: e.value})}}
                // onUnselect={onUnselect}
                >
                    <Column
                        field={"Emissions Sources"}
                        header={"EMISSIONS SOURCES"}
                        body={headerActionTemplate}
                        className='title-header'
                        expander
                    />
                    {state.trendsHeader.map((item: any) => {
                        return (
                            <Column
                                field={item?.field}
                                header={getHeader(item?.name)}
                                body={rowsActionTemplate}
                                className='title-header'
                            />
                        );
                    })}
                </TreeTable>
            </div>
        </div>
    )
}