import React, { memo, useContext } from "react";
import { AppContext } from "../../store/AppContext";
import { useNavigate } from "react-router-dom";
import Logo from '../../assets/images/logo.png';
import carbonNeutrality from '../../assets/images/carbonNeutrality.png';
import { Configuration } from "../../api/queryFieldMappings";
import { emissionNavigator, getLocaleNumber, getLocalePercentNumber } from "../../utils/utils";

interface ILandingPageProps {
  totalEmissionData: any
}

export const EmissionSummary = memo((props: ILandingPageProps) => {
  const { totalEmissionData: { carbonNeutralityData } = {}, totalEmissionData } = props;
  const { locale } = useContext(AppContext);
  const { emissionIntensityBar } = Configuration?.Kpi_Landing_Page;
  const navigate = useNavigate();

  const getTrianglePosition = () => {
    const trianglePoint = carbonNeutralityData?.trianglePoint;
    if(trianglePoint >= 100 ) {
      return 98.5
    };
    return trianglePoint;
  }
  
  return (
    <div className="emmison-summary flex flex-column md:h-30rem sm:h-full lg:overflow-hidden md:overflow-hidden themeTextPrimaryColor">
      <div className="header-container p-6 flex">
        <div className="icon"> <img src={Logo} alt="logo" /></div>
        <div className="header-text ml-3">
          <h1 className="m-0 text-2xl">{locale["GHGEmissionsPerf"]}</h1>
        </div>
      </div>

      <div className="summary-items flex md:flex-row sm:flex-column pl-8 pr-8 justify-content-between">
        <div className="summary-item lg:ml-1 w-22rem md:mt-4 sm:mt-4 md:w-16rem">
          <div className="intensity-text w-22rem text-sm justify-content-center flex md:w-16rem">
            {locale["ghgEmissionsIntensity"]}
          </div>
          <div className="uom text-sm justify-content-center flex">
                {`(${totalEmissionData.CO2eIntesityUom})`}
          </div>
          <div className="intensity-value text-4xl  font-bold justify-content-center flex">
            {getLocalePercentNumber(totalEmissionData.CO2ePercentage)}
          </div>
        </div>
        <div className="summary-item lg:ml-1  w-22rem  md:mt-4 sm:mt-6  md:w-16rem">
          <div className="intensity-text w-22rem text-sm justify-content-center flex md:w-16rem">
            {locale["methaneEmissionsIntensity"]}
          </div>
          <div className="uom text-sm justify-content-center flex">
          {`(${totalEmissionData.CH4IntesityUom})`}
          </div>
          <div className="intensity-value text-4xl  font-bold justify-content-center flex">
            {getLocalePercentNumber(totalEmissionData.CH4ePercentage)}
          </div>
        </div>
        <div className="summary-item lg:ml-1 w-22rem md:mt-4 sm:mt-6  md:w-16rem">
          <div className="intensity-text w-22rem text-sm justify-content-center flex md:w-16rem">
            {locale["ghgEmissionsInCo2e"]}
          </div>
          <div className="uom text-sm justify-content-center flex">
          {`(${totalEmissionData.CO2eTotalValueUom})`}
          </div>
          <div className="intensity-value text-4xl font-bold justify-content-center flex">
              {getLocaleNumber(totalEmissionData.CO2eTotalValue)}
          </div>
        </div>
      </div>

      <div className="summary-bottom flex md:flex-row sm:flex-column align-items-center justify-content-center">
        {/* <span className="netruality-kpi-type">{locale["co2e"]}</span> */}
        <div className="progress">
          {/* <div className="progress-bar">
            {
              carbonNeutralityData?.getCarbonNeutralityLimit.map((item: any, index: number) => {
                return (<div className="divider" style={{ right: `${item.percentage}` }}>
                  <div className="value">{getLocaleNumber(+(item.value))}</div>
                  {index !== 0 && index !== 4 ? <div className="hook"></div> : null}
                </div>)
              })
            }
            <div className="triangle" style={{ right: `${getTrianglePosition()}%` }}>
              <span>{(carbonNeutralityData?.current?.toFixed(3) || locale["nodata"])}</span>
            </div>
          </div>

          <div className="bottom-text mt-4">
            <span>{locale["yourJourneyToCarbonNeutrality"]}</span>
          </div> */}
          <img src={carbonNeutrality} alt="logo" />
        </div>

        <div className="dashboard-button ml-7 lg:align-self-start  md:align-self-center">
          <button
            type="button"
            className="themeTextPrimaryColor buttonBgColor buttonBorder px-3 py-2 text-base border-1 border-solid border-round cursor-pointer hover:bg-primary-600 hover:border-primary-600"
            onClick={() => {
              emissionNavigator(navigate, 'enterprise', null, '/');
            }}
          >
            {locale["viewDashboard"]}
          </button>
        </div>
      </div>
    </div>
  );
});
