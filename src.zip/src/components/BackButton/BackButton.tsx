import React, { useMemo } from "react";
import BackIcon from '../../assets/images/BackButton.png';
import { useNavigate } from 'react-router-dom';
import { goBack } from "../../utils/utils";

const Back = <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M13.5 7.75H2.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M7.5 13.1112L2.5 7.8056L7.5 2.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>;

export const  BackButton = (props:any) => {
    const {isWhiteBG} = props;
    const navigate = useNavigate();

    const onClickHandler = () => {
        goBack(navigate)
    }

    const buttonCSS = useMemo( ()=>{
        if(isWhiteBG) {
            return ''
        }
        return 'icon-bg-dark'
    },[isWhiteBG]);

    return (
        <>
            <div className={ `${buttonCSS} back-button cursor-pointer mr-2` } onClick = {onClickHandler}>
                <span> { Back } </span>
            </div>
        </>
        
    );
};
