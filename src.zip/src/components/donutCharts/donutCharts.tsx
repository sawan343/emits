import React, { memo, useContext } from "react";
import * as Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import useDonutChartData from "../../hooks/useDonutChartData";
import { ProgressSpinner } from "primereact/progressspinner";
import { getLocaleNumber, precisionDecimal } from '../../utils/utils';

const DonutCharts: any = (props: any) => {
  const { page, params } = props;
  const { donutChartData, loading, error } = useDonutChartData(page, params);
  const getOptions = (chartOptions: any) => {
    const options: any = {
      colors: chartOptions.color,
      chart: {
        type: "pie",
        marginTop: 0,
        paddingTop: 0
      },
      title: {
        useHTML: true,
        align: 'center',
        floating: true,
        y: 170,
        text: getLocaleNumber(precisionDecimal(chartOptions.totalActualValue)) + `<div className="unitMeasure">${chartOptions.uom}</div>`,
      },
      subtitle: {
        text: chartOptions.scope,
        verticalAlign: "middle",
        y: 60,
        floating: true,
        style: {
          color: '#303030',
          fontWeight: '900',
          fontSize: '16px'
        }
      },

      tooltip: {
        shared: true,
        useHTML: true,
        backgroundColor: '#FFFFFF',
        formatter: function (this: any) {
          return `<div style='font-size: 1rem; color:#303030; border-radius:0.25rem; font-weight: 800;'>
                ${this.point.name}: ${precisionDecimal(this.point.y)}
            </div>`
        },
      },
      credits: {
        enabled: false,
      },
      legend: {
        align: 'center',
        layout: 'vertical',
        verticalAlign: 'top',
        y: 350,
        x: 10,
        floating: true,
        symbolHeight: 12,
        symbolWidth: 12,
        symbolRadius: 2,
        squareSymbol: true,
        useHTML: false,
        itemMarginTop: 10,
        // itemMarginBottom: 2,
        itemStyle: {
          "color": "#606060",
          "font-size": "16px",
          "font-weight": "500"
        },
        navigation: {
          enabled: false,
          activeColor: "#F0F0F0",
          animation: true,
          arrowSize: 12,
          inactiveColor: "#C0C0C0",
          style: {
            fontWeight: "bold",
            color: "#00000",
            fontSize: "12px",
          },
        },
      },
      plotOptions: {
        pie: {
          shadow: true,
          center: ['50%', '33%'],
          size: "193px",
          borderColor: '',
          dataLabels: {
            enabled: false,
          },
          showInLegend: false,
        },
      },
      series: [
        {
          innerSize: "92%",
          showInLegend: true,
          name: '',
          data: getSeries(chartOptions),
          shadow: {
            color: 'rgba(0, 0, 0, 0.25)',
            width: 7,
            opacity: 1,
            offsetX: -4,
            offsetY: 7
          },
        },
      ],
    };

    return options;
  };

  const getSeries = (chartOptions: any) => {
    return chartOptions?.sources.map((item: any) => {
      return {
        name: item.source,
        y: item.actualValue,
      };
    });
  };

  const displayDonutChart = (options: any) => {
    return (
      <HighchartsReact
        highcharts={Highcharts}
        options={options}
        containerProps={{ style: { width: '20rem', height: '38rem' } }}
      ></HighchartsReact>
    );
  };

  return (
    <div className="donutChart-card">
      {loading ? (
        <div>
          <div>
            <ProgressSpinner
              className="spinner"
              animationDuration=".5s"
              pt={{
                circle: {
                  style: { stroke: "#A0A0A0", strokeWidth: 3, animation: "0s" },
                },
              }}
            />
          </div>
        </div>
      ) : (
        donutChartData.map((item: any) => {
          const options = getOptions(item);
          return displayDonutChart(options);
        })
      )}
    </div>
  );
};

export default memo(DonutCharts);
