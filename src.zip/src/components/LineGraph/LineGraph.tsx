import * as React from "react";
import { useEffect, useContext, useState, memo, useMemo } from "react";
import * as ReactDOM from "react-dom";
import * as Highcharts from "highcharts";
import NoDataToDisplay from "highcharts/modules/no-data-to-display";

import HighchartsReact from "highcharts-react-official";
import { getReportingPeriod } from "../../api/graphqlUtils";
import { AppContext } from "../../store/AppContext";
import {  getLocaleDate, getLocaleTime, getLocaleMonth, getLocaleNumber, precisionDecimal } from '../../utils/utils';


const getXAxisTitle = (values: any, variables: any) => {
  if (!values) return variables;
  const date = new Date(values);
  if (variables === "Daily" || variables === "Weekly") {
    return `${getLocaleMonth(values, { month: "long" })} ${date.getFullYear()}`;
  }
  if (variables === "Hourly") {
    return `${getLocaleDate(values, { day: '2-digit' })} ${getLocaleMonth(values, { month: "long" })} ${date.getFullYear()}`;
  }
  if (variables === "Monthly") {
    return `${date.getFullYear()}`;
  }
  return '';
};

const getXAxis = (values: any, variables: any) => {
  return values?.map((item: any) => {
      if (variables === "Daily") {
          return getLocaleDate(item, { day: '2-digit' });
      }
      if (variables === "Hourly") {
          return getLocaleTime(item, { hour: 'numeric', minute: 'numeric', hour12: false });
      }
      if (variables === "Monthly") {
          return getLocaleMonth(item, { month: "long" });
      }
      return new Date(item);
  });
};

const RankColors = ["#FFE293", "#FF644C", "#279D2B", "#005EAC"];
const nFormatter = (d: any) => d;
declare global {
  interface Window {
    jQuery: any;
  }
}

NoDataToDisplay(Highcharts);

const getSeries = (
  values: any,
  source: any,
  rankActive: any,
  selectedRank: any
) => {
  values.forEach((item: any, i: number) => {
    const series = [...item.data];
    const highestValue = Math.max(...series);
    const lowestValue = Math.min(...series);

    const highestIndex = series.indexOf(highestValue);
    const lowestIndex = series.indexOf(lowestValue);

    const y_highest = series[highestIndex];
    series[highestIndex] = {
      y: y_highest,
      color: "#EE3124",
      tooltip_text: "Highest",
      marker: { enabled: true, radius: 6 },
    };

    const y_lowest = series[lowestIndex];
    if (highestIndex !== lowestIndex) {
      series[lowestIndex] = {
        y: y_lowest,
        color: "#279D2B",
        tooltip_text: "Lowest",
        marker: { enabled: true, radius: 6 },
      };
    }

    const lastIndex = series.length - 1;
    if (highestIndex !== lastIndex && lastIndex !== lowestIndex) {
      const y_last = series[lastIndex];
      series[lastIndex] = {
        y: y_last,
        color: "#1792E5",
        tooltip_text: "Current",
        marker: { enabled: true, radius: 6 },
      };
    }

    values[i].data = series;
    values[i].marker = {
      symbol: "circle",
    };

    //item['color'] = colorcode[source];
  });
  return [...values];
};

const getNameOfMonth = (monthNumber: number) => {
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  return monthNames[monthNumber - 1];
};
const options: any = {
  lang: {
    noData: "No data to display",
  },
  noData: {
    style: {
      fontWeight: "bold",
      fontSize: "15px",
      color: "#303030",
    },
  },
  legend: {
    enabled: false,
  },
  chart: {
    height: 300,
    type: "line",
    scrollablePlotArea: {
      scrollPositionX: 0,
    },
  },
  title: {
    text: "",
  },
  subtitle: {
    text: "",
  },
  plotOptions: {
    series: {
      stacking: "normal",
      marker: {
        enabled: false,
        states: {
          hover: {
            enabled: false,
          },
        },
      },
    },
  },
  credits: {
    enabled: false,
  },
  xAxis: {
    margin: 5,
    title: {
      y: 12,
      text: "",
      style: {
        fontSize: "14px",
        fontWeight: "bold",
      },
    },
    labels: {
      style: {
        fontSize: "14px",
      },
    },
    crosshair: {
      width: 1,
      color: "#000000",
    },
  },
  yAxis: {
    lineWidth: 1,
    title: {
      text: "CO2e Emission",
      style: {
        fontSize: "14px",
        fontWeight: "bold",
      },
    },
    labels: {
      format: "{text}",
      formatter: function (this: any) {
        return (this.value);
      },
      style: {
        fontSize: "14px",
      },
    },
  },
  tooltip: {
    outside: true,
    enabled: true,
    backgroundColor: "transparent",
    shadow: "none",
    className: "line-graph-tooltip",
    style: {
      color: "white",
      borderRadius: "0.25rem",
      
      paddingTop: "0.5rem",
      paddingRight: "0.75rem",
      paddingLeft: "0.5rem",
    },
    borderWidth: 0,
    shared: true,
    useHTML: true,
    headerFormat:
      '<div class="trend-tooltip-line-graph"><div><th colspan="2">${yAxisTitle}</th></div>',
    pointFormatter: function (this: any) {
      return (
        `<div class="trend-tooltip-row"><button class="trend-tooltip-button" style="background: ${this.series.color}">${this.series.name} </button>` +
        `<div class="trend-tooltip-y">${this.tooltip_text || 'Value'}: ${getLocaleNumber(precisionDecimal(this.y))}</div></div>`
      );
    },
    footerFormat: "</div>",
    valueDecimals: 2,
  },
};
export const LineGraph = memo((props: any) => {
  const { groupByRank } = props?.scopeContributionData;
  let { timeContext } = useContext(AppContext);
  let timeStamp: any;
  let xAxisData:any = []; 
   
  const rankData: any = [];
  Object.keys(groupByRank).forEach((element: any, index: number) => {
    if(index ===0) {
      xAxisData =  groupByRank[element]?.map((item:any) => item?.time)
    };

    if (element && element !== "null") {
      const obj = groupByRank[element];
      try {
        timeStamp = obj[0].time
      } catch (error) {
        timeStamp = new Date();
      }

      rankData.push({
        name: "Rank " + element,
        color: RankColors[index],
        data: obj.map((e: any) => e.actualValue),
        lineWidth: 3,
        isActiveRank: true,
      });
    }
  });

  const {
    selectedRank,
    dateType,
    data,
    yAxisTitle,
    source,
    rankActive,
  } = {
    selectedRank: 1,
    dateType: getReportingPeriod(timeContext?.['start'], timeContext?.['end'], timeContext?.id?.toUpperCase()),
    yAxisTitle: "CO2e GHG Emission",
    source: "Boilder",
    rankActive: "Rank 1",
    data: rankData,
  };

  const chart = React.useRef<any>(null);
  const [activeRank, setActiveRank] = useState("Rank 1");
  const [activeRankColor, setActiveColor] = useState("Rank 1");
  const [legends, setLegends] = useState([]);

  useEffect(() => {
    const $legend: any = document.getElementById("customLegend");

    if (!chart.current) return;

    const legendsData = chart.current.chart.series.map(
      (data: any, j: number) => {
        return {
          color: data.color,
          name: data.name,
        };
      }
    );
    setLegends(legendsData);

    //   $('#customLegend .item').click(function(e,k){
    //     var inx = $(this).index(),
    //         point = chart.current.chart.series[inx];

    //     if(point.visible){
    //       $(this.childNodes[0]).css("background-color",  "#A0A0A0")
    //       point.setVisible(false);
    //     }
    //     else{
    //       $(this.childNodes[0]).css("background-color", point.color)
    //       point.setVisible(true);
    //     }
    // });
  }, [activeRank, activeRankColor]);

  function handleLegendClick(event: any) {
    event.stopPropagation();
    const point = chart.current.chart.series[+event.currentTarget.id];
    if (point.visible) {
      //$(this.childNodes[0]).css("background-color",  "#A0A0A0")
      event.currentTarget.firstChild.style.backgroundColor = "#A0A0A0";
      point.setVisible(false);
    } else {
      event.currentTarget.firstChild.style.backgroundColor = point.color;
      //$(this.childNodes[0]).css("background-color", point.color)
      point.setVisible(true);
    }
  }

  // useEffect(() => {
  //   //code will come here
  //   if(!chart.current) return ;
  //   let activeline = 0;
  //   data.forEach((item, index) => {
  //     if (item.isActiveRank) {
  //       if(activeline === 0){
  //         chart.current.chart.series[index].update({ opacity: 1 });
  //         setActiveRank(item.name);
  //         setActiveColor(item.color);
  //         activeline++;
  //       }

  //     } else {
  //       chart.current.chart.series[index].update({ opacity: 0.4 })
  //     }
  //   })
  //   if(activeline === 0){ //if no rank is active then default rank one will be active
  //     chart.current.chart.series[0].update({ opacity: 1 });
  //     chart.current.chart.series[0].update({ lineWidth: 6 });
  //   };

  // },[selectedRank]);

  options.xAxis.title.text = getXAxisTitle(timeStamp, dateType);

  xAxisData = xAxisData.filter((x:any, i:any, a:any) => a.indexOf(x) == i)

  options.xAxis.categories =  getXAxis( xAxisData, dateType);
  options.yAxis.title.text = yAxisTitle;
  options.tooltip.headerFormat = `<div class="trend-tooltip-line-graph "><div class="trend-tooltip-header"><h3>${yAxisTitle}</h3></div>`;

  useMemo(() => {
    options.series = [
      {
        name: "Soft Sensor",
        color: "#FF9847",
        data: [],
        lineWidth: 6,
        isActiveRank: true,
        marker: {
          symbol: "circle",
        },
      },
    ];
    if (data && data.length > 0) {
      options.series = getSeries(data, source, rankActive, selectedRank);
    }
  }, [data]);

  return (
    <div
      className="container-line-graph container-box"
      key={Math.random().toString()}
    >
      <div className="activeRankInfo">
        {/* <div className="activeStatus"></div> */}
        <h3>Rank Comparison</h3>
      </div>

      <HighchartsReact
        ref={chart}
        highcharts={Highcharts}
        options={options}
        selectedRank={selectedRank}
        key={Math.random().toString()}
      />
      <div id="customLegend">
        {legends &&
          legends.map((item: any, i: number) => (
            <div
              id={i + ""}
              onClick={handleLegendClick}
              key={"legend" + i}
              className="item"
            >
              <div
                className="symbol"
                style={{ backgroundColor: item.color }}
              ></div>
              <div className="serieName">{item.name}</div>
            </div>
          ))}
      </div>
    </div>
  );
});
