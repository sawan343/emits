import React, { useContext, useEffect, useMemo, useState } from 'react';
import { AppContext } from '../../store/AppContext';
import { useLocation, useNavigate, Outlet } from "react-router-dom";
import { HomeIcon } from '../../components/homeIcon/HomeIcon';
import homeImage from '../../assets/images/homeIcon.png';
import { KpiBar } from '../../components/kpiBar/KpiBar';
import IntensityCardContainer from '../../components/IntensityTile/intensityCard';
import { CriticalSitesContainer } from '../../components/criticalSites/criticalSiteTiles';
import { BackButton } from '../../components/BackButton/BackButton';
import { Button } from 'primereact/button';
import { Card } from 'primereact/card';
import DonutCharts from '../../components/donutCharts/donutCharts';
import { ColumnChart } from '../../components/columnChart/ColumnChart';
import { KpiSelector } from '../../components/kpiSelector/KpiSelector';
import { emissionNavigator } from '../../utils/utils';
import IntensityTileFullView from '../../components/IntensityTile/intensityFullView';
import CriticalSiteFullView from '../../components/criticalSites/CriticalSiteFullView';

const Site: any = (props: any) => {
  let location = useLocation();
  const { locale, portalContext, timeContext } = useContext(AppContext);
  const navigate = useNavigate();
  const [selectedKpiTypeFromDropdown, setSelectedKpiTypeFromDropdown] = useState("");
  const [isZoom, setIsZoom] = useState(false);
  const [intensityData, setIntensityData] = useState({});
  const [isCriticalSiteZoom, setIsCriticalSiteZoom] = useState(false);
  const [criticalSiteData, setCriticalSiteData] = useState([])

  let page = location?.state?.page || location?.pathname?.replace('/', '').toLocaleLowerCase();
  let params = location?.state?.params || { siteName: portalContext.site };

  useEffect(() =>{
    setIsZoom(false);
  },[timeContext?.start, timeContext?.end, portalContext?.asset]);

  const zoomHandler = (data: any) => {
    setIsZoom(!isZoom);
    setIntensityData(data);
  }

  const criticalSiteZoomHandler = (data: any) => {
    setIsCriticalSiteZoom(!isCriticalSiteZoom);
    setCriticalSiteData(data);
  }

  const kpiSelectorCallback = (kpi: any) => setSelectedKpiTypeFromDropdown(kpi);

  const gotoTrend = () => {
    emissionNavigator(navigate, 'sitedetail/trends', { ...params }, '/');
  }

  return (
    <div className="site-container pt-4">
      <div className="site-header ml-3">
        <BackButton />
        <HomeIcon img={homeImage} />
        <div className="page-text ml-3 text-2xl w-full">
          <span>{params?.siteName || locale['siteTitle']}</span>
        </div>
      </div>
      <div className="ml-3 mr-3 floatTiles">
        <div id="kpiBar" className="kpiBar">
          <KpiBar page={page} params={params} />
        </div>
        {!isZoom && !isCriticalSiteZoom &&
          <div className='flex intensity-donut-container'>
            <div className='intensityCriticalSites'>
              <div id='kpiSelector' className='mt-3'>
                <KpiSelector kpiSelectorCallback={kpiSelectorCallback} />
              </div>
              <div id='intensity' className='p-3 mt-2'>
                <IntensityCardContainer page={page} params={params} selectedKpiTypeFromDropdown={selectedKpiTypeFromDropdown} zoomHandler={zoomHandler} />
              </div>
              <div id='top3CriticalSites'>
                <CriticalSitesContainer
                  page={page}
                  params={params}
                  selectedKpiTypeFromDropdown={selectedKpiTypeFromDropdown}
                  criticalSiteZoomHandler={criticalSiteZoomHandler}
                />
              </div>
            </div>

            <Card className='main-body ml-3 mt-3'>
              <div className="card">
                <div className='text-base donut-title'>{locale['ghgEmissionsBySources']}</div>
                <div>
                  <DonutCharts page={page} params={params} />
                </div>
              </div>
            </Card>
          </div>}
        {isZoom &&
          <div className='w-full mt-3 intensity-full-view'>
            <IntensityTileFullView
              intensityData={intensityData}
              page={page}
              zoomHandler={zoomHandler}
              selectedKpiTypeFromDropdown={selectedKpiTypeFromDropdown}
            />
          </div>
        }
        {
          isCriticalSiteZoom &&
          <div className='w-full mt-3 intensity-full-view'>
            <CriticalSiteFullView
              criticalSiteData={criticalSiteData}
              page={page}
              criticalSiteZoomHandler={criticalSiteZoomHandler}
              selectedKpiTypeFromDropdown={selectedKpiTypeFromDropdown}
            />
          </div>
        }
        <div className='flex justify-content-end'>
          <button type="button" className='ViewDetailsButton my-4 buttonBgColor buttonBorder' onClick={gotoTrend}>{locale['viewDetails']}</button>
        </div>
      </div>
    </div>
  );
};

export default React.memo(Site);