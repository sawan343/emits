
import React, {useContext} from 'react';
import { AppContext } from '../../store/AppContext';

const NoPage:any = (props:any) => {
const { locale } = useContext(AppContext);
console.log(props)
return <p>{locale["noPage"]}</p>;
}

export default NoPage ;

