import React from 'react';
import { sourceTagInfo } from '../../utils/utils';
import useScopeContributionChart from "../../hooks/useScopeContributionChart";


export const CallScopeContributionAPI = (props:any) => {
    const {sourceTagMetaData, getscopeContributionData} = props;
    const {
      scopeContributionData,
      scopeContributionLoading,
      scopeContributionError
    } =  useScopeContributionChart(sourceTagMetaData);
  
    if(!scopeContributionLoading) {
      getscopeContributionData({
        scopeContributionData,
        scopeContributionLoading,
        scopeContributionError
      })
    }
  
    return null;
  }
