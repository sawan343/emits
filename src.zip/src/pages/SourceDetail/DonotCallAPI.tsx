import React from 'react';
import useSourceTagMetaData from "../../hooks/useSourceTagMetaData";
import { sourceTagInfo } from '../../utils/utils';

export const DonotCallAPI = (props: any) => {
    const { locationState, getSourceTagMetaData } = props;
    const {
      actualValue,
      imageUrl,
      kpi_category,
      rank,
      scope_displayname,
      site,
      source_displayname,
      source_tag,
      sourcegroup_displayname,
      sourcetag_displayname,
      subsource_displayname,
      uom,
      asset_name
    } = locationState.params;
  
    getSourceTagMetaData({
      sourceTagMetaData: sourceTagInfo(
        actualValue,
        imageUrl,
        kpi_category,
        rank,
        scope_displayname,
        site,
        source_displayname,
        source_tag,
        sourcegroup_displayname,
        sourcetag_displayname,
        subsource_displayname,
        uom,
        asset_name
      ),
      sourceTagMetaDataLoading: false,
      sourceTagMetaDataError: false,
    });
    return null;
  };
  