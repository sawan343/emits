import React, { useEffect, useContext, useState, memo, useCallback } from "react";
import { InfoCard } from "../../components/InfoCard/InfoCard";
import { LineGraph } from "../../components/LineGraph/LineGraph";
import { IntensityBar } from "../../components/IntensityBar/IntensityBar";
import { GasesTable } from "../../components/GasesTable/GasesTable";
import { useLocation, useNavigate } from "react-router-dom";
import { Loader } from "../../components/Loader/Loader";
import { AppContext } from "../../store/AppContext";
import { CHART_COLORS } from "../../utils/constants";
import { HomeIcon } from "../../components/homeIcon/HomeIcon";
import homeImage from '../../assets/images/homeIcon.png';
import { BackButton } from "../../components/BackButton/BackButton";
import { DonotCallAPI } from "./DonotCallAPI";
import { CallAPI } from "./CallAPI";
import { CallScopeContributionAPI } from "./CallScopeContributionAPI";
import { isArray } from "highcharts";

let activeRank:any = 1;

export const SourceDetail  = memo ((props: any) => {
  const { locale, portalContext, timeContext } = useContext(AppContext);

  const locationState = useLocation()?.state;

  const [sourceTagMetaData, setSourceTagMetaData]:any = useState({});
  const [sourceTagMetaDataError, setSourceTagMetaDataError] = useState();
  const [sourceTagMetaDataLoading, setSourceTagMetaDataLoading] = useState(true);

  const [scopeContributionData, setScopeContributionData]:any = useState({});
  const [scopeContributionDataError, setScopeContributionDataError] = useState();
  const [scopeContributionDataLoading, setScopeContributionDataLoading] = useState(true);

  useEffect(() =>{
    if(locationState?.params?.isNavigatedFromRanking) {
      setScopeContributionData({});
      setScopeContributionDataLoading(true);
    } else {
      setSourceTagMetaDataLoading(true);
      setSourceTagMetaData({});
    }
   
  },[timeContext?.start, timeContext?.end, portalContext?.asset]);

  useEffect(() =>{
    if(sourceTagMetaData?.scope_displayname) {
      setScopeContributionData({});
      setScopeContributionDataLoading(true);
    }else{
      if(!sourceTagMetaDataLoading) {
        setScopeContributionData({
          groupDataByScope: {},
          groupDataBySource: {},
          groupDataBySourceTag: {},
          totalScope: '',
          totalSource:'',
          totalSourceTag:'',
          groupByRank:[],
        });
      }
    }
  }, [sourceTagMetaDataLoading])

  const getSourceTagMetaData = (obj:any) => {
    if(sourceTagMetaDataLoading){
      setSourceTagMetaDataLoading(obj.sourceTagMetaDataLoading);
      setSourceTagMetaDataError( obj.sourceTagMetaDataError);
      setSourceTagMetaData({...obj.sourceTagMetaData, siteName: obj.sourceTagMetaData?.siteName || portalContext?.site}); 
    }
  }

  const getscopeContributionData  = (obj:any) => {
    if(scopeContributionDataLoading && !sourceTagMetaDataLoading){
      setScopeContributionDataLoading(obj.scopeContributionLoading);
      setScopeContributionDataError( obj.scopeContributionError);
      setScopeContributionData(obj.scopeContributionData); 
      if(sourceTagMetaData?.activeRank) {
        activeRank = sourceTagMetaData?.activeRank;
      } else {
        activeRank = obj?.scopeContributionData?.activeRank;
      }
    }
  };
  const gasesItems = [
    {
      color: "#E0E0E0",
      percentage: 100,
      formula: "This is formula",
      columnName: "Scope 1",
      value: 900,
    },
    {
      color: "#1792E5",
      percentage: 50,
      formula: "This is formula",
      columnName: "Combustion",
      value: 30,
    },
    {
      color: "green",
      percentage: 50,
      formula: "This is formula",
      columnName: "Boiler",
      value: 30,
    },
  ];
  
  const intensityProps = {
    gasData: gasesItems,
    unit: "Tonnes",
    sourceTag: "Boiler",
  };

  if(!scopeContributionDataLoading){
    const {
      groupDataByScope,
      groupDataBySource,
      groupDataBySourceTag,
      totalScope,
      groupByRank,
      totalSource,
      totalSourceTag
    } = scopeContributionData;
    const {sourcetag_displayname, source_displayname, scope_displayname, uom, rank, kpi_type, actualValue} =  sourceTagMetaData;
    gasesItems[0] = {
      color: "#E0E0E0",
      percentage: totalScope > 0 ? 100 : 0,
      formula: "This is formula",
      columnName: scope_displayname,
      value: totalScope,
    };
    gasesItems[1] = {
      color: CHART_COLORS[source_displayname],
      percentage: (totalScope > 0 && totalSource > 0) ? (totalSource/totalScope) * 100 : 0 ,
      formula: "This is formula",
      columnName: source_displayname,
      value: totalSource,
    };
    gasesItems[2] = {
      color: "green",
      percentage: (totalSource > 0 && totalSourceTag > 0) ? (totalSourceTag/totalSource) * 100 : 0,
      formula: "This is formula",
      columnName: sourcetag_displayname,
      value: totalSourceTag,
    };
    intensityProps.unit = uom;
    intensityProps.sourceTag = sourcetag_displayname;
  }
  
  if(sourceTagMetaDataLoading) {
    return <><Loader />{locationState?.params?.isNavigatedFromRanking ? 
    <DonotCallAPI locationState= {locationState} getSourceTagMetaData={getSourceTagMetaData}/> : 
    locationState?.params?.isNavigatedFromMap ? <CallAPI getSourceTagMetaData={getSourceTagMetaData} asset = {locationState?.params?.assetName} siteName = {locationState?.params?.siteName} /> : 
    <CallAPI getSourceTagMetaData={getSourceTagMetaData} asset = {portalContext?.asset} siteName = {portalContext?.site} />}</>
  }
  
  if(scopeContributionDataLoading && !sourceTagMetaDataLoading) return <> <Loader /><CallScopeContributionAPI sourceTagMetaData = {sourceTagMetaData} getscopeContributionData = {getscopeContributionData} /></>;
  return (
    <div className="asset-view-container">
      <div className="header flex">
          <BackButton />
          <HomeIcon img={homeImage} />
          <div><h1>{sourceTagMetaData?.sourcetag_displayname}</h1></div>
          
      </div>
      
      <div className="row1">
        <InfoCard activeRank = {activeRank} sourceTagMetaData= {sourceTagMetaData} scopeContributionData = {scopeContributionData}/>
        <IntensityBar {...intensityProps} />
      </div>
      <div className="row2">
        {" "}
        <LineGraph scopeContributionData = {scopeContributionData} sourceTagMetaData= {sourceTagMetaData} />
      </div>
      <div className="row3">
        {" "}
        {sourceTagMetaData?.asset_name ? <GasesTable activeRank = {activeRank} sourceTagMetaData= {sourceTagMetaData} /> : <p>{locale['noGasFound']}</p>}
      </div>
    </div>
  );
});
