import React, {memo} from 'react';
import useSourceTagMetaData from "../../hooks/useSourceTagMetaData";
import { sourceTagInfo } from '../../utils/utils';
import useActiveRank from '../../hooks/useActiveRank';

export const CallAPI = memo((props: any) => {
    const { asset, siteName, getSourceTagMetaData } = props;
  
    const {
      sourceTagMetaData,
      sourceTagMetaDataLoading,
      sourceTagMetaDataError,
    } = useSourceTagMetaData("", asset);
    const {activeRankData, activeLoading, activeError}  = useActiveRank("", siteName, asset);

    if(!sourceTagMetaDataLoading && !activeLoading) {
      const {
        actualValue,
        imageUrl,
        kpi_category,
        rank,
        scope_displayname,
        site,
        source_displayname,
        source_tag,
        sourcegroup_displayname,
        sourcetag_displayname,
        subsource_displayname,
        uom,
        asset_name
      } = sourceTagMetaData;
      getSourceTagMetaData({
        sourceTagMetaData: sourceTagInfo(
          actualValue,
          imageUrl,
          kpi_category,
          activeRankData,
          scope_displayname,
          site,
          source_displayname,
          source_tag,
          sourcegroup_displayname,
          sourcetag_displayname,
          subsource_displayname,
          uom,
          asset_name
        ),
        sourceTagMetaDataLoading,
        sourceTagMetaDataError,
      });
    }
    return null;
  });