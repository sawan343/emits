import React, { useContext, useState, memo, useEffect, useMemo } from "react";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import { BackButton } from "../../components/BackButton/BackButton";
import { emissionNavigator } from "../../utils/utils";
import { AppContext } from "../../store/AppContext";
import TrendIcon from "../../assets/images/Trend.png";
import FilterPanel from "../../components/FilterPanel/FilterPanel";
import useFilterPanelData from "../../hooks/useFilterPanelData";
import { DataViewLayoutOptions } from "primereact/dataview";
import { HomeIcon } from "../../components/homeIcon/HomeIcon";
import homeImage from '../../assets/images/homeIcon.png';

//import SourceIcon from "../../assets/images/Sources.svg";

const MapIcon = `<svg width="18" height="17" viewBox="0 0 18 17" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M1 3.99352V15.9676L6.09091 12.9741L11.9091 15.9676L17 12.9741V1L11.9091 3.99352L6.09091 1L1 3.99352Z" stroke="#606060" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M11.4727 3.80078V14.7099" stroke="#606060" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.23828 1.18164V12.0907" stroke="#606060" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;

const SourceIcon = `<svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8.44369 4.39996C8.54105 4.24704 8.42963 4.04716 8.24837 4.04957L7.99924 4.05287C6.5433 4.09048 5.08953 3.93735 3.67479 3.59801C3.38975 3.52963 3.11035 3.74203 3.11035 4.03516V4.03516C3.11035 4.23899 3.24921 4.4171 3.44791 4.46254C4.94012 4.80377 6.46791 4.96658 7.99924 4.94728V4.94728C8.15433 4.94728 8.28232 4.83094 8.32755 4.68259C8.35727 4.58513 8.39612 4.49049 8.44369 4.39996V4.39996Z" fill="#606060" stroke="#606060" stroke-width="0.5"/>
<path d="M8.44369 7.45708C8.54105 7.30417 8.42963 7.10429 8.24837 7.1067L7.99924 7.11C6.5433 7.14761 5.08953 6.99448 3.67479 6.65514C3.38975 6.58676 3.11035 6.79916 3.11035 7.09229V7.09229C3.11035 7.29612 3.24921 7.47423 3.44791 7.51967C4.94012 7.8609 6.46791 8.02371 7.99924 8.00441V8.00441C8.15433 8.00441 8.28232 7.88807 8.32755 7.73972C8.35727 7.64226 8.39612 7.54762 8.44369 7.45708V7.45708Z" fill="#606060" stroke="#606060" stroke-width="0.5"/>
<path d="M8.44369 10.4607C8.54105 10.3078 8.42963 10.108 8.24837 10.1104L7.99924 10.1137C6.5433 10.1513 5.08953 9.99814 3.67479 9.6588C3.38975 9.59043 3.11035 9.80282 3.11035 10.0959V10.0959C3.11035 10.2998 3.24921 10.4779 3.44791 10.5233C4.94012 10.8646 6.46791 11.0274 7.99924 11.0081V11.0081C8.15433 11.0081 8.28232 10.8917 8.32755 10.7434C8.35727 10.6459 8.39612 10.5513 8.44369 10.4607V10.4607Z" fill="#606060" stroke="#606060" stroke-width="0.5"/>
<path d="M7.99772 14.1614C11.5177 14.1614 13.6199 13.4539 13.7755 13.0712V8.83945H14.6644V13.0668C14.6644 14.6242 10.4733 15.038 7.99772 15.038C5.52217 15.038 1.33105 14.6197 1.33105 13.0668V3.01911C1.33105 1.46168 5.52217 1.04785 7.99772 1.04785C8.49297 1.04785 9.05484 1.06625 9.63874 1.10635C9.96313 1.12864 10.1461 1.48345 9.9833 1.76494C9.89708 1.91405 9.73287 1.99993 9.56101 1.98852C9.07749 1.95644 8.55466 1.93781 7.99772 1.93781C4.44217 1.93781 2.35328 2.66758 2.21994 3.03246V13.0668C2.35328 13.4361 4.47772 14.1614 7.99772 14.1614Z" fill="#606060" stroke="#606060" stroke-width="0.5"/>
<path d="M13.0158 1.00195L14.4325 2.46862C14.7127 2.75848 14.9035 3.12786 14.9809 3.53002C15.0583 3.93219 15.0187 4.34907 14.8672 4.72795C14.7156 5.10682 14.459 5.43067 14.1297 5.65851C13.8003 5.88636 13.4132 6.00798 13.0171 6.00798C12.621 6.00798 12.2338 5.88636 11.9044 5.65851C11.5751 5.43067 11.3185 5.10682 11.1669 4.72795C11.0154 4.34907 10.9759 3.93219 11.0532 3.53002C11.1306 3.12786 11.3214 2.75848 11.6016 2.46862L13.0158 1.00195Z" stroke="#606060" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;
const DataForButton = [{
    type: "trends",
    icon: TrendIcon,
    localeText: "Trends"

}, {
    type: "source",
    icon: SourceIcon,
    localeText: "Source"

}, {
    type: "mapview",
    icon: MapIcon,
    localeText: "Map"

}];
export const SiteDetails = memo(() => {
    const navigate = useNavigate();
    const { locale } = useContext(AppContext);
    const [layout, setLayout] = useState('grid');
    const location = useLocation();
    let { params } = location?.state;
    const siteName = params?.siteName;
    params = { ...params, layout: layout };

    const { valueBySource } = useFilterPanelData(location?.state?.pageName?.toLowerCase() ||
        location?.pathname?.replace("/", "").toLocaleLowerCase());

    const handleTabs = (e: any) => {
        const tabName = e.currentTarget.id;
        emissionNavigator(navigate, tabName, { ...params });
    };

    const changeLayout = (value: any) => {
        setLayout(value);
        params = { ...params, layout: value };
        return emissionNavigator(navigate, 'source', { ...params });
    }

    const activeButtonI: any = useMemo(() => {
        let active;
        let header;
        switch (location.pathname.toLowerCase()) {
            case "/sitedetail/trends":
                active = 'trends';
                header = 'trendView';
                break;
            case "/sitedetail/source":
                active = 'source'
                header = 'sourceView';
                break;
            case "/sitedetail/mapview":
                active = 'mapview';
                header = 'mapView';
                break;

            default:
                active = ""
                break;
        }
        return { active, header };
    }, [location.pathname]);

    const getSelectedLayout = () => {
        return layout === 'grid' ? 'grid' : 'list';
    }

    return (
        <div className="site-page-container">
            <header className="site-header">
                <div className="lhs">
                    <div className="icons"> <BackButton isWhiteBG={true} />  <HomeIcon img={homeImage} /></div>
                    <div className="header-text"> <h1 className="page-text">{locale[activeButtonI.header] + ' : ' + siteName}</h1></div>
                </div>
                <div className="rhs flex">
                    {
                        activeButtonI.active === 'source' && <DataViewLayoutOptions layout={getSelectedLayout()} onChange={(e: any) => changeLayout(e.value)} />
                    }
                    <div className="layout-button-container flex">
                        {DataForButton.map((item: any, i: number) => {
                            const { type, icon, localeText } = item;
                            const isActive = activeButtonI.active === type ? 'active' : "";
                            return (
                                <div key={`button_site` + i} id={type} className={`${isActive} button`} onClick={handleTabs}>

                                    <img
                                        src={`data:image/svg+xml;base64,${btoa(
                                            icon
                                        )}`}
                                        alt=""
                                    />
                                    <a> {locale[localeText]}</a> </div>
                            );
                        })}


                    </div>
                    <FilterPanel FilterPanelData={valueBySource} />
                </div>
            </header>
            <Outlet />
        </div>
    );
});
