import React, {useContext, useEffect, useState} from "react";
import AerialMap from "../../../../components/mapComponent/MapComponent";
import useMapView from "../../../../hooks/useMapView";
import { useLocation, useNavigate   } from "react-router-dom";
import { Loader } from "../../../../components/Loader/Loader";
import { AppContext } from "../../../../store/AppContext";
import { emissionNavigator } from "../../../../utils/utils";
export const MapView = () => {
    const { locale, siteDetailFilter } = useContext(AppContext);
    const [loadMap, setLoadMap] = useState(true);
    const location = useLocation();
    const navigate = useNavigate();

    useEffect(() =>{
        setLoadMap(false);
    },[JSON.stringify(siteDetailFilter)])

    useEffect(() =>{
        if(!loadMap){
            setLoadMap(true);
        }
    },[loadMap])

    function gotoSourceDetails(selectedAsset: any) {
        console.log(selectedAsset);
        emissionNavigator(navigate, 'source_detail', { siteName: siteName, assetName: selectedAsset, isNavigatedFromRanking: false, isNavigatedFromMap: true }, '/')
      }

    const siteName = location?.state?.params?.siteName;
    const page = location?.state?.page?.toLowerCase() || location?.pathname?.replace('/', '').toLocaleLowerCase();
    const {
        assetsLatLong,
        loading,
        error,
        markersWithTop3Emitters
    }= useMapView(page, siteName, siteDetailFilter);
    

    let mapMarkerData: any = [];
    if (loading) return <Loader />;

    if(error) return <p>{locale["errorMessage"]}</p>;

    if (assetsLatLong?.length > 0) {
        mapMarkerData = assetsLatLong.map((item: any) => {
            const { enterprise, latitude, asset_name, longitude, sourcetag_displayname, limitCheckStatus, source_displayname, scope_displayname } = item;

            return (
                {
                    label: sourcetag_displayname,
                    position: { lat: Number(latitude), lng: Number(longitude) },
                    status: limitCheckStatus,
                    tags: [source_displayname, scope_displayname],
                    tooltip: markersWithTop3Emitters[sourcetag_displayname],
                    clickHandler: (data: any) => {
                        gotoSourceDetails.call(null, asset_name)
                        //return false;
                    }
                }
            )
        })
    };

    // if (assetsLatLong?.length > 0) {
    //     mapMarkerData = assetsLatLong.map((item: any) => {
    //         const { enterprise, latitude, longitude, sourcetag_displayname, limitCheckStatus } = item;
    //         return (
    //             {
    //                 label: sourcetag_displayname,
    //                 position: { lat: Number(latitude), lng: Number(longitude) },
    //                 status: limitCheckStatus
    //             }
    //         )
    //     })
    // };

    return  <div className="map-view-container">
        { loadMap  && <AerialMap  data={mapMarkerData} maxZoom = {true} showTooltip = {true} siteDetailFilter = {siteDetailFilter}/> }
    </div>
}

