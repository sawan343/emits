import React, { useContext, useReducer } from "react";
import { ColumnChart } from "../../../../components/columnChart/ColumnChart";
import { TrendGrid } from "../../../../components/trendGrid/TrendGrid";
import { Card } from "primereact/card";
import { useLocation } from "react-router-dom";
import { AppContext } from "../../../../store/AppContext";


export const Trends = () => {  
  const { locale, portalContext, siteDetailFilter } = useContext(AppContext);
  const location = useLocation();
  const siteName = location?.state?.params?.siteName || portalContext?.site;
  
  const [state, setState] = useReducer((oldState: any, newState: any) => (
    { ...oldState, ...newState }), {
    active: portalContext?.assetType === 'Unit' ? 'unit' : 'source',
    isUnitLevel: portalContext?.assetType === 'Unit',
    selectedTrendNode: null,
    selectedColumnNode: null,
    selectedNodeList:[]
  })

  const setSelectedTrendNode = (event: any) => {
    setState({ selectedTrendNode: event })
  }

  const setSelectedColumnNode = (event: any) => {
    setState({ selectedColumnNode: event })
  }

  const getSelectedNodeList = (event:any) => {
    setState({selectedNodeList: event})
  }

  const DataForButton = [{
    type: "source",
    localeText: "BY SOURCES"

  }, {
    type: "unit",
    localeText: "BY UNITS"

  }];

  const handleTabs = (e: any) => {
    const tabName = e.currentTarget.id;
    const isUnitLevel = tabName === 'unit';
    return setState({ active: tabName, isUnitLevel });
  };
  return (
    <>
      <Card className='chart-container'>
        <div className="card">
          <div className="flex header">
            <div className='text-base column-chart-title'>{locale["ghgEmissionsBySources"]}</div>
            <div>
              <div className="layout-button-container flex">
                {DataForButton.map((item: any, i: number) => {
                  const { type, localeText } = item;
                  const isActive = state.active === type ? 'active' : "";
                  return (
                    <div key={`button_site` + i} id={type} className={`${isActive}`} onClick={handleTabs}>
                      {/* <a> {locale[localeText]}</a> */}
                      <a>{localeText}</a>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
          <ColumnChart siteName={siteName} selectedTrendNode={state.selectedTrendNode} setSelectedColumnNode={setSelectedColumnNode} isUnitLevel={state.isUnitLevel} getSelectedNodeList={getSelectedNodeList} siteDetailFilter = {siteDetailFilter} />
        </div>
      </Card>
      <div className="chart-container tree-table">
        <TrendGrid siteName={siteName} setSelectedTrendNode={setSelectedTrendNode} selectedColumnNode={state.selectedColumnNode} isUnitLevel={state.isUnitLevel} selectedNodeList={state.selectedNodeList}  siteDetailFilter = {siteDetailFilter} />
      </div>
    </>
  )
}
