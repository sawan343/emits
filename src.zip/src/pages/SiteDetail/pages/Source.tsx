import React, { useContext } from "react";
import { RankingVisual } from "../../../components/rankingVisual/RankingVisual";
import { useLocation   } from "react-router-dom";
import { AppContext } from "../../../store/AppContext";

export const Source = () => {
    const { locale } = useContext(AppContext);

    const location = useLocation();
    const siteName = location?.state?.params?.siteName;
    return (
        <div className="rankingVisualContainer">
             <div className="sources-title"><p>{locale['emissionBySources']}</p></div>
            <RankingVisual siteName ={siteName}/>
        </div>
    )
}

