import React, { useEffect, useContext } from "react";
import { Outlet, Link, useLocation, redirect, useNavigate, Navigate } from "react-router-dom";
import { messagingContext, getPortalCurrentContext } from "../../portal/portal";
import { AppContext } from "../../store/AppContext";
import GetAssetDetails from "../../hooks/useAssetDetailsData";
import { deepCloneEmission, defaultTimeRange } from "../../utils/utils";


/**
 *  This hook will be invoke every time when router will get change 
 *  it can be use for sending data to portal
 * 
 *  note : below function/hook will be moved to hook folder
 */
function usePageViews() {
  let location = useLocation();
  useEffect(() => {
    console.log(["pageview", location.pathname]);
  }, [location]);
};


const Layout: any = () => {
  const { setLocale, setPortalContext, portalContext, timeContext, setTimeContext } = useContext(AppContext);
  const navigate = useNavigate();


  usePageViews();

  const portalContextHandler = async (context: any) => {
    console.log("ortal context fnc ", context)
    let contextObj = {};
    if (context.subject) {
      // setPortalContext(context);
      contextObj = deepCloneEmission(context);

      if (sessionStorage.getItem('assetData')) {
        let assetsFromSessionStorage = deepCloneEmission(sessionStorage.getItem('assetData'));
        console.log("asset already have")
        return storeContextAndNavigate(contextObj, assetsFromSessionStorage, 'old');
      }
      else {
        try {
          const data = await GetAssetDetails();
          console.log("nav-portal >>> GetAssetDetails");
          if (data && data.data?.assets && data?.data?.assets.length > 0) {
            sessionStorage.setItem('assetData', JSON.stringify(data?.data?.assets));
            return storeContextAndNavigate(contextObj, data?.data?.assets, 'new');
          }
        }
        catch (error: any) {
          console.log("nav-portal >>> GetAssetDetails > error ");
          console.log(error)
        };
      }
    }
  }

  const portalTimeHandler = (context: any) => {
    console.log("context in time fnc ", context)
    let contextObj = {};
    if (context.time) {
      contextObj = deepCloneEmission(context)?.time.resolved;
      setTimeContext(contextObj)
    }
    else {
      let time = defaultTimeRange();
      setTimeContext(deepCloneEmission(time)?.resolved);
    }
  }

  const storeContextAndNavigate = (contextObj: any, data: any, status: string) => {
    let newPortalContext = generateContext(contextObj, data, status);
    console.log("newPortalContext ", newPortalContext)
    setPortalContext(newPortalContext);
    console.log("nav-portal >>> GetAssetDetails > data && data.assets && data.assets.length > 0 ");
    let redirectTo = newPortalContext.assetType === "Enterprise" ? "/" : newPortalContext.assetType;
    
    switch (newPortalContext.assetType) {
      case "Enterprise":
        redirectTo = ""
        break;
      case "Unit":
        redirectTo = "sitedetail/trends"
        break;
      case "Asset":
        redirectTo = "source_detail"
        break;
      default:
        redirectTo = newPortalContext.assetType;
        break;
    }

    try {
      navigate(`/${redirectTo}`, {
        replace: false, state: {
          page: newPortalContext?.assetType?.toLocaleLowerCase(),
          params: {siteName:  newPortalContext?.site}
        }
      }); 
    } catch (error) {
      navigate(`/`, {
        replace: false, state: {
          page: "landing"
        }
      });
    };
   

  }

  const generateContext = (context: any, assetData: any, state: any) => {
    console.log("generate context: ", context);
    console.log("generate assetData: ", assetData);
    console.log(Array.isArray(assetData))
    let localAssetDetails;
    if (state === 'new') {
      localAssetDetails = assetData.filter((item: any) => item.name === context?.subject?.alias[0]?.id)[0];
    }
    else {
      localAssetDetails = JSON.parse(assetData).filter((item: any) => item.name === context?.subject?.alias[0]?.id)[0];
    }

    return {
      assetId: localAssetDetails?.id,
      assetType: localAssetDetails?.assettype_name,
      asset: localAssetDetails?.name,
      enterprise: localAssetDetails?.enterprise,
      region: localAssetDetails?.region,
      site: localAssetDetails?.site
    }
  }

  useEffect(() => {
    getPortalCurrentContext().then(async (context: any) => {
      console.log("nav-portal >>> getPortalCurrentContext  ");

      if (context?.correlationId) {
        portalTimeHandler(context);
        portalContextHandler(context);
        console.log("nav-portal >>> getPortalCurrentContext >>>  portalContextHandler(context) ");

      }
    })
  }, [messagingContext])

  useEffect(() => {
    console.log("nav-portal >>> useEffect(messagingContext)");

    messagingContext.connect();
    messagingContext.onChanged(async (context: any) => {
      console.log("nav-portal >>> useEffect(messagingContext) >>> messagingContext.onChanged");

      if (context?.correlationId) {
        console.log("nav-portal >>> useEffect(messagingContext) >>> messagingContext.onChanged >>> portalContextHandler(context)");
        portalTimeHandler(context);
        portalContextHandler(context);
      }
    })
  }, [messagingContext])

  console.log("contextObjFromContextApi ", portalContext)
  console.log("time context ", timeContext)
  return (
    <div data-testid="Emissions" className="layout-wrapper">
      <Outlet />
    </div>
  )
};

export default Layout;
