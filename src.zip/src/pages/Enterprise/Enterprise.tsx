import React, { useContext, useEffect, useMemo, useState } from 'react';
import { AppContext } from '../../store/AppContext';
import { useLoaderData, useLocation, useNavigate } from 'react-router-dom';
import { useQuery, gql } from '@apollo/client';
import AerialMap from '../../components/mapComponent/MapComponent';
import { KpiBar } from '../../components/kpiBar/KpiBar'
import './Enterprise.scss';
import IntensityCardContainer from '../../components/IntensityTile/intensityCard';
import { CriticalSitesContainer } from '../../components/criticalSites/criticalSiteTiles';
import homeImage from '../../assets/images/Home.png';
import useAssetLatLongData from '../../hooks/useAssetLatLongData';
import { HomeIcon } from '../../components/homeIcon/HomeIcon';
import { BackButton } from '../../components/BackButton/BackButton';
import { Loader } from '../../components/Loader/Loader';
import { KpiSelector } from '../../components/kpiSelector/KpiSelector';
import { emissionNavigator } from '../../utils/utils';
import IntensityTileFullView from '../../components/IntensityTile/intensityFullView';
import CriticalSiteFullView from '../../components/criticalSites/CriticalSiteFullView';
export const EnterPriseLoader = () => {

};

const EnterPrise: any = (props: any) => {
    const [selectedKpiTypeFromDropdown, setSelectedKpiTypeFromDropdown] = useState("");
    const [theme, setTheme] = useState("light");
    const [isZoom, setIsZoom] = useState(false);
    const [intensityData, setIntensityData] = useState({})
    const [isCriticalSiteZoom, setIsCriticalSiteZoom] = useState(false);
    const [criticalSiteData, setCriticalSiteData] = useState([])

    const { locale, portalContext, timeContext } = useContext(AppContext);
    let location = useLocation();
    const navigate = useNavigate();
    let page = location?.state?.page || location?.pathname?.replace('/', '').toLocaleLowerCase();
    let params = location?.state?.params;

    const { assetsLatLong, markersWithTop3Emitters, loading, error } = useAssetLatLongData(page, params);
    const kpiSelectorCallback = (kpi:any) => setSelectedKpiTypeFromDropdown(kpi);

    useEffect(() =>{
        setIsZoom(false);
        setIsCriticalSiteZoom(false);
      },[timeContext?.start, timeContext?.end, portalContext?.asset]);

    const zoomHandler = (data:any) => {
        setIsZoom(!isZoom);
        setIntensityData(data);
    }

    const criticalSiteZoomHandler = (data:any) => {
        setIsCriticalSiteZoom(!isCriticalSiteZoom);
        setCriticalSiteData(data);
    }
    //const data: any = useLoaderData();
    const themeChanger = (e: any) => {
        setTheme(
            prev => {
                return prev === "dark" ? "light" : "dark"
            }
        );
        e.preventDefault()

    };

    useMemo(() => {
        const root = document.getElementsByTagName('html')[0]; // '0' to assign the first (and only `HTML` tag)
        root.setAttribute('class', '');
        root.setAttribute('class', theme);
    }, [theme])

    let mapMarkerData: any = [];
    if (loading) return <Loader />;

    if (error) return <p>{locale["errorMessage"]}</p>;

    if (assetsLatLong?.length > 0) {
        mapMarkerData = assetsLatLong.map((item: any) => {
            const { enterprise, latitude, longitude, region, limitCheckStatus } = item;
            return (
                {
                    label: "Region: " + region,
                    criticalSiteslabel: locale['criticalSite'],
                    regionName: region,
                    position: { lat: Number(latitude), lng: Number(longitude) },
                    status: limitCheckStatus,
                    tooltip: markersWithTop3Emitters[region],
                    clickHandler: (data: any) => {
                        emissionNavigator(navigate,'region', { redirect: region } ,'/');
                    }
                }
            )
        })
    };
    return (
        <>
            <div className="emission-container pt-4">
                <AerialMap data={mapMarkerData} showTooltip = {true} />
                <div className='enterprise-header ml-3'>
                    {/* <BackButton /> */}
                    <HomeIcon
                        img={homeImage}
                    />
                    <div className='page-text ml-3 text-2xl w-full'>
                        <span>{portalContext['enterprise'] || locale['enterpriseTitle']}</span>
                    </div>

                </div>
                <div className='ml-3 mr-3 floatTiles'>
                    <div id='kpiBar' className='kpiBar'>
                        <KpiBar page = {page} params = {params} />
                    </div>
                    {!isZoom && !isCriticalSiteZoom &&
                        <div className='intensityCriticalSites'>
                            <div id='kpiSelector' className='mt-3'>
                                <KpiSelector  kpiSelectorCallback = {kpiSelectorCallback} />
                            </div>
                            <div id='intensity' className='p-3 mt-2'>
                                <IntensityCardContainer page = {page} params = {params} selectedKpiTypeFromDropdown = {selectedKpiTypeFromDropdown} zoomHandler = {zoomHandler}/>
                            </div>
                            <div id='top3CriticalSites'>
                                <CriticalSitesContainer
                                    page={page}
                                    params = {params}
                                    selectedKpiTypeFromDropdown = {selectedKpiTypeFromDropdown}
                                    criticalSiteZoomHandler = {criticalSiteZoomHandler}
                                />
                            </div>
                        </div>
                    }
                    {isZoom &&
                        <div className='w-full mt-3 intensity-full-view'>
                            <IntensityTileFullView
                                intensityData = {intensityData}
                                page = {page}
                                zoomHandler = {zoomHandler}
                                selectedKpiTypeFromDropdown = {selectedKpiTypeFromDropdown}
                            />
                        </div>
                    }
                    {
                        isCriticalSiteZoom && 
                        <div className='w-full mt-3 intensity-full-view'>
                            <CriticalSiteFullView
                                criticalSiteData = {criticalSiteData}
                                page = {page}
                                criticalSiteZoomHandler = {criticalSiteZoomHandler}
                                selectedKpiTypeFromDropdown = {selectedKpiTypeFromDropdown}
                            />
                        </div>
                    }
                </div>
            </div>
        </>


    );
}

export default React.memo(EnterPrise);