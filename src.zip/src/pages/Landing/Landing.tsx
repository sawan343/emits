import React from 'react';
import { BackgroudImage } from "../../components/backgroudImage/BackgroudImage";
import { EmissionSummary } from "../../components/emissionSummary/EmissionSummary";
import useLandingPageData from '../../hooks/useLandingPageData';
import { useLocation } from 'react-router-dom';
import { Loader } from '../../components/Loader/Loader';


const Landing: any = (props: any) => {
    const location = useLocation();
    const { totalEmissionData, loading, error } = useLandingPageData(location.state?.pageName?.toLowerCase() || location.pathname.replace('/', '').toLocaleLowerCase());

    if (loading) {
        return <Loader />
    }

    return (
        <div className="landing-page">
            <BackgroudImage />
            <EmissionSummary totalEmissionData={totalEmissionData} />
        </div>
    );
}

export default React.memo(Landing);