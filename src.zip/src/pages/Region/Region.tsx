
import React, { useContext, useState, useEffect } from 'react';
import { AppContext } from '../../store/AppContext';
import AerialMap from '../../components/mapComponent/MapComponent';
import { KpiBar } from '../../components/kpiBar/KpiBar';
import IntensityCardContainer from '../../components/IntensityTile/intensityCard';
import { CriticalSitesContainer } from '../../components/criticalSites/criticalSiteTiles';
import { useLocation, useNavigate } from 'react-router-dom';
import useAssetLatLongData from '../../hooks/useAssetLatLongData';
import { HomeIcon } from '../../components/homeIcon/HomeIcon';
import homeImage from '../../assets/images/Home.png';
import '../Enterprise/Enterprise.scss';
import { BackButton } from '../../components/BackButton/BackButton';
import { Loader } from '../../components/Loader/Loader';
import { emissionNavigator } from '../../utils/utils';
import { KpiSelector } from '../../components/kpiSelector/KpiSelector';
import IntensityTileFullView from '../../components/IntensityTile/intensityFullView';
import CriticalSiteFullView from '../../components/criticalSites/CriticalSiteFullView';

const Region: any = () => {
    const [selectedKpiTypeFromDropdown, setSelectedKpiTypeFromDropdown] = useState("");
    const [isZoom, setIsZoom] = useState(false);
    const [intensityData, setIntensityData] = useState({})
    const [isCriticalSiteZoom, setIsCriticalSiteZoom] = useState(false);
    const [criticalSiteData, setCriticalSiteData] = useState([])

    const kpiSelectorCallback = (kpi:any) => setSelectedKpiTypeFromDropdown(kpi);


    const { locale, portalContext, timeContext } = useContext(AppContext); let location = useLocation();
    const navigate = useNavigate();

    let page = location?.state?.page || location?.pathname?.replace('/', '').toLocaleLowerCase();
    let params = location?.state?.params;
    const { assetsLatLong, loading,  error, markersWithTop3Emitters} = useAssetLatLongData(page,params);
    let mapMarkerData: any = [];

    useEffect(() =>{
        setIsZoom(false);
      },[timeContext?.start, timeContext?.end, portalContext?.asset]);

    const zoomHandler = (data:any) => {
        setIsZoom(!isZoom);
        setIntensityData(data);
    }

    const criticalSiteZoomHandler = (data:any) => {
        setIsCriticalSiteZoom(!isCriticalSiteZoom);
        setCriticalSiteData(data);
    }

    if (loading) return <Loader />;

    if(error) return <p>{locale["errorMessage"]}</p>;

    if (assetsLatLong?.length > 0) {
        mapMarkerData = assetsLatLong.map((item: any) => {
            const { enterprise, latitude, longitude, site, limitCheckStatus } = item;
            return (
                {
                    label: "Site: " + site,
                    criticalSiteslabel: locale['criticalSite'],
                    position: { lat: Number(latitude), lng: Number(longitude) },
                    status: limitCheckStatus,
                    tooltip: markersWithTop3Emitters[site],
                    clickHandler: (data: any) => {
                        emissionNavigator(navigate, 'site', { redirect: params?.redirect, siteName: site }, '/');
                    }
                }
            )
        })
    };

    return (
        <>
            <div className="emission-container pt-4">
            <AerialMap data={mapMarkerData} showTooltip = {true}/>
            <div className='enterprise-header ml-3'>
                <BackButton />
                <HomeIcon 
                    img ={homeImage}
                />
                <div className='page-text ml-3 text-2xl'>
                    {params?.redirect || locale['regionPageHeader']}
                </div>
            </div>
            <div className='ml-3 mr-3 floatTiles'>
                <div id='kpiBar' className='kpiBar'>
                    <KpiBar page = {page} params = {params} />
                </div>
                {!isZoom && !isCriticalSiteZoom &&
                        <div className='intensityCriticalSites'>
                            <div id='kpiSelector' className='mt-3'>
                                <KpiSelector  kpiSelectorCallback = {kpiSelectorCallback} />
                            </div>
                            <div id='intensity' className='p-3 mt-2'>
                                <IntensityCardContainer page = {page} params = {params} selectedKpiTypeFromDropdown = {selectedKpiTypeFromDropdown} zoomHandler = {zoomHandler}/>
                            </div>
                            <div id='top3CriticalSites'>
                                <CriticalSitesContainer
                                    page={page}
                                    params = {params}
                                    selectedKpiTypeFromDropdown = {selectedKpiTypeFromDropdown}
                                    criticalSiteZoomHandler = {criticalSiteZoomHandler}
                                />
                            </div>
                        </div>
                    }
                    {isZoom &&
                        <div className='w-full mt-3 intensity-full-view'>
                            <IntensityTileFullView
                                intensityData = {intensityData}
                                page = {page}
                                zoomHandler = {zoomHandler}
                                selectedKpiTypeFromDropdown = {selectedKpiTypeFromDropdown}
                            />
                        </div>
                    }
                    {
                        isCriticalSiteZoom && 
                        <div className='w-full mt-3 intensity-full-view'>
                            <CriticalSiteFullView
                                criticalSiteData = {criticalSiteData}
                                page = {page}
                                criticalSiteZoomHandler = {criticalSiteZoomHandler}
                                selectedKpiTypeFromDropdown = {selectedKpiTypeFromDropdown}
                            />
                        </div>
                    }
            </div>
        </div>

        </>
    )
};

export default React.memo(Region);